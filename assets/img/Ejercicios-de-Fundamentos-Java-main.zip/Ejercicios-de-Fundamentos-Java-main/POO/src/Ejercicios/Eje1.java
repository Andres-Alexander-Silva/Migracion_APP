package Ejercicios;

import java.util.Scanner;

public class Eje1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int miligramos = sc.nextInt();

        if (miligramos > 100) System.out.println("¡Felicidades, es una buena poción!");
        else System.out.println("La poción es mediocre, sangre sucia inmunda");
    }
}
