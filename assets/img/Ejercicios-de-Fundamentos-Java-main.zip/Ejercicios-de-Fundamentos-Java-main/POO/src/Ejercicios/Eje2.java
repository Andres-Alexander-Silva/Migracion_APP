package Ejercicios;

import java.util.Scanner;

public class Eje2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        float distancia_conductor;
        boolean disponibilidad;

        distancia_conductor = sc.nextFloat();
        disponibilidad = sc.nextBoolean();

        if (distancia_conductor <= 0.5 && disponibilidad) System.out.println("Listo para iniciar recorrido");
        else if (distancia_conductor <= 0.5 && !disponibilidad) System.out.println("Conductro cercano, pero no disponible");
        else if (distancia_conductor > 0.5 && disponibilidad) System.out.println("Conductor disponible pero muy lejos, aplicaran tarifas mas altas");
        else System.out.println("No hay conductores disponibles");
    }
}