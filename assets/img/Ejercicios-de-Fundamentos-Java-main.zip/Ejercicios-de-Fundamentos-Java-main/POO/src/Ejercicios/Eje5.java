package Ejercicios;

import java.util.Scanner;

public class Eje5 {
    public static void main(String[] args) {
        String[] titulos = new String[] {"Jumanji","Toy Story","Pulp Fiction","Batman: El caballero de la noche","Kill Bill"};

        int max_length = 0;
        String longest_tililos = "";

        for (String title: titulos) {
            int tamano_titulos = titulos.length;
            if (tamano_titulos > max_length) {
                max_length = tamano_titulos;
                longest_tililos = title;
            }
        }

        System.out.println(longest_tililos);
    }
}