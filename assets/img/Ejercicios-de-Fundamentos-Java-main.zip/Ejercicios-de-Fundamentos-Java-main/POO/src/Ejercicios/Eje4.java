package Ejercicios;

import java.util.Scanner;

public class Eje4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("¿Como esta el clima hoy?");
        int clima = sc.nextInt();

        switch (clima) {
            case 1 -> System.out.println("El clima es soleado");
            case 2 -> System.out.println("El clima es Nublado");
            case 3 -> System.out.println("El clima es Lluvioso");
            case 4 -> System.out.println("El clima es Tormentoso");
            case 5 -> System.out.println("El clima es Nevado");
            default -> System.out.println("preguntale a google");
        }
    }
}