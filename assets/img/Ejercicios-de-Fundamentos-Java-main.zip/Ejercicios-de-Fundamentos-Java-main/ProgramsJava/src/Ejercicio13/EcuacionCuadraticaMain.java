package Ejercicio13;

import java.util.Scanner;

class EcuacionCuadraticaMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        EcuacionCuadratica ec = new EcuacionCuadratica();

        ec.a = c.nextInt();
        ec.b = c.nextDouble();
        ec.c = c.nextInt();

        ec.calcularCuadratica();

        System.out.println("Concavidad hacia arriba: " + ec.concavidadHArriba);
        System.out.println("Concavidad hacia abajo:  " + ec.concavidadHAbajo);
        System.out.println("No hay soluciones:       " + ec.noHaySoluciones);
        System.out.println("Hay una solucion:        " + ec.hayUnaSolucion);
        System.out.println("Hay dos soluciones:      " + ec.hayDosSoluciones);
        System.out.println("Solucion:                " + ec.formato);
    }
}
