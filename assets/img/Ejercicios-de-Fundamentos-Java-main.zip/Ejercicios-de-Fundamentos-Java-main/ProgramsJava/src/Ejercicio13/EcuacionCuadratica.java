package Ejercicio13;

class EcuacionCuadratica {
    int a,c;
    int division;
    double b;
    double solucion;
    boolean concavidadHArriba,concavidadHAbajo;
    boolean noHaySoluciones,hayUnaSolucion,hayDosSoluciones;
    String formato;

    void calcularCuadratica(){
        solucion = Math.pow(b,2d) - 4 * a * c;
        b = -(b);
        division = 2 * a;
        noHaySoluciones = solucion < 0;
        hayUnaSolucion = solucion == 0;
        hayDosSoluciones = solucion > 0;
        concavidadHArriba = a > 0;
        concavidadHAbajo = a < 0;
        formato = "( " + (int )b + " \u00b1 " + "√(" + (int) solucion + ")" + " ) " + "/ " + division;
    }
}
