package Ejercicio7;

import java.util.Scanner;

class RelogInvertidoMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        RelogInvertido rg = new RelogInvertido();

        rg.horas = c.nextInt();
        rg.minutos = c.nextInt();
        rg.segundos = c.nextInt();

        rg.calcularSegundos();

        System.out.println("Tiempo total en segundos: " + rg.totalSegundos);
    }
}
