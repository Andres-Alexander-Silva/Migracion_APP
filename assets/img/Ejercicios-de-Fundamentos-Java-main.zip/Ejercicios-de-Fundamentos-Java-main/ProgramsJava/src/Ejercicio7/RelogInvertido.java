package Ejercicio7;

class RelogInvertido {
    int horas;
    int minutos;
    int segundos;
    int totalSegundos;
    int horaASegundo;
    int minutoASegundo;

    void calcularSegundos(){
        horaASegundo = horas * 3600;
        minutoASegundo = minutos * 60;
        totalSegundos = horaASegundo + minutoASegundo + segundos;
    }
}
