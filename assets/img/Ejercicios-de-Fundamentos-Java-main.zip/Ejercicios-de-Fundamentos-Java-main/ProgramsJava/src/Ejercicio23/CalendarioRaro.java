package Ejercicio23;

class CalendarioRaro {
    int n0 = 48;
    int numD1,numD2,numMes1,numMes2,numA1,numA2,numA3,numA4;
    int fechaCalendario;
    String fechaASCII;

    void calcularCalentario(){
        numD1 = (fechaCalendario / 10000000) + n0;
        numD2 = ((fechaCalendario % 10000000) / 1000000) + n0;
        numMes1 = ((fechaCalendario % 10000000) % 1000000) / 100000 + n0;
        numMes2 = ((((fechaCalendario % 10000000) % 1000000) % 100000) / 10000) + n0;
        numA1 = 9 - ((((fechaCalendario % 10000000) % 1000000) % 100000) % 10000) / 1000;
        numA2 = 9 - (((((fechaCalendario % 10000000) % 1000000) % 100000) % 10000) % 1000) / 100;
        numA3 = 9 - ((((((fechaCalendario % 10000000) % 1000000) % 100000) % 10000) % 1000) % 100) / 10;
        numA4 = 9 - ((((((fechaCalendario % 10000000) % 1000000) % 100000) % 10000) % 1000) % 100) % 10;
        fechaASCII = numD1+""+numD2+""+numMes1+""+numMes2+""+numA1+""+numA2+""+numA3+""+numA4;
    }
}
