package Ejercicio23;

import java.util.Scanner;

class CalendarioRaroMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CalendarioRaro cr = new CalendarioRaro();

        cr.fechaCalendario = c.nextInt();

        cr.calcularCalentario();

        System.out.println(cr.fechaASCII);
    }
}
