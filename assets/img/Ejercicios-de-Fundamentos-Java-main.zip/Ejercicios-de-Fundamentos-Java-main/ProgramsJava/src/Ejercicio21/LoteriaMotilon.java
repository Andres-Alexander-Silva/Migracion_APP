package Ejercicio21;

class LoteriaMotilon {
    int numeroG,numeroA,apuestoAP,apuestaAPI,apuestaP;
    int a,b,c,d,p,q,r,s;
    boolean ganaP,ganaAP,ganaAPI;
    long valorGPI,valorGP,valorGAP,valorGT;

    void calcularloteria(){
        a = numeroG / 1000;
        b = (numeroG % 1000) / 100;
        c = ((numeroG % 1000) % 100) / 10;
        d = ((numeroG % 1000) % 100) % 10;
        p = numeroA / 1000;
        q = (numeroA % 1000) / 100;
        r = ((numeroA % 1000) % 100) / 10;
        s = ((numeroA % 1000) % 100) % 10;
        ganaP = (a == p) && (b == q) && (c == r) && (d == s);
        ganaAPI = (a == s) && (b == r) && (c == q) && (d == p);
        ganaAP = (c == r) && (d == s);
        valorGP = (long) apuestaP * 5000;
        valorGPI = (long) apuestaAPI * 2500;
        valorGAP = (long) apuestoAP * 1000;
        valorGT = valorGP + valorGPI + valorGAP;
    }
}
