package Ejercicio21;

import java.util.Scanner;

class LoteriaMotilonMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        LoteriaMotilon lm = new LoteriaMotilon();

        lm.numeroG = c.nextInt();
        lm.numeroA = c.nextInt();
        lm.apuestaP = c.nextInt();
        lm.apuestaAPI = c.nextInt();
        lm.apuestoAP = c.nextInt();

        lm.calcularloteria();

        System.out.println("Gana Pleno: " + lm.ganaP);
        System.out.println("Gana Pleno Invertido: " + lm.ganaAPI);
        System.out.println("Gana Pata: " + lm.ganaAP);
        System.out.println("Valor Gana Pleno: " + lm.valorGP);
        System.out.println("Valor Gana Pleno Invertido: " + lm.valorGPI);
        System.out.println("Valor Gana Pata: " + lm.valorGAP);
        System.out.println("Valor Gana Total: " + lm.valorGT);
    }
}
