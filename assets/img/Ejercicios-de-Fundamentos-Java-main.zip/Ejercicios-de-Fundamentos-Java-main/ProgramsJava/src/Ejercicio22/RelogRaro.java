package Ejercicio22;

class RelogRaro {
    int horaMS;
    int h,s,m;
    char jornada;
    boolean datosValidos;
    boolean MoN, eOa, mOn;

    void calcularRelogR(){
        h = (horaMS / 100) / 100;
        m = (horaMS / 100) % 100;
        s = horaMS % 100;

        mOn = ((jornada == 'm' || jornada == 'n') && (h == 12)) && (m >= 0 && m <= 59) && (s >= 0 && s <= 59);
        eOa = (jornada == 'e' || jornada == 'a') && (h >= 1 && h <= 5) && (m >= 0 && m <= 59) && (s >= 0 && s <= 59);
        MoN = (jornada == 'M' || jornada == 'N') && (h >= 6 && h <= 11) && (m >= 0 && m <= 59) && (s >= 0 && s <= 59);
        datosValidos = mOn || eOa || MoN;
    }
}
