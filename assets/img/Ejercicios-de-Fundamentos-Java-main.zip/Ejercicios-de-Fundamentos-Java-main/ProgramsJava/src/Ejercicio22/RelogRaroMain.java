package Ejercicio22;

import java.util.Scanner;

class RelogRaroMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        RelogRaro rc = new RelogRaro();

        rc.horaMS = c.nextInt();
        rc.jornada = c.next().charAt(0);

        rc.calcularRelogR();
        System.out.println("Hora Valida: " + rc.datosValidos);
    }
}
