package Ejercicio26;

class DosRectangulo {
    int r1X1,r1Y1,anchoR1,altoR1,r2X1,r2Y1,anchoR2,altoR2;
    int x2R1,x3R1,x4R1,x2R2,x3R2,x4R2;
    int y2R1,y3R1,y4R1,y2R2,y3R2,y4R2;
    String puntosRectangulo1,puntosRectangulo2;
    boolean interior,exterior,secante,tangente;

    void calcularRectanguloD(){
        x2R1 = r1X1 + anchoR1;
        x3R1 = x2R1;
        x4R1 = x3R1 - anchoR1;
        y2R1 = r1Y1;
        y3R1 = y2R1 -altoR1;
        y4R1 = y3R1;
        x2R2 = r2X1 + anchoR2;
        x3R2 = x2R2;
        x4R2 = x3R2 - anchoR2;
        y2R2 = r2Y1;
        y3R2 = y2R2 - altoR2;
        y4R2 = y3R2;
        interior = (r2X1 < x2R1 && r2X1 > r1X1 && r2Y1 < r1Y1 && r2Y1 > y4R1) && (x3R2 < x3R1 && x3R2 > x4R1 && y3R2 < y2R1 && y3R2 > y3R1);
        exterior = x2R2<r1X1||y4R1>r2Y1||x2R1<r2X1||r1Y1<y4R2;
        tangente = ((x4R2>=r1X1) && (r1Y1==y4R2)||(x3R2<=x2R1)&&(r1Y1==y4R2)) || ((r2X1>=x4R1)&&(y4R1==r2Y1)||(x2R2<=x3R1)&&(y4R1==r2Y1)) ||
                (((y2R2<=r1Y1)&&(r1X1==x2R2)||(y3R2>=y4R1)&&(r1X1==x2R2)))||(((r2Y1<=y2R2)&&(x2R1==r2Y1)||(y4R2>=y3R1)&&(x2R1==r2Y1)))
                || r1X1 == r2X1 && (r1Y1 == r2Y1) || x2R1 == x2R2 && (y2R1 == y2R2)|| x3R1 == x3R2 && (y3R1 == y3R2)|| x4R1 == x4R2 && (y4R1 == y4R2);
        secante = (interior==exterior)==(tangente == false);
        puntosRectangulo1 = "("+r1X1+","+r1Y1+")"+", ("+x2R1+","+y2R1+")"+", ("+x3R1+","+y3R1+")"+", ("+x4R1+","+y4R1+")";
        puntosRectangulo2 = "("+r2X1+","+r2Y1+")"+", ("+x2R2+","+y2R2+")"+", ("+x3R2+","+y3R2+")"+", ("+x4R2+","+y4R2+")";
    }
}
