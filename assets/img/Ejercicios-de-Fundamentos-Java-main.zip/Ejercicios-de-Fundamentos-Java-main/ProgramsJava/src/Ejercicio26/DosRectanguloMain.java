package Ejercicio26;

import java.util.Scanner;

class DosRectanguloMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        DosRectangulo dr = new DosRectangulo();

        dr.r1X1 = c.nextInt();
        dr.r1Y1 = c.nextInt();
        dr.anchoR1 = c.nextInt();
        dr.altoR1 = c.nextInt();
        dr.r2X1 = c.nextInt();
        dr.r2Y1 = c.nextInt();
        dr.anchoR2 = c.nextInt();
        dr.altoR2 = c.nextInt();

        dr.calcularRectanguloD();

        System.out.println("Puntos del Rectángulo 1: " + dr.puntosRectangulo1);
        System.out.println("Puntos del Rectángulo 2: " + dr.puntosRectangulo2);
        System.out.println("Rectángulos Interiores:  " + dr.interior);
        System.out.println("Rectángulos Exteriores:  " + dr.exterior);
        System.out.println("Rectángulos Secantes:    " + dr.secante);
        System.out.println("Rectángulos Tangentes:   " + dr.tangente);
    }
}
