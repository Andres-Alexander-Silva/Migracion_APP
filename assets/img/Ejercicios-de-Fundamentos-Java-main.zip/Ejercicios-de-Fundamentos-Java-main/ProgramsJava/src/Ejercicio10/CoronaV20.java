package Ejercicio10;

class CoronaV20{
    int dia1,dia2,dia3,dia4,dia5,dia6;
    int porcentajeCD1,porcentajeCD2,porcentajeCD3,porcentajeCD4,porcentajeCD5;
    int promedioPorcentaje;

    void calcularPorcentajeC(){
        porcentajeCD1 = ((dia2 - dia1) * 100) / dia2;
        porcentajeCD2 = ((dia3 - dia2) * 100) / dia3;
        porcentajeCD3 = ((dia4 - dia3) * 100) / dia4;
        porcentajeCD4 = ((dia5 - dia4) * 100) / dia5;
        porcentajeCD5 = ((dia6 - dia5) * 100) / dia6;
        promedioPorcentaje = (porcentajeCD1 + porcentajeCD2 + porcentajeCD3 + porcentajeCD4 + porcentajeCD5) / 5;
    }
}
