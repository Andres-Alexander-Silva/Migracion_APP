package Ejercicio10;

import java.util.Scanner;

class CoronaV20Main {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        CoronaV20 cv = new CoronaV20();

        cv.dia1 = c.nextInt();
        cv.dia2 = c.nextInt();
        cv.dia3 = c.nextInt();
        cv.dia4 = c.nextInt();
        cv.dia5 = c.nextInt();
        cv.dia6 = c.nextInt();

        cv.calcularPorcentajeC();

        System.out.println("Porcentaje de Contagio 1: " + cv.porcentajeCD1);
        System.out.println("Porcentaje de Contagio 2: " + cv.porcentajeCD2);
        System.out.println("Porcentaje de Contagio 3: " + cv.porcentajeCD3);
        System.out.println("Porcentaje de Contagio 4: " + cv.porcentajeCD4);
        System.out.println("Porcentaje de Contagio 5: " + cv.porcentajeCD5);
        System.out.println("Promedio del Porcentage : " + cv.promedioPorcentaje);
    }
}
