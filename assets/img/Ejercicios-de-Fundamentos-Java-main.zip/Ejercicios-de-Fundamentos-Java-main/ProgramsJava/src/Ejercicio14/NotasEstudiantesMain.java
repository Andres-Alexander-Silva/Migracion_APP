package Ejercicio14;

import java.util.Scanner;

class NotasEstudiantesMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        NotasEstudiantes nte = new NotasEstudiantes();

        nte.notaEstudiante = c.nextDouble();

        nte.calcularNota();

        System.out.println("Nota valida         : " + nte.notaValida);
        System.out.println("Nota Muy Deficiente : " + nte.notaMDeficiente);
        System.out.println("Nota Deficiente     : " + nte.notaDeficiente);
        System.out.println("Nota Aceptable      : " + nte.notaAceptable);
        System.out.println("Nota Buena          : " + nte.notaBuena);
        System.out.println("Nota Exelente       : " + nte.notaExelente);
    }
}
