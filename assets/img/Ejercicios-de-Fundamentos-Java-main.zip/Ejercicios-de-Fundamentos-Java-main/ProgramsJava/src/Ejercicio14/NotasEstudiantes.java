package Ejercicio14;

class NotasEstudiantes {
    double notaEstudiante;
    boolean notaValida,notaMDeficiente,notaDeficiente;
    boolean notaAceptable,notaBuena,notaExelente;

    void calcularNota(){
        notaValida = notaEstudiante >= 0 && notaEstudiante <= 5.0;
        notaMDeficiente = notaEstudiante >= 0 && notaEstudiante < 2.9;
        notaDeficiente = notaEstudiante >= 3 && notaEstudiante < 3.4;
        notaAceptable = notaEstudiante >= 3.5 && notaEstudiante < 3.9;
        notaBuena = notaEstudiante >= 4 && notaEstudiante < 4.4;
        notaExelente = notaEstudiante >= 4.5 && notaEstudiante < 4.9;
    }
}
