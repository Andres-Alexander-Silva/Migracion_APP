package Ejercicio8;

import java.util.Scanner;

class VelocidadInternetMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        VelocidadInternet v = new VelocidadInternet();

        v.velocidadMBPS = c.nextInt();
        v.bytesTransferir = c.nextInt();

        v.calcularVelocidad();

        System.out.println("Tiempo de Transferencia : " + v.tiempoTransferencia);
    }
}
