package Ejercicio8;

class VelocidadInternet {
    int velocidadMBPS;
    int bytesTransferir;
    int tiempoTransferencia;
    int mbps;
    int bits;

    void calcularVelocidad(){
        mbps = velocidadMBPS * 1000000;
        bits = bytesTransferir * 8;
        tiempoTransferencia = bits / mbps;
    }
}
