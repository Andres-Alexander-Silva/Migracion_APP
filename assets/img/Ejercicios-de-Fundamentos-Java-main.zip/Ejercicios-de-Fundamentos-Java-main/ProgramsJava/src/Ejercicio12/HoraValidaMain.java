package Ejercicio12;

import java.util.Scanner;

class HoraValidaMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        HoraValida hv = new HoraValida();

        hv.horas = c.nextInt();
        hv.minutos = c.nextInt();
        hv.segundos = c.nextInt();

        hv.evaluarHoraValida();

        System.out.println("¿Hora es válida? " + hv.horaValida);
    }
}
