package Ejercicio12;

class HoraValida {
    int horas;
    int minutos;
    int segundos;
    boolean horasValidas;
    boolean segundosValidos;
    boolean minutosValidos;
    boolean horaValida;

    void evaluarHoraValida(){
        horasValidas = horas <= 24;
        minutosValidos = minutos <= 60;
        segundosValidos = segundos <= 60;
        horaValida = (horasValidas) && (minutosValidos) && (segundosValidos);
    }
}
