package Ejercicio15;

import java.util.Scanner;

class CensoMain {
     public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Censo cs = new Censo();

        cs.edad = c.nextDouble();
        cs.estatura = c.nextDouble();
        cs.peso = c.nextDouble();

        cs.clacularCenso();

        System.out.println("Edad fuera de rango     : " + cs.edadFR);
        System.out.println("Estatura fuera de rango : " + cs.estaturaFR);
        System.out.println("Peso fuera de rango     : " + cs.pesoFR);
        System.out.println("Joven                   : " + cs.joven);
        System.out.println("Adulto                  : " + cs.adulto);
        System.out.println("Segunda Edad            : " + cs.segundaEdad);
        System.out.println("Estatura Baja           : " + cs.estaturaB);
        System.out.println("Estatura Promedio       : " + cs.estaturaP);
        System.out.println("Estatura Alta           : " + cs.estaturaA);
        System.out.println("Peso Bajo               : " + cs.pesoB);
        System.out.println("Peso Promedio           : " + cs.pesoP);
        System.out.println("Peso Alto               : " + cs.pesoA);
    }
}
