package Ejercicio15;

class Censo {
    double edad,estatura,peso;
    boolean edadFR,estaturaFR,pesoFR,joven,adulto,segundaEdad;
    boolean estaturaB,estaturaP,estaturaA,pesoB,pesoP,pesoA;

    void clacularCenso(){
        estaturaB = estatura >= 1 && estatura <= 1.6;
        estaturaP = estatura > 1.6 && estatura <= 1.7;
        estaturaA = estatura > 1.7 && estatura <= 1.8;
        pesoB = peso >= 40 && peso <= 60;
        pesoP = peso > 60 && peso <= 80;
        pesoA = peso > 80 && peso <= 100;
        joven = edad >= 16 && edad <= 25;
        adulto = edad > 25 && edad <= 40;
        segundaEdad = edad > 40 && edad <= 50;
        pesoFR = peso > 100 || peso < 40;
        edadFR = edad > 16 || edad < 50;
        estaturaFR = estatura > 1 || estatura < 1.8;
    }
}
