package Ejercicio25;

class DosCircunferencias {
    int rC1,rC2;
    double cXC1,cYC1,cXC2,cYC2;
    double distanciaC;
    float sumaR,restaR;
    boolean exteriores,tangenteE,secantes,tangenteI,interiores,concentricas;

    void calcularDosC(){
        distanciaC = Math.sqrt(Math.pow((cXC2 - cXC1),2) + Math.pow((cYC2 - cYC1),2));
        sumaR = rC1 + rC2;
        restaR = rC1 - rC2;
        exteriores = distanciaC > sumaR;
        tangenteE = distanciaC == sumaR;
        secantes = (distanciaC < sumaR) && (distanciaC > restaR);
        tangenteI = distanciaC == restaR;
        interiores = distanciaC < restaR && distanciaC != 0;
        concentricas = distanciaC == 0;
    }
}
