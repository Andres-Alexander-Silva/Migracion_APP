package Ejercicio25;

import java.util.Scanner;

class DosCircunferenciasMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        DosCircunferencias dc = new DosCircunferencias();

        dc.rC1 = c.nextInt();
        dc.cXC1 = c.nextDouble();
        dc.cYC1 = c.nextDouble();
        dc.rC2 = c.nextInt();
        dc.cXC2 = c.nextDouble();
        dc.cYC2 = c.nextDouble();

        dc.calcularDosC();

        System.out.println("Distancia entre Centros = " + dc.distanciaC);
        System.out.println("Suma de radios          = " + dc.sumaR);
        System.out.println("Resta de radios         = " + dc.restaR);
        System.out.println("Exteriores              = " + dc.exteriores);
        System.out.println("Tangentes Exteriores    = " + dc.tangenteE);
        System.out.println("Secantes                = " + dc.secantes);
        System.out.println("Tangentes Interiores    = " + dc.tangenteI);
        System.out.println("Interiores              = " + dc.interiores);
        System.out.println("Concéntricas            = " + dc.concentricas);
    }
}
