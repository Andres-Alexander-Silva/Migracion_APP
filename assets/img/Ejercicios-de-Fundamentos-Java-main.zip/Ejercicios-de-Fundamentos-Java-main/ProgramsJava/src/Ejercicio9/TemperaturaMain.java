package Ejercicio9;

import java.util.Scanner;

class TemperaturaMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        Temperatura tmp = new Temperatura();

        tmp.celsius = c.nextFloat();
        tmp.farenheit = c.nextFloat();
        tmp.kelvin = c.nextFloat();

        tmp.calculoTemperatura();

        System.out.println("Celsius a Farenheit: " + tmp.celsiusFarenheit);
        System.out.println("Celsius a Kelvin: " + tmp.celsiusKelvin);
        System.out.println("Farenheit a Celsius: " + tmp.farenheitCelsius);
        System.out.println("Farenheit a Kelvin: " + tmp.farenheitKelvin);
        System.out.println("Kelvin a Celsius: " + tmp.kelvinCelsius);
        System.out.println("Kelvin a Farenheit: " + tmp.kelvinFarenheit);
        System.out.println("Equivalentes: " + tmp.equivalentes);
    }
}
