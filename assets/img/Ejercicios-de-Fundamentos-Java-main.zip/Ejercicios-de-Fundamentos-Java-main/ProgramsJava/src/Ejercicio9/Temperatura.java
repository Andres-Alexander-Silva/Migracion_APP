package Ejercicio9;

class Temperatura {
    float celsius;
    float farenheit;
    float kelvin;
    float celsiusFarenheit;
    float celsiusKelvin;
    float farenheitCelsius;
    float farenheitKelvin;
    float kelvinCelsius;
    float kelvinFarenheit;
    boolean equivalentes;

    void calculoTemperatura(){
        celsiusFarenheit = ((9*celsius)/5) + 32;
        celsiusKelvin = celsius + 273;
        farenheitCelsius = (5 * (farenheit - 32)) / 9;
        farenheitKelvin = ((5 * (farenheit - 32)) / 9) + 273;
        kelvinCelsius = kelvin - 273;
        kelvinFarenheit = ((9 * (kelvin - 273)) / 5) + 32;
        equivalentes = (celsiusFarenheit == kelvinFarenheit) && (Math.round(farenheitCelsius) == Math.round(kelvinCelsius)) && (celsiusKelvin == farenheitKelvin);
    }
}
