package Ejercicio27;

import java.util.Scanner;

class RotacionDEjesMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        RotacionDEjes re = new RotacionDEjes();

        re.x1 = c.nextDouble();
        re.y1 = c.nextDouble();
        re.x2 = c.nextDouble();
        re.y2 = c.nextDouble();
        re.x3 = c.nextDouble();
        re.y3 = c.nextDouble();
        re.x4 = c.nextDouble();
        re.y4 = c.nextDouble();

        re.calculorRotacionE();

        System.out.println("output=Puntos del Rectángulo Rotado:");
        System.out.println(re.p1);
        System.out.println(re.p2);
        System.out.println(re.p3);
        System.out.println(re.p4);
        System.out.println("Ángulo de Rotación: " + re.a);
    }
}
