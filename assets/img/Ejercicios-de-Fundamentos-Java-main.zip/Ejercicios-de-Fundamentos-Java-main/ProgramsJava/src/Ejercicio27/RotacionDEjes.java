package Ejercicio27;

class RotacionDEjes {
    double x1,x2,x3,x4,y1,y2,y3,y4;
    double distancia,co,ca;
    double s,c;
    double x1R,x2R,x3R,x4R,y1R,y2R,y3R,y4R;
    int a;
    double r;
    String p1,p2,p3,p4;

    void calculorRotacionE(){
        distancia = Math.sqrt(Math.pow((x2-x1),2) + Math.pow((y2-y1),2));
        co = Math.abs(y1-y2);
        ca = Math.abs(x1-x2);
        c = ca / distancia;
        s = co / distancia;
        x1R = (x1 * c) - (y1 * s);
        x2R = (x2 * c) - (y2 * s);
        x3R = (x3 * c) - (y3 * s);
        x4R = (x4 * c) - (y4 * s);
        y1R = (x1 * s) + (y1 * c);
        y2R = (x2 * s) + (y2 * c);
        y3R = (x3 * s) + (y3 * c);
        y4R = (x4 * s) + (y4 * c);
        p1 = "("+Math.round(x1R)+","+Math.round(y1R)+"),";
        p2 = "("+Math.round(x2R)+","+Math.round(y2R)+"),";
        p3 = "("+Math.round(x3R)+","+Math.round(y3R)+"),";
        p4 = "("+Math.round(x4R)+","+Math.round(y4R)+")";
        r = Math.acos(c);
        a = (int) Math.round(Math.toDegrees(r));
    }
}
