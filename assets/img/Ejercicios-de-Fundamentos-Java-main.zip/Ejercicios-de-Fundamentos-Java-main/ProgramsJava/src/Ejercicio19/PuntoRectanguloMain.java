package Ejercicio19;

import java.util.Scanner;

class PuntoRectanguloMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        PuntoRectangulo pr = new PuntoRectangulo();

        pr.sx = c.nextDouble();
        pr.sy = c.nextDouble();
        pr.ancho = c.nextDouble();
        pr.alto = c.nextDouble();
        pr.x = c.nextDouble();
        pr.y = c.nextDouble();

        pr.calcularPuntoR();

        System.out.println("Punto Dentro             : " + pr.dentro);
        System.out.println("Punto Fuera              : " + pr.fuera);
        System.out.println("Punto En Borde Superior  : " + pr.bordeS);
        System.out.println("Punto En Borde Inferior  : " + pr.bordeI);
        System.out.println("Punto En Borde Izquierdo : " + pr.bordeIz);
        System.out.println("Punto En Borde Derecho   : " + pr.bordeD);
    }
}
