package Ejercicio19;

class PuntoRectangulo {
    double sx,sy,ancho,alto,x,y;
    double anchoMax,altoMin;
    boolean dentro,fuera,bordeS,bordeI,bordeIz,bordeD;

    void calcularPuntoR(){
        anchoMax = sx + ancho;
        altoMin = sy - alto;
        dentro = (x < anchoMax) && (x > sx) && (y > altoMin) && (y < sy);
        fuera = (x > anchoMax) || (x < sx) || (y < altoMin) || (y > sy);
        bordeS = ((x < anchoMax) && (x > sx)) && (y == sy);
        bordeI = ((x <= anchoMax) && (x >= sx)) && (y == altoMin);
        bordeIz = (x == sx) && ((y >= altoMin) && (y <= sy));
        bordeD = (x == anchoMax) && ((y >= altoMin) && (y <= sy));
    }
}
