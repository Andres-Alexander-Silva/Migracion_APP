package Ejercicio11;

class CasaCambio {
    double precioCompraDolar;
    double precioVentaDolar;
    double cantidadInicialPesos;
    double cantidadInicialDolar;
    double cantidadDolarComprado;
    double cantidadDolarVendido;
    double cantidadFinalPesos;
    double cantidadFinaldolares;
    boolean informacionValida;

    void calcularCambio(){
        cantidadFinalPesos = cantidadInicialPesos + (cantidadDolarVendido * precioVentaDolar) - (cantidadDolarComprado * precioCompraDolar);
        cantidadFinaldolares = (cantidadInicialDolar + cantidadDolarComprado) - cantidadDolarVendido;
        informacionValida = (cantidadFinalPesos > 0) && (cantidadFinaldolares > 0);
    }
}
