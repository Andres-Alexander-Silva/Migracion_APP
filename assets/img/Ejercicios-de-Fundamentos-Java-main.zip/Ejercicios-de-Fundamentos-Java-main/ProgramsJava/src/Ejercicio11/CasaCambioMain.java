package Ejercicio11;

import java.util.Scanner;

class CasaCambioMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        CasaCambio cc = new CasaCambio();

        cc.precioCompraDolar = c.nextDouble();
        cc.precioVentaDolar = c.nextDouble();
        cc.cantidadInicialPesos = c.nextDouble();
        cc.cantidadInicialDolar = c.nextDouble();
        cc.cantidadDolarComprado = c.nextDouble();
        cc.cantidadDolarVendido = c.nextDouble();

        cc.calcularCambio();

        System.out.println("Cantidad Final de Pesos: " + cc.cantidadFinalPesos);
        System.out.println("Cantidad Final de Dolares: " + cc.cantidadFinaldolares);
        System.out.println("Informacion valida: " + cc.informacionValida);
    }
}
