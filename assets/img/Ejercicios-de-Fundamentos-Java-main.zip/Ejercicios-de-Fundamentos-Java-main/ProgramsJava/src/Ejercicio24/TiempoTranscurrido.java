package Ejercicio24;

class TiempoTranscurrido {
    long num;
    long h1,m1,s1,h2,m2,s2;
    long sM1,sM2;
    double tiempoED;
    boolean hM,h,m,s;

    void calcularTiempoT(){
        h1 = (num / 1000000) % 100;
        m1 = (num / 100000000) % 100;
        s1 = (num / 100000000) / 100;
        h2 = num % 100;
        m2 = (num % 10000) / 100;
        s2 = (num % 1000000) / 10000;
        hM = h2 > h1;
        h = (h1 >= 0 && h1 < 24) && (h2 >= 0 && h2 < 24);
        m = (m1 >= 0 && m1 <= 59) && (m2 >= 0 && m2 <= 59);
        s = (s1 >= 0 && s1 <= 59) && (s2 >= 0 && s2 <= 59);
        sM1 = ((h1) * 3600) + ((m1) * 60) + s1;
        sM2 = ((h2) * 3600) + ((m2) * 60) + s2;
        tiempoED = (double) (sM2 - sM1) / 86400;
    }
}
