package Ejercicio24;

import java.util.Scanner;

class TiempoTranscurridoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TiempoTranscurrido tp = new TiempoTranscurrido();

        tp.num = c.nextLong();

        tp.calcularTiempoT();

        System.out.println("El tiempo transcurrido en días es : " + tp.tiempoED);
    }
}
