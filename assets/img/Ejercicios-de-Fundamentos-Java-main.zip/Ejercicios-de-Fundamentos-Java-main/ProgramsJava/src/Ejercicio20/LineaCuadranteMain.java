package Ejercicio20;

import java.util.Scanner;

class LineaCuadranteMain{
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        LineaCuadrante lc = new LineaCuadrante();

        lc.x1 = c.nextDouble();
        lc.y1 = c.nextDouble();
        lc.x2 = c.nextDouble();
        lc.y2 = c.nextDouble();

        lc.calcularCuadrante();

        System.out.println("Primer Cuadrante  : " + lc.primerC);
        System.out.println("Segundo Cuadrante : " + lc.segundoC);
        System.out.println("Tercer Cuadrante  : " + lc.tercerC);
        System.out.println("Cuarto Cuadrante  : " + lc.cuartoC);
        System.out.println("Un Cuadrante      : " + lc.unC);
        System.out.println("Dos Cuadrantes    : " + lc.dosC);
        System.out.println("Tres Cuadrantes   : " + lc.tresC);
    }
}
