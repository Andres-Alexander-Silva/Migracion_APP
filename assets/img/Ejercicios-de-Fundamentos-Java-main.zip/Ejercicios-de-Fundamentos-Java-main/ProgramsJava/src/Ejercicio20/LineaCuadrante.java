package Ejercicio20;

class LineaCuadrante {
    double x1,x2,y1,y2;
    boolean primerC,segundoC,tercerC,cuartoC;
    boolean unC,dosC,tresC;

    void calcularCuadrante(){
        primerC = (x1 >= 0 && y1 >= 0) || (x2 >= 0 && y2 >= 0);
        segundoC = (x1 < 0 && y1 > 0) || (x2 < 0 && y2 > 0);
        tercerC = (x1 < 0 && y1 < 0) || (x2 < 0 && y2 < 0);
        cuartoC = (x1 > 0 && y1 < 0) || (x2 > 0 && y2 < 0);
        tresC = (primerC && segundoC && tercerC) || (segundoC && tercerC && cuartoC) || (primerC && segundoC && cuartoC) || (primerC && tercerC && cuartoC);
        dosC = (primerC && segundoC) || (primerC && tercerC) || (primerC && cuartoC) || (segundoC && tercerC) || (segundoC && cuartoC) || (tercerC && cuartoC);
        unC = (primerC || segundoC || tercerC || cuartoC) == (segundoC == tercerC);
    }
}