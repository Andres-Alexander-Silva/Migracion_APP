package Ejercicio18;

import java.util.Scanner;

class PuntoCircunferenciaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        PuntoCircunferencia pc = new PuntoCircunferencia();

        pc.cx = c.nextDouble();
        pc.cy = c.nextDouble();
        pc.r = c.nextDouble();
        pc.x = c.nextDouble();
        pc.y = c.nextDouble();

        pc.calcularPuntoC();

        System.out.println("Punto Dentro  :" + pc.dentro);
        System.out.println("Punto Fuera    : " + pc.fuera);
        System.out.println("Punto En Borde : " + pc.borde);
    }
}
