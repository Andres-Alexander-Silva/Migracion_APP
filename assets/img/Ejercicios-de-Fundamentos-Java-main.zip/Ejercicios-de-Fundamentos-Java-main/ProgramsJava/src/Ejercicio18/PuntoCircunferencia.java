package Ejercicio18;

class PuntoCircunferencia {
    double cx,cy,r,x,y,d;
    boolean dentro,fuera,borde;

    void calcularPuntoC(){
        d = Math.sqrt(Math.pow((x - cx),2) + Math.pow((y - cy),2));
        dentro = d < r;
        fuera = d > r;
        borde = d == r;
    }
}
