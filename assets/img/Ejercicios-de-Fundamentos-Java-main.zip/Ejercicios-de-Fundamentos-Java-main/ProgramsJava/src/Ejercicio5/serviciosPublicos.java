package Ejercicio5;

class serviciosPublicos {
    //Declaration variables
    int lecturaAnterior;
    int lecturaActual;
    int tarifaMensual;
    int consumo;
    double sobrecargo;
    double agua;
    double aseo;
    double alcantarillado;
    double total;

    void igualMenosVeinte(){
        consumo = lecturaActual - lecturaAnterior;
        agua = consumo * tarifaMensual;
        aseo = (agua * 10) / 100;
        alcantarillado = (agua * 15) / 100;
        total = agua + aseo + alcantarillado;
    }

    void mayorAVeinte(){
        consumo = lecturaActual - lecturaAnterior;
        agua = consumo - 20;
        sobrecargo = (double) (tarifaMensual * 25) / 100;
        sobrecargo *= agua;
        agua = (consumo * tarifaMensual) + sobrecargo;
        aseo = (agua * 10) / 100;
        alcantarillado = (agua * 15) / 100;
        total = agua + aseo + alcantarillado;
    }
}
