package Ejercicio5;

import java.util.Scanner;

class serviciosPublicosMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        serviciosPublicos sp = new serviciosPublicos();

        sp.lecturaAnterior = c.nextInt();
        sp.lecturaActual = c.nextInt();
        sp.tarifaMensual = c.nextInt();

        sp.igualMenosVeinte();
        System.out.println("Consumo        : " + sp.consumo);

        while (sp.consumo <= 20){
            System.out.println("Agua           : " + sp.agua);
            System.out.println("Aseo           : " + sp.aseo);
            System.out.println("alcantarillado : " + sp.alcantarillado);
            System.out.println("Total          : " + sp.total);
            break;
        }

        sp.mayorAVeinte();

        while (sp.consumo > 20){
            System.out.println("Agua           : " + sp.agua);
            System.out.println("Aseo           : " + sp.aseo);
            System.out.println("alcantarillado : " + sp.alcantarillado);
            System.out.println("Total          : " + sp.total);
            break;
        }
    }
}
