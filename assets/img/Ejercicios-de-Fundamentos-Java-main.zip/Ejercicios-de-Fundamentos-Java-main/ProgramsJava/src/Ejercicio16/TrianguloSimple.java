package Ejercicio16;

class TrianguloSimple {
    int lado1,lado2,lado3;
    boolean equilatero,isosceles,escaleno;

    void calcularTriangulo(){
        equilatero = lado1 == lado2 && lado1 == lado3;
        isosceles = (lado1 == lado2 && lado2 != lado3 && lado1 != lado3) || (lado1 != lado2 && lado2 != lado3 && lado3 == lado1) || (lado1 != lado2 && lado2 == lado3 && lado3 != lado1);
        escaleno = lado1 != lado2 && lado1 != lado3 && lado3 != lado2;
    }
}
