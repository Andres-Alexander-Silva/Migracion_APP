package Ejercicio16;

import java.util.Scanner;

class TrinaguloSimpleMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TrianguloSimple trs = new TrianguloSimple();

        trs.lado1 = c.nextInt();
        trs.lado2 = c.nextInt();
        trs.lado3 = c.nextInt();

        trs.calcularTriangulo();

        System.out.println("Equilátero:" + trs.equilatero);
        System.out.println("Isósceles:" + trs.isosceles);
        System.out.println("Escaleno:" + trs.escaleno);
    }
}
