package Ejercicio1;

class Tienda {
	//VARIABLES DE ENTRADA
	int dineroInicial;
	int ingresosTotales;
	int egresosTotales;
	//VARIABLAS DE SALIDA
	double impuestos;
	double gananciasBrutas;
	double gananciasNetas;
	double dineroFinal;
	
	void algoritmo(){
		impuestos = (ingresosTotales*19)/100;
		gananciasBrutas = ingresosTotales - egresosTotales;
		gananciasNetas = gananciasBrutas - impuestos;
		dineroFinal = dineroInicial + gananciasNetas;
	}
}