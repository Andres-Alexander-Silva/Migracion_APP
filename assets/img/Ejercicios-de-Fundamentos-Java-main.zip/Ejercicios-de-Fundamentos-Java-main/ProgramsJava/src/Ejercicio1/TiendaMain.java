package Ejercicio1;

import java.util.Scanner;

class TiendaMain {
	public static void main(String args[]) {
		Scanner consola = new Scanner(System.in);
		Tienda tienda = new Tienda();
		
		System.out.println("Dinero Inicial: ");
		tienda.dineroInicial = consola.nextInt();
		System.out.println("Ingresos: ");
		tienda.ingresosTotales = consola.nextInt();
		System.out.println("Egresos: ");
		tienda.egresosTotales = consola.nextInt();
		
		tienda.algoritmo();
		
		System.out.println("Impuestos = " + tienda.impuestos);
		System.out.println("Ganancias Brutas = " + tienda.gananciasBrutas);
		System.out.println("Ganancias Netas = " + tienda.gananciasNetas);
		System.out.println("Dinero Final = " + tienda.dineroFinal);
	}
}
