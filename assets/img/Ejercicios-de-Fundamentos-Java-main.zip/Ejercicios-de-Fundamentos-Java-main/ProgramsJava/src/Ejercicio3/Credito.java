package Ejercicio3;

class Credito {
    //Declarar variables
    long montoCredito;
    int tasaInteres;
    int plazoMeses;
    int valorCuotaM;
    int valorMensualC;
    int valorMensualI;
    int gananciaTotal;

    //Funcion para calcular el credito
    void calcularCredito(){
        valorMensualC = (int) (montoCredito /  plazoMeses);
        valorMensualI = (int) ((montoCredito * tasaInteres) / 100);
        valorCuotaM = valorMensualC + valorMensualI;
        gananciaTotal = ((valorCuotaM * plazoMeses - (int) (montoCredito)) * 100) / (int) (montoCredito);
    }
}
