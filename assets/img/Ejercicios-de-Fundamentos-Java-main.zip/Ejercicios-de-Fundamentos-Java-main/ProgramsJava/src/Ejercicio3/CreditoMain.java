package Ejercicio3;

import java.util.Scanner;

class CreditoMain {
    public static void main(String args[]){
        Scanner entrada = new Scanner(System.in);
        Credito credito = new Credito();

        credito.montoCredito = entrada.nextInt();
        credito.tasaInteres = entrada.nextInt();
        credito.plazoMeses = entrada.nextInt();

        credito.calcularCredito();

        System.out.println("Valor Cuota Mensual: " + credito.valorCuotaM);
        System.out.println("Valor Mensual Capital: " + credito.valorMensualC);
        System.out.println("Valor Mensual Interes: " + credito.valorMensualI);
        System.out.println("Ganancia ToTal: " + credito.gananciaTotal + "%");
    }

}
