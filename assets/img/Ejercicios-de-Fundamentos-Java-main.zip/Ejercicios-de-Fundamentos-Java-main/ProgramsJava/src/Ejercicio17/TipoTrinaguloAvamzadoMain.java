package Ejercicio17;

import java.util.Scanner;

class TipoTrinaguloAvamzadoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TipoTrianguloAvnzado tta = new TipoTrianguloAvnzado();

        tta.x1 = c.nextDouble();
        tta.y1 = c.nextDouble();
        tta.x2 = c.nextDouble();
        tta.y2 = c.nextDouble();
        tta.x3 = c.nextDouble();
        tta.y3 = c.nextDouble();

        tta.calcularTrianguloA();

        System.out.println("Lado 1         : " + tta.distanciaPunto1);
        System.out.println("Lado 2         : " + tta.distanciaPunto2);
        System.out.println("Lado 3         : " + tta.distanciaPunto3);
        System.out.println("m1             : " + tta.pendientePunto1);
        System.out.println("m2             : " + tta.pendientePunto2);
        System.out.println("m3             : " + tta.pendientePunto3);
        System.out.println("Es Triángulo   : " + tta.esTriangulo);
        System.out.println("Es Equilátero  : " + tta.esEquilatero);
        System.out.println("Es Isósceles   : " + tta.esIsosceles);
        System.out.println("Es Escaleno    : " + tta.esEscaleno);
        System.out.println("Es Rectángulo  : " + tta.esRectangulo);
    }
}
