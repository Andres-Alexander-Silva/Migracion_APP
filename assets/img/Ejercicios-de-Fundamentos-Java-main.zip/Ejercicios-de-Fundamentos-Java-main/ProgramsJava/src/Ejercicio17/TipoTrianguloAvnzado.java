package Ejercicio17;

class TipoTrianguloAvnzado {
    double x1,x2,x3;
    double y1,y2,y3;
    double distanciaPunto1,distanciaPunto2,distanciaPunto3;
    double pendientePunto1,pendientePunto2,pendientePunto3;
    double pitagoras1,pitagoras2,pitagoras3;
    boolean esTriangulo,esEquilatero,esIsosceles;
    boolean esEscaleno,esRectangulo;

    void calcularTrianguloA(){
        distanciaPunto1 = Math.sqrt(Math.pow((x2 - x1),2) + Math.pow((y2 - y1),2));
        distanciaPunto2 = Math.sqrt(Math.pow((x3 - x1),2) + Math.pow((y3 - y1),2));
        distanciaPunto3 = Math.sqrt(Math.pow((x3 - x2),2) + Math.pow((y3 - y2),2));
        pendientePunto1 = (y2 - y1) / (x2 - x1);
        pendientePunto2 = (y3 - y1) / (x3 - x1);
        pendientePunto3 = (y3 - y2) / (x3 - x2);
        pitagoras1 = Math.pow((distanciaPunto2),2) + Math.pow((distanciaPunto3),2);
        pitagoras2 = Math.pow((distanciaPunto1),2) + Math.pow((distanciaPunto3),2);
        pitagoras3 = Math.pow((distanciaPunto1),2) + Math.pow((distanciaPunto2),2);
        esTriangulo = (pendientePunto1 != pendientePunto2) || (pendientePunto1 != pendientePunto3) || (pendientePunto2 != pendientePunto3);
        esEquilatero = (distanciaPunto1 == distanciaPunto2) && (distanciaPunto1 == distanciaPunto3) && (distanciaPunto2 == distanciaPunto3);
        esIsosceles = (distanciaPunto1 != distanciaPunto2) && (distanciaPunto1 == distanciaPunto3) || (distanciaPunto2 != distanciaPunto3) && (distanciaPunto1 == distanciaPunto2) || (distanciaPunto3 != distanciaPunto1) && (distanciaPunto3 == distanciaPunto2);
        esEscaleno = (distanciaPunto1 != distanciaPunto2) && (distanciaPunto1 != distanciaPunto3);
        esRectangulo = (Math.pow((distanciaPunto1),2) == pitagoras1) || (Math.pow((distanciaPunto2),2) == pitagoras2) || (Math.pow((distanciaPunto3),2) == pitagoras3);
    }
}
