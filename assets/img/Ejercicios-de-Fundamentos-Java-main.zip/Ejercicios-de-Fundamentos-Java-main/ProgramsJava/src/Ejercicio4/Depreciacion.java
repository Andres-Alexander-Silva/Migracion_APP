package Ejercicio4;

class Depreciacion {
    //Declarar vaiables
    int valorTotalDepreciar;
    int valorMensual;
    int agno = 12;
    double agnosDeprecion;

    //Funcion para calcular la depreciacion
    void calculoDepreciacion(){
        agnosDeprecion = (double) (valorTotalDepreciar / valorMensual);
        agnosDeprecion /= agno;
    }
}
