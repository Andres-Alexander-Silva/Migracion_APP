package Ejercicio4;

import java.util.Scanner;

class DepreciacionMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        Depreciacion d = new Depreciacion();

        d.valorTotalDepreciar = c.nextInt();
        d.valorMensual = c.nextInt();

        d.calculoDepreciacion();

        System.out.println("Años Depreciacion : " + d.agnosDeprecion);
    }
}
