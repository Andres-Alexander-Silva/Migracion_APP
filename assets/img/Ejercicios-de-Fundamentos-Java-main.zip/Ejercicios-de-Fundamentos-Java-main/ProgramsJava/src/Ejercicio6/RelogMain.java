package Ejercicio6;

import java.util.Scanner;

class RelogMain {
    public static void main(String[] args){
        Scanner c = new Scanner(System.in);
        Relog rg = new Relog();

        rg.tiempoSegundos = c.nextInt();
        rg.calcularHora();

        System.out.println("Tiempo en Segundos (<= 86399 == 23:59:59 ) : " + rg.formato);
    }
}
