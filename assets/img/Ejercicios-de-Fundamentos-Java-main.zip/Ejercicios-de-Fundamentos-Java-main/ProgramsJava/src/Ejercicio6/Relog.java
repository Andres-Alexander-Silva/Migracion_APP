package Ejercicio6;

class Relog {
    int tiempoSegundos;
    int horas;
    int minutos;
    int segundos;
    String textoHoras;
    String textoMinutos;
    String textoSegundos;
    String formato;

    void calcularHora() {
        horas = (tiempoSegundos / 3600);
        minutos = (tiempoSegundos - horas * 3600) / 60;
        segundos = tiempoSegundos - (horas * 3600 + minutos * 60);
        textoHoras = Integer.toString(horas);
        textoMinutos = Integer.toString(minutos);
        textoSegundos = Integer.toString(segundos);
        formato = textoHoras+":"+textoMinutos+":"+textoSegundos;
    }
}
