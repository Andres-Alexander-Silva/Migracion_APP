package Ejercicio2;

class Producto{
	//Variables de entrada 
	int cantidadInicial;
	int cantidadComprada;
	int cantidadVendida;
	int precioDeCompra;
	//Variables de salida
	int precioDeVenta;
	int gananciasBrutas;
	int gananciasNetas;
	int impuestos;
	int ingresos;
	int egresos;

	void operacion(){
		//Calcular producto
		precioDeVenta = (precioDeCompra * 29)/100;
		precioDeVenta += precioDeCompra;
		ingresos = precioDeVenta * cantidadVendida;
		egresos = precioDeCompra * cantidadComprada;
		gananciasBrutas = ingresos - egresos;
		impuestos = (ingresos *19)/100;
		gananciasNetas = gananciasBrutas - impuestos;	
	}
}