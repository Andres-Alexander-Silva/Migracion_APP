package Ejercicio2;

import java.util.Scanner;

class ProductoMain{
	public static void main(String args[]) {
		Scanner consola = new Scanner(System.in);
		Producto producto = new Producto();
		
		System.out.println("Cantidad Inicial: ");
		producto.cantidadInicial = consola.nextInt();
		System.out.println("Cantidad Comprada: ");
		producto.cantidadComprada = consola.nextInt();
		System.out.println("Cantidad Vendida: ");
		producto.cantidadVendida = consola.nextInt();
		System.out.println("precioDeCompra; ");
		producto.precioDeCompra = consola.nextInt();

		producto.operacion();

		System.out.println("Precio de Venta: " + producto.precioDeVenta);
		System.out.println("Ingresos: " + producto.ingresos);
		System.out.println("Egresos: " + producto.egresos);
		System.out.println("Ganancias Brutas: " + producto.gananciasBrutas);
		System.out.println("Impuestos: " + producto.impuestos);
		System.out.println("ganancias Netas: " + producto.gananciasNetas);
	}
}