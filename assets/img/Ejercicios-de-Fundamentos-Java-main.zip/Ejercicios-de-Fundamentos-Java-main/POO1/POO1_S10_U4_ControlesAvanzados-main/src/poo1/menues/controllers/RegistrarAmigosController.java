package poo1.menues.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class RegistrarAmigosController {

	@FXML
	public void handleRegistrarAmigoButton(ActionEvent event) {
		System.out.println("Registrando amigo");
	}
	
	
	
	
	
//	private LogicaMenues logica;
	
//	@FXML 
//	private MenuBar myMenuBar;
	
//	public RegistrarAmigosController() {
//		logica = new LogicaMenues();
//	}
	
//	@FXML
//	public void handleIncluirAmigoMenu(ActionEvent event) {
//		logica.handleIncluirAmigoMenu(event, myMenuBar);
//	}
//	
//	@FXML
//	public void handleIncluirMascotaMenu(ActionEvent event) {
//		logica.handleIncluirMascotaMenu(event, myMenuBar);		
//	}
//	
//	@FXML
//	public void handleInicioMenu(ActionEvent event) {
//		logica.handleInicioMenu(event, myMenuBar);		
//	}
	
}
