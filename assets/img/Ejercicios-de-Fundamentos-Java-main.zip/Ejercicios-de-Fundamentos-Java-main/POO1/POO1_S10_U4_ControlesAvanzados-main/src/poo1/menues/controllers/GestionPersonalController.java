package poo1.menues.controllers;

public class GestionPersonalController {

//	private LogicaMenues logica;
//	
//	@FXML 
//	private MenuBar myMenuBar;
//	
//	public GestionPersonalController() {
//		logica = new LogicaMenues();
//	}
//	
//	@FXML
//	public void handleIncluirAmigoMenu(ActionEvent event) {
//		logica.handleIncluirAmigoMenu(event, myMenuBar);
//	}
//	
//	@FXML
//	public void handleIncluirMascotaMenu(ActionEvent event) {
//		logica.handleIncluirMascotaMenu(event, myMenuBar);		
//	}
//	
//	@FXML
//	public void handleInicioMenu(ActionEvent event) {
//		logica.handleInicioMenu(event, myMenuBar);		
//	}

}
