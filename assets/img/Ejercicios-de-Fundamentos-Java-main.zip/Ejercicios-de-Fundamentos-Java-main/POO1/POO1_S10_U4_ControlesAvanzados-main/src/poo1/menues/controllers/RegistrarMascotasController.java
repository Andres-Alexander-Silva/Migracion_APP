package poo1.menues.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class RegistrarMascotasController {

	@FXML
	public void handleRegistrarMascotaButton(ActionEvent event) {
		System.out.println("Registrando mascota");
	}
	
	
	
	
//	private LogicaMenues logica;
	
//	@FXML 
//	private MenuBar myMenuBar;
	
//	public RegistrarMascotasController() {
//		logica = new LogicaMenues();
//	}
	
//	@FXML
//	public void handleIncluirAmigoMenu(ActionEvent event) {
//		logica.handleIncluirAmigoMenu(event, myMenuBar);
//	}
//	
//	@FXML
//	public void handleIncluirMascotaMenu(ActionEvent event) {
//		logica.handleIncluirMascotaMenu(event, myMenuBar);		
//	}
//	
//	@FXML
//	public void handleInicioMenu(ActionEvent event) {
//		logica.handleInicioMenu(event, myMenuBar);		
//	}
	
}
