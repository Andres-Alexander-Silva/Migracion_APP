package poo1.elecciones.controllers;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import poo1.colegio.fachada.Colegio;

public class ActualizarPersoneroController {
	 @FXML private TextField txtApellido, txtGrado, txtLema, txtNombre, txtNunTargeton;
	 private Colegio cObj;
	 
	 public ActualizarPersoneroController() {
			cObj = Colegio.obtenerInstancia();
		}
	 
	 public void actualizarDatos(ActionEvent e) {
		 String nombre = txtNombre.getText();
		 String apellido = txtApellido.getText();
		 String grado = txtGrado.getText();
		 String lema = txtLema.getText();
		 int numTargeton = Integer.parseInt(txtNunTargeton.getText());
		 
		 cObj.actualizarInfoPersonero(numTargeton, nombre, apellido, lema, grado);
		 
		 txtNombre.clear();
		 txtApellido.clear();
		 txtGrado.clear();
		 txtLema.clear();
	 }
	    
	 public void buscarPersonero(ActionEvent e) {
		 int numTargeton = Integer.parseInt(txtNunTargeton.getText());
		 txtNombre.setText(cObj.mostrarInfoPersonero(numTargeton).getNombre());
		 txtApellido.setText(cObj.mostrarInfoPersonero(numTargeton).getApellido());
		 txtGrado.setText(cObj.mostrarInfoPersonero(numTargeton).getGrado());
		 txtLema.setText(cObj.mostrarInfoPersonero(numTargeton).getLema());
		 
	 }
	 
	 public void volverAInicio(ActionEvent e) {
		 Stage stage = obtenerStage(e);
			stage.close();
			try {
				FXMLLoader loader = new FXMLLoader(
						getClass().getResource("/poo1/elecciones/views/PrincipalView.fxml"));
				Pane root = loader.load();

				Scene scene = new Scene(root);
				stage.setScene(scene);
				stage.show();
			} catch (IOException ev) {
				ev.printStackTrace();
			}
	 }
	 
	 private Stage obtenerStage(ActionEvent event) {
			Node node = (Node) event.getSource();
			Stage stage = (Stage) node.getScene().getWindow();
			return stage;
		}
}