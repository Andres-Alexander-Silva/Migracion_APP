package poo1.elecciones.controllers;

import java.io.IOException;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import poo1.colegio.fachada.Colegio;

public class RegistrarVotoController {
	@FXML private TextField txtVotos;
	private Colegio colegioObj;
	
	public RegistrarVotoController() {
		colegioObj = Colegio.obtenerInstancia();
	}
	
	public void votar() {
		if (txtVotos.getText() != "") {
			int voto = Integer.parseInt(txtVotos.getText());
		colegioObj.agregarVoto(voto);
		
		JOptionPane.showMessageDialog(null, "El voto se a registrado satisfactoriamente");
		
		txtVotos.clear();
		} else {JOptionPane.showMessageDialog(null, "El voto no se a registrado intentalo de nuevo");}
		
	}
	
	public void votaEnBlanco() {
		colegioObj.agregarVotoBlanco();
		JOptionPane.showMessageDialog(null, "El voto en blanco se a registrado satisfactoriamente");
	}
	
	@FXML
	public void volverInicio(ActionEvent e) {
		Stage stage = obtenerStage(e);
		stage.close();
		try {
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/poo1/elecciones/views/PrincipalView.fxml"));
			Pane root = loader.load();

			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException ev) {
			ev.printStackTrace();
		}
	}
	private Stage obtenerStage(ActionEvent event) {
		Node node = (Node) event.getSource();
		Stage stage = (Stage) node.getScene().getWindow();
		return stage;
	}
}