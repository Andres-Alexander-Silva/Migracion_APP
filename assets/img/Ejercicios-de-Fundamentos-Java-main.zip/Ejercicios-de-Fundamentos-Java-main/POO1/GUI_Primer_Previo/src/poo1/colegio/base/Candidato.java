package poo1.colegio.base;

public class Candidato {

	private String nombre, apellido, grado, lema;
	private int numeroTarjeton, votos;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getGrado() {
		return grado;
	}
	public void setGrado(String grado) {
		this.grado = grado;
	}
	public String getLema() {
		return lema;
	}
	public void setLema(String lema) {
		this.lema = lema;
	}
	public int getNumeroTarjeton() {
		return numeroTarjeton;
	}
	public void setNumeroTarjeton(int numeroTarjeton) {
		this.numeroTarjeton = numeroTarjeton;
	}
	public int getVotos() {
		return votos;
	}
	public void setVotos(int votos) {
		this.votos = votos;
	}
}