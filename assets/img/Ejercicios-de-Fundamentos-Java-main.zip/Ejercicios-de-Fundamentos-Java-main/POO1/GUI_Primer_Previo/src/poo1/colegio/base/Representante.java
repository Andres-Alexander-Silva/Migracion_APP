package poo1.colegio.base;

public class Representante extends Candidato {

	private String nombreFormulaEstudiante;
	private String grupo;

	public String getGrupo() {
		return grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public String getNombreFormulaEstudiante() {
		return nombreFormulaEstudiante;
	}

	public void setNombreFormulaEstudiante(String nombreFormulaEstudiante) {
		this.nombreFormulaEstudiante = nombreFormulaEstudiante;
	}
	
}
