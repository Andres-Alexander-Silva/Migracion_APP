package poo1.elecciones.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import poo1.colegio.fachada.Colegio;

public class GenerarReportesController implements Initializable {
	@FXML private ComboBox<String> cmbReporte;
	@FXML private TextArea txtAInfo;
	private Colegio colegioObj;
	
	public GenerarReportesController() {
		colegioObj = Colegio.obtenerInstancia();
	}
	
	public void generarReporte(ActionEvent e) {
		String inf = "";
		String Reporte = cmbReporte.getValue();
		switch (Reporte) {
		case "Total votos por candidatos":
			 inf = colegioObj.imprimirVotosPorCandidato();
			break;
		case "Representante y Personero Elegidos":
			inf = colegioObj.imprimirCandidatosGanadores();
			break;
		case "Poblacion Electoral":
			inf = colegioObj.imprimirPoblacionElectoral();
			break;
		}
		
		txtAInfo.setText(inf);
	}
	
	public void limpiar() {
		txtAInfo.clear();
	}
	
	@FXML
	public void volverInicio(ActionEvent e) {
		Stage stage = obtenerStage(e);
		stage.close();
		try {
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/poo1/elecciones/views/PrincipalView.fxml"));
			Pane root = loader.load();

			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException ev) {
			ev.printStackTrace();
		}
	}
	private Stage obtenerStage(ActionEvent event) {
		Node node = (Node) event.getSource();
		Stage stage = (Stage) node.getScene().getWindow();
		return stage;
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ArrayList<String> listaReporte = new ArrayList<>();
		listaReporte.add("Total votos por candidatos");
		listaReporte.add("Representante y Personero Elegidos");
		listaReporte.add("Poblacion Electoral");
		cmbReporte.getItems().addAll(listaReporte);
	}
}
