package poo1.elecciones.controllers;

import java.io.IOException;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import poo1.colegio.fachada.Colegio;

public class RegistrarRepresentanteController {
	@FXML private TextField txtNombre;
	@FXML private TextField txtApellido;
	@FXML private TextField txtNumTarjeton;
	@FXML private TextField txtGrado;
	@FXML private TextField txtLema;
	@FXML private TextField txtFormula;
	@FXML private TextField txtGrupo;
	
	private Colegio colegioObj;
	
	public RegistrarRepresentanteController() {
		colegioObj = Colegio.obtenerInstancia();
	}
	
	public void registrarRepresentante(ActionEvent e) {
		String nombre = txtNombre.getText();
		String apellido = txtApellido.getText();
		int numTarjeton = Integer.parseInt(txtNumTarjeton.getText());
		String grado = txtGrado.getText();
		String lema = txtLema.getText();
		String formula = txtFormula.getText();
		String grupo = txtGrupo.getText();
		
		colegioObj.agregarCandidatoRepresentante(nombre, apellido, grado, grupo, lema, numTarjeton, formula);
		
		JOptionPane.showMessageDialog(null, "El representante se agreg� satisfactoriamente");
		
		txtNombre.clear();
		txtApellido.clear();
		txtNumTarjeton.clear();
		txtGrado.clear();
		txtLema.clear();
		txtFormula.clear();
		txtGrupo.clear();
	}
	
	@FXML
	public void volverInicio(ActionEvent e) {
		Stage stage = obtenerStage(e);
		stage.close();
		try {
			FXMLLoader loader = new FXMLLoader(
					getClass().getResource("/poo1/elecciones/views/PrincipalView.fxml"));
			Pane root = loader.load();

			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (IOException ev) {
			ev.printStackTrace();
		}
	}
	private Stage obtenerStage(ActionEvent event) {
		Node node = (Node) event.getSource();
		Stage stage = (Stage) node.getScene().getWindow();
		return stage;
	}
}