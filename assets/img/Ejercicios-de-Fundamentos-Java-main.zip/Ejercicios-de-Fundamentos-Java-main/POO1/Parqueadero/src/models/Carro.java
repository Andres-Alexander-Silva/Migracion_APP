package models;

public class Carro extends Vehiculo {
	
}
