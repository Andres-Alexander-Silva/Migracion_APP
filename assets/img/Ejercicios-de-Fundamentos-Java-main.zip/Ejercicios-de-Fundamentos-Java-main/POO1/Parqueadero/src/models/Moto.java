package models;

public class Moto extends Vehiculo {

}
