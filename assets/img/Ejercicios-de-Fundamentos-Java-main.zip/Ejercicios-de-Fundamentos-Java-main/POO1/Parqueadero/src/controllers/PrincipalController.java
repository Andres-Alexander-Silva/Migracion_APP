package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import fachada.Parqueadero;

public class PrincipalController implements Initializable{
	@FXML private ComboBox<String> cmbTipo;
    @FXML private Label lbInformacion;
    @FXML private TextField txtDia;
    @FXML private TextField txtModelo;
    @FXML private TextField txtPlaca;
    @FXML private TextField txtCarros;
    @FXML private TextField txtMotos;
    private Parqueadero p;

    public PrincipalController() {
    	p = Parqueadero.obtenerInstancia();
    }
    
    public void agregarVehiculo(ActionEvent event) {
    	String placa = txtPlaca.getText();
    	int modelo = Integer.parseInt(txtModelo.getText());
    	int dia = Integer.parseInt(txtDia.getText());
    	String tipo = cmbTipo.getValue();
    	
    	p.agregarVehiculo(tipo, modelo, dia, placa);
    	
    	String cantMotos = String.valueOf(p.obtenerCantidadDeMotos());
    	String cantCarros = String.valueOf(p.obtenerCantidadDeCarros());
    	
    	txtMotos.setText(cantMotos);
    	txtCarros.setText(cantCarros);
    	
    	txtPlaca.clear();
    	txtModelo.clear();
    	txtDia.clear();
    }

    public void reiniciarValores(ActionEvent event) {
    	txtPlaca.clear();
    	txtModelo.clear();
    	txtDia.clear();
    	
    	p.reiniciar();
    	
    	txtMotos.clear();
    	txtCarros.clear();
    }

    public void totalizarCostos(ActionEvent event) {
    	lbInformacion.setText(p.obtenerPrecioVehiculos());
    }

    public void vaciarCampo(ActionEvent event) {
    	txtPlaca.clear();
    	txtModelo.clear();
    	txtDia.clear();
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	ArrayList<String> listTipo = new ArrayList<String>();
    	listTipo.add("Carro");
    	listTipo.add("Moto");
    	cmbTipo.getItems().addAll(listTipo);
    }
}
