package fachada;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import models.Vehiculo;
import models.Carro;
import models.Moto;

public class Parqueadero {
	private ArrayList<Vehiculo> vehiculos;
	private static Parqueadero instancia;
	private int contCarros, contMotos;
	
	private Parqueadero() {
		vehiculos = new ArrayList<Vehiculo>();
	}
	
	public static Parqueadero obtenerInstancia() {
		if (instancia == null) {
			instancia = new Parqueadero();
		}
		return instancia;
	}
	
	public void reiniciar() {
		vehiculos.clear();
		contCarros = 0;
		contMotos = 0;
	}
	
	public boolean obtenerPlacaRepetida(String placa) {
		boolean placaRepetida = false;
		int contador = 0;
		for (int i = 0; i < vehiculos.size(); i++) {
			if (vehiculos.get(i).getPlaca().equals(placa)) {
				contador++;
			}
		}
		if (contador != 0) {
			placaRepetida = true;
		}
		return placaRepetida;
	}
	
	public void agregarVehiculo(String tipo, int modelo, int dia, String placa) {
		if (obtenerPlacaRepetida(placa) == false) {
			if (tipo.equals("Carro") && placa.length() == 6) {
				Carro c = new Carro();
				c.setPlaca(placa);
				c.setModelo(modelo);
				c.setDia(dia);
				
				vehiculos.add(c);
				contCarros++;
				
				System.out.println("Agregado Correctamente el carro");
			}
			if (tipo.equals("Moto") && placa.length() == 5) {
				Moto m = new Moto();
				m.setPlaca(placa);
				m.setDia(dia);
				m.setModelo(modelo);
				
				vehiculos.add(m);
				contMotos++;
				
				System.out.println("Agregado Correctamente la moto");
			}
		} else {
			JOptionPane.showMessageDialog(null, "La placa que estas tratando de ingresar ya esta registrada");
		}
	}
	
	public String obtenerPrecioVehiculos() {
		String infoTotal = "";
		int precioCarro = 0;
		int precioMoto = 0;
		int totalMotos = 0, totalCarros = 0;
				
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo veh = vehiculos.get(i);
		
			if(veh instanceof Carro) {
				
				
				if (veh.getModelo() < 2012) {
					precioCarro += 2000;
				}
				if (veh.getModelo() >= 2012 && veh.getModelo() < 2020) {
					precioCarro += 2500; 
				}
				if (veh.getModelo() >= 2020) {
					int adicion = (2500 * 20) / 100;
					precioCarro +=  2500 + adicion;
				}
				
				totalCarros += precioCarro;
				
			}
			else if(veh instanceof Moto) {
			
				if (veh.getModelo() < 2012) {
					precioMoto += 1000;
				}
				
				if (veh.getModelo() >= 2012 && veh.getModelo() < 2020) {
					precioMoto += 1200;
				}
				
				if (veh.getModelo() >= 2020) {
					int adicion = (1200 * 10) / 100;
					precioMoto += 1200 + adicion;
				}
				
				totalMotos = precioMoto;
			}
		}
		
		int totalVehiculos = obtenerCantidadDeCarros() + obtenerCantidadDeMotos();
		int totalRecaudado = totalMotos + totalCarros;
		
		infoTotal = "El total de carros es " + obtenerCantidadDeCarros() + " con un valor de " + totalCarros + 
				", el total de motos es " + obtenerCantidadDeMotos() + " para un valor de " + totalMotos + 
				", el total de vehiculos fue " + totalVehiculos + " y el total recaudado " + totalRecaudado;
		
		return infoTotal;
	}
	
	public int obtenerCantidadDeCarros() {
		return contCarros;
	}
	
	public int obtenerCantidadDeMotos() {
		return contMotos;
	}
}