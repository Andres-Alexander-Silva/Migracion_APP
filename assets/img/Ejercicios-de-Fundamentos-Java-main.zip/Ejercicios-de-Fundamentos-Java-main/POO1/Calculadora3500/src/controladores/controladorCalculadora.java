package controladores;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class controladorCalculadora {
	@FXML private TextField valor1;
	@FXML private TextField valor2;
	@FXML private TextField resultado;
	
	public void sumar(ActionEvent ev) {
		int num1 = Integer.parseInt(valor1.getText());
		int num2 = Integer.parseInt(valor2.getText());
		
		int suma = num1 + num2;
		String strSuma = Integer.toString(suma);
		resultado.setText(strSuma);
	}
	public void restar() {
		int num1 = Integer.parseInt(valor1.getText());
		int num2 = Integer.parseInt(valor2.getText());
		
		int resta = num1 - num2;
		String strResta = Integer.toString(resta);
		resultado.setText(strResta);
	}
	public void multi() {
		int num1 = Integer.parseInt(valor1.getText());
		int num2 = Integer.parseInt(valor2.getText());
		
		int multi = num1 * num2;
		String strMulti = Integer.toString(multi);
		resultado.setText(strMulti);
	}
	public void division() {
		int num1 = Integer.parseInt(valor1.getText());
		int num2 = Integer.parseInt(valor2.getText());
		
		if (num2 == 0) {}
		else {
			int divi = num1 / num2;
			String strMulti = Integer.toString(divi);
			resultado.setText(strMulti);
		}
	}
	public void borrar(){
		this.valor1.clear();
		this.valor2.clear();
	}
}