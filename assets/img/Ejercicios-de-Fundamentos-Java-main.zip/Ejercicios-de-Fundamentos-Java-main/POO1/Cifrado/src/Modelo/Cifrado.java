package Modelo;

public class Cifrado {
	private char letras[];
    private char alfabeto[];
    
    public Cifrado(){}

    public Cifrado(String mensaje){
    	this.alfabeto = new char[]{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        this.letras = new char[mensaje.length()];
        for (int i = 0; i < this.letras.length; i++){
            this.letras[i] = mensaje.charAt(i);
        }
    }

    public char[] getLetras() {
        return letras;
    }

    public char[] getAlfabeto() {
        return alfabeto;
    }

    @Override
    public String toString(){
        String ms = "";
        for (char dato : this.letras){
            ms += dato + "\t";
        }
        return ms;
    }

    public Cifrado getEcriptar(int salto){
        Cifrado nMsg = new Cifrado();
        nMsg.letras = new char[this.letras.length];
        for (int i = 0; i < nMsg.letras.length; i++){
            for (int j = 0; j < getAlfabeto().length; j++){
                if(this.letras[i] == getAlfabeto()[j]){
                    if (salto < 0){
                        nMsg.letras[i] = getAlfabeto()[Math.abs((j+salto+getAlfabeto().length)%getAlfabeto().length)];
                    } else {
                        nMsg.letras[i] = getAlfabeto()[(j+salto)%getAlfabeto().length];
                    }
                }
            }
        }
        return nMsg;
    }
}
