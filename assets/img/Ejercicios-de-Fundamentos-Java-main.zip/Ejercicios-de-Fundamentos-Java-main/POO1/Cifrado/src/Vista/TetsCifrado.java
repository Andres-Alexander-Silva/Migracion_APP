package Vista;

import Modelo.Cifrado;

public class TetsCifrado {

	public static void main(String[] args) {
		String msg = "MADARME";
        Cifrado c = new Cifrado(msg);
        System.out.println(c);
        Cifrado enc = c.getEcriptar(1000);
        System.out.println(enc);
	}

}
