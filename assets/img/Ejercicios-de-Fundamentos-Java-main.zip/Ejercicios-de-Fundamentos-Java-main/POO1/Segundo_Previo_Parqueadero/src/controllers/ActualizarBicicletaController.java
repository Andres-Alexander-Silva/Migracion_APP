package controllers;

import fachada.Parqueadero;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import models.Bicicleta;

public class ActualizarBicicletaController {
	@FXML private TextField txtCCPropietario;
    @FXML private TextField txtColor;
    @FXML private TextField txtMarca;
    @FXML private Label lbEsPrestada;
    private Parqueadero p;
	
	public ActualizarBicicletaController() {
		p = Parqueadero.obtenerInstancia();
	}

    @FXML
    public void buscarPropietario(ActionEvent event) {
    	String ccPropietario = txtCCPropietario.getText();
    	
    	Bicicleta bic = p.mostrarInfoBicicleta(ccPropietario);
    	
    	txtMarca.setText(bic.getMarca());
    	txtColor.setText(bic.getColor());
    	lbEsPrestada.setText("La bicicleta es prestada? "+bic.isEsPrestada());
    }
    
    public void actualizarBicicleta(ActionEvent event) {
    	String ccPropietario = txtCCPropietario.getText();
    	String marca = txtMarca.getText();
    	String color = txtColor.getText();
    	
    	p.actualizarDatosBicicleta(ccPropietario, marca, color);
    	
    	txtMarca.clear();
    	txtColor.clear();
    }
}
