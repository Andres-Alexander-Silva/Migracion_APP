package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import fachada.Parqueadero;

public class RegistrarMotoController implements Initializable {
	@FXML private ComboBox<Integer> cmbCilindros;
    @FXML private ComboBox<String> cmbTipo;
    @FXML private TextField txtMarca;
    @FXML private TextField txtPlaca;
    @FXML private TextField txtHoraIngreso;
    private Parqueadero p;
    
    public RegistrarMotoController() {
    	p = Parqueadero.obtenerInstancia();
    }

    public void registrarMoto(ActionEvent event) {
    	String placa = txtPlaca.getText();
    	String marca = txtMarca.getText();
    	int cilindros = cmbCilindros.getValue();
    	String tipo = cmbTipo.getValue();
    	
    	try {
    		p.agregarVehiculos("Moto",placa,null,marca,0,cilindros,tipo,null,null,false);
    		JOptionPane.showMessageDialog(null, "La moto se agrego exitosamente");
    	} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "No se pudo registrar la moto");
		}
    	
    	txtPlaca.clear();
    	txtMarca.clear();
    }
    
    public void cancelarRegistro(ActionEvent event) {
    	txtPlaca.clear();
    	txtMarca.clear();
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	ArrayList<Integer> listCilindros = new ArrayList<>();
    	ArrayList<String> listTipo = new ArrayList<>();
    	
    	listCilindros.add(200);
    	listCilindros.add(300);
    	listCilindros.add(400);
    	
    	listTipo.add("Urbana");
    	listTipo.add("Carretera");
    	listTipo.add("Campo");
    	
    	cmbCilindros.getItems().addAll(listCilindros);
    	cmbTipo.getItems().addAll(listTipo);
    }
}
