package controllers;

import javax.swing.JOptionPane;

import fachada.Parqueadero;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;

public class RegistrarBiciletaController {
    @FXML private CheckBox chbSi;
    @FXML private TextField txtCCPropietario;
    @FXML private TextField txtColor;
    @FXML private TextField txtMarca;
    private Parqueadero p;
    
    public RegistrarBiciletaController() {
    	p = Parqueadero.obtenerInstancia();
    }

    public void cancelarRegistro(ActionEvent event) {
    	txtCCPropietario.clear();
    	txtColor.clear();
    	txtMarca.clear();
    }

    public void registrarBicicleta(ActionEvent event) {
    	String ccPropietario = txtCCPropietario.getText();
    	String color = txtColor.getText();
    	String marca = txtMarca.getText();
    	boolean esPrestado = chbSi.isSelected();
    	
    	try {
    		p.agregarVehiculos("Bicicleta", null, null, marca, 0, 0, null, ccPropietario, color, esPrestado);
    		JOptionPane.showMessageDialog(null, "La bicicleta se a agrego exitosamente");
    	} catch (Exception e) {
    		JOptionPane.showMessageDialog(null, "No se pudo registrar la bicicleta");
    	}
    	
    	txtCCPropietario.clear();
    	txtColor.clear();
    	txtMarca.clear();
    }

}
