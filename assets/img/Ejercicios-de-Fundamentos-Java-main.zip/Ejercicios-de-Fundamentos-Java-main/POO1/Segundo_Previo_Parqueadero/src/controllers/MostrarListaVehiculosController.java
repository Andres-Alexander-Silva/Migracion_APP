package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import models.Vehiculo;
import fachada.Parqueadero;

public class MostrarListaVehiculosController implements Initializable {
	@FXML private ComboBox<String> cmbTipo;
	@FXML private ComboBox<String> cmbCondicion;
	@FXML private ListView<String> listVehiculos;
	@FXML private ListView<Vehiculo> listaCondicion;
	@FXML private TextField txtCantHoras;
	private Parqueadero p;
	
	public MostrarListaVehiculosController() {
		p = Parqueadero.obtenerInstancia();
	}

    public void mostrarListaVehiculos(ActionEvent event) {
    	String tipo = cmbTipo.getValue();
    	if (tipo.equals("Carro")) {
    		ArrayList<String> listCarro = p.obtenerListaCarros();
    		listVehiculos.getItems().clear();
    		listVehiculos.getItems().addAll(listCarro);
    	} else if (tipo.equals("Moto")) {
    		ArrayList<String> listMoto = p.obtenerListaMotos();
    		listVehiculos.getItems().clear();
    		listVehiculos.getItems().addAll(listMoto);
    	} else if (tipo.equals("Bicicleta")) {
    		System.out.println("v");
    		ArrayList<String> listBicicleta = p.obtenerListaBicicleta();
    		System.out.println(listBicicleta.size());
    		listVehiculos.getItems().clear();
    		listVehiculos.getItems().addAll(listBicicleta);
    	}
    }
    
    public void mostrarCondicionVEhiculos(ActionEvent e) {
    	String condicion = cmbCondicion.getValue();
    	String tipo = cmbTipo.getValue();
    	int cantHoras = Integer.parseInt(txtCantHoras.getText());
    	ArrayList<Vehiculo> listaVe = p.mostrarListaVehiculosCondicion(tipo, condicion, cantHoras);
    	listaCondicion.getItems().clear();
    	listaCondicion.getItems().addAll(listaVe);
    	System.out.println("Entro al evento");
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	ArrayList<String> listVehiculo = new ArrayList<>();
    	ArrayList<String> listaVehiculosCondicion = new ArrayList<>();
    	listaVehiculosCondicion.add("<");
    	listaVehiculosCondicion.add(">");
    	listaVehiculosCondicion.add("=");
    	listVehiculo.add("Carro");
    	listVehiculo.add("Moto");
    	listVehiculo.add("Bicicleta");
    	cmbTipo.getItems().addAll(listVehiculo);
    	cmbCondicion.getItems().addAll(listaVehiculosCondicion);
    }
}
