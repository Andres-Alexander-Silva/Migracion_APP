package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class MenuBarController {
	@FXML private MenuBar myMenu;
	
	public void mostrarRegistrarCarro(ActionEvent event) {
		abrirVentana(event,"RegistrarCarroView",myMenu);
	}
	
	public void mostrarRegistrarMoto(ActionEvent event) {
		abrirVentana(event,"RegistrarMotoView",myMenu);
	}
	
	public void mostrarListaDeVehiculos(ActionEvent event) {
		abrirVentana(event,"MostrarListaVehiculosView",myMenu);
	}
	
	public void mostrarRegistroBicicleta(ActionEvent event) {
		abrirVentana(event,"RegistrarBicicletaView",myMenu);
	}
	
	public void mostrarInicio(ActionEvent event) {
		abrirVentana(event,"PrincipalViews",myMenu);
	}
	
	public void actualizarBicicleta(ActionEvent event) {
		abrirVentana(event,"ActualizarBicicletaView",myMenu);
	}
	
	public void registrarSalidaVehiculos(ActionEvent event) {
		abrirVentana(event,"RegistrarSalidaView", myMenu);
	}
	
	public void mostrarListaPorPlaca(ActionEvent evenet) {
		abrirVentana(evenet, "MostrarListaPorPlaca", myMenu);
	}
	
	public void mostrarListaPorTiempo(ActionEvent event) {
		abrirVentana(event, "MostrarListarPorHoraParqueo", myMenu);
	}
	
	public void mostrarVentanaListaBicicletas(ActionEvent event) {
		abrirVentana(event, "MostrarListaBicicletas", myMenu);
	}
	
	public void abrirVentana(ActionEvent event, String vista, MenuBar myMenuBar) {
		try {
			BorderPane root = (BorderPane) FXMLLoader.load(getClass().getResource("/views/"+vista+".fxml"));
			Stage stage = (Stage) myMenuBar.getScene().getWindow();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
