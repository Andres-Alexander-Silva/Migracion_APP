package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import fachada.Parqueadero;

public class RegistrarCarroController implements Initializable {
	@FXML private ComboBox<Integer> cmbCilindros;
    @FXML private ComboBox<Integer> cmbNumPuertas;
    @FXML private TextField txtMarca;
    @FXML private TextField txtModelo;
    @FXML private TextField txtPlaca;
    private Parqueadero p;
    
    public RegistrarCarroController() {
    	p = Parqueadero.obtenerInstancia();
    }

    public void registrarCarro(ActionEvent event) {
    	String placa = txtPlaca.getText();
    	String marca = txtMarca.getText();
    	String modelo = txtModelo.getText();
    	int cilindros = cmbCilindros.getValue();
    	int numPuertas = cmbNumPuertas.getValue();
   
    	try {
    		p.agregarVehiculos("Carro", placa, modelo, marca, numPuertas, cilindros, null, null, null, false);
    		JOptionPane.showMessageDialog(null, "EL carro se agrego exitosamente");
    	} catch (Exception e) {
    		JOptionPane.showMessageDialog(null, "No se pudo registrar el carro");
    	}
    	
    	txtPlaca.clear();
    	txtMarca.clear();
    	txtModelo.clear();
    }
    
    public void cancelarRegistro(ActionEvent event) {
    	txtPlaca.clear();
    	txtMarca.clear();
    	txtModelo.clear();
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	ArrayList<Integer> listCilindros = new ArrayList<>();
    	ArrayList<Integer> listNumPuertas = new ArrayList<>();
    	
    	listCilindros.add(1000);
    	listCilindros.add(1200);
    	listCilindros.add(1500);
    	listCilindros.add(2000);
    	
    	listNumPuertas.add(2);
    	listNumPuertas.add(3);
    	listNumPuertas.add(4);
    	listNumPuertas.add(5);
    	
    	cmbCilindros.getItems().addAll(listCilindros);
    	cmbNumPuertas.getItems().addAll(listNumPuertas);
    }
}
