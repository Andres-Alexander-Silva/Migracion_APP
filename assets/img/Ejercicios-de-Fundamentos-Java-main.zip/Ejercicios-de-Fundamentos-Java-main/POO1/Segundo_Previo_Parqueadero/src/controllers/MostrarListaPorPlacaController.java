package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import fachada.Parqueadero;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import models.Vehiculo;

public class MostrarListaPorPlacaController implements Initializable {
	@FXML private CheckBox chbEmpiza;
    @FXML private ComboBox<String> cmbTipo;
    @FXML private ListView<Vehiculo> listvListaPlacas;
    @FXML private TextField txtPlacaBuscar;
    private Parqueadero p;
    
    public MostrarListaPorPlacaController() {
    	p = Parqueadero.obtenerInstancia();
    }

    public void listarPorPlaca(ActionEvent event) {
    	String tipoV = cmbTipo.getValue();
    	String placaB = txtPlacaBuscar.getText();
    	boolean isEmpieza = chbEmpiza.isSelected();
    	
    	ArrayList<Vehiculo> listaVehiculosPlaca = p.obtenerListaPorPlaca(placaB, tipoV, isEmpieza);
    	listvListaPlacas.getItems().clear();
    	listvListaPlacas.getItems().addAll(listaVehiculosPlaca);
    	
    	txtPlacaBuscar.clear();
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
    	ArrayList<String> listTipo = new ArrayList<>();
    	listTipo.add("Carro");
    	listTipo.add("Moto");
    	cmbTipo.getItems().addAll(listTipo);
    }
}
