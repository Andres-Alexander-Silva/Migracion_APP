package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import fachada.Parqueadero;

public class MostrarListaPorHoraParqueoController {
    @FXML private TextArea txtAListaVehiculos;
    private Parqueadero p;
    
    public MostrarListaPorHoraParqueoController() {
    	p = Parqueadero.obtenerInstancia();
    }

    public void listarVehiculosPorSegundo(ActionEvent event) {
    	txtAListaVehiculos.setText(p.listarVehiculosParqueadosPorHora());
    }
}
