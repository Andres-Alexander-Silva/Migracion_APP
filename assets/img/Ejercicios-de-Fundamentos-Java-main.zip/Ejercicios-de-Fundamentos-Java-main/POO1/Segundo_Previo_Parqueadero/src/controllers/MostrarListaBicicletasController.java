package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import fachada.Parqueadero;

public class MostrarListaBicicletasController {
    @FXML private TextArea txtAListaBicicletas;
    private Parqueadero p;
    
    public MostrarListaBicicletasController() {
    	p = Parqueadero.obtenerInstancia();
    }

    public void mostrarlistaBicicletas(ActionEvent event) {
    	txtAListaBicicletas.setText(p.listarPorCedulaBicicletas());
    }
}
