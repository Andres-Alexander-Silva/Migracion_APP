package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import fachada.Parqueadero;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class RegistrarSalidaVController implements Initializable{
	@FXML private ComboBox<String> cmbTipoV;
	@FXML private TextField txtCcOPlaca;
	@FXML private TextField txtHoraSalida;
	@FXML private Label lbReporte;
	@FXML private Label lbPrecio;
	private Parqueadero p;
    
    public RegistrarSalidaVController() {
    	p = Parqueadero.obtenerInstancia();
    }
    
    public void totalizarPrecioVehiculos(ActionEvent event) {
    	lbReporte.setText(p.totalizarPrecioVehiculos());
    }
	
	public void registrarSalidaV(ActionEvent event) {
		String tipo = cmbTipoV.getValue();
		String CcOPlaca = txtCcOPlaca.getText();
		
		lbPrecio.setText(p.retirarVehiculo(CcOPlaca, tipo));
		
		txtCcOPlaca.clear();
    }
	
	public void initialize(URL arg0, ResourceBundle arg1) {
		ArrayList<String> listTipoV = new ArrayList<>();
		listTipoV.add("Carro");
		listTipoV.add("Moto");
		listTipoV.add("Bicicleta");
		cmbTipoV.getItems().addAll(listTipoV);
	}
}
