package models;

public class Moto extends Vehiculo {
	private int cilindro;
	private String tipo;
	
	public int getCilindro() {
		return cilindro;
	}
	
	public void setCilindro(int cilindro) {
		this.cilindro = cilindro;
	} 
	
	public String getTipo() {
		return tipo;
	}
	
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public String toString() {
		return getPlaca()+" "+getMarca()+" "+cilindro+" "+tipo;
	}
}