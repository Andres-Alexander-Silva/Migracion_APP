package models;

import java.util.Calendar;

public class Vehiculo {
	private String placa;
	private String marca;
	private Calendar horaEntrada;
	private Calendar horaSalida;
	
	public String getPlaca() {
		return placa;
	}
	
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	
	public String getMarca() {
		return marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}

	public Calendar getHoraEntrada() {
		return horaEntrada;
	}

	public void setHoraEntrada(Calendar horaEntrada) {
		this.horaEntrada = horaEntrada;
	}

	public Calendar getHoraSalida() {
		return horaSalida;
	}

	public void setHoraSalida(Calendar horaSalida) {
		this.horaSalida = horaSalida;
	}
	
	/*@Override
	public boolean equals(Object obj) {
		boolean rta = false;
		if(obj instanceof Vehiculo) {
		 Vehiculo tmp = (Vehiculo)obj;
		 rta = this.placa.equals(tmp.placa);
		}
		return rta;
	}*/
}