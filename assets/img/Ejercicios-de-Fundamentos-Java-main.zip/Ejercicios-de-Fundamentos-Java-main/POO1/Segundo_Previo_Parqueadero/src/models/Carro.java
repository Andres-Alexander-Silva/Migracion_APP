package models;

public class Carro extends Vehiculo {
	private String modelo;
	private int cilindros;
	private int numPuertas;
	
	public String getModelo() {
		return modelo;
	}
	
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	
	public int getCilindros() {
		return cilindros;
	}
	
	public void setCilindros(int cilindros) {
		this.cilindros = cilindros;
	}
	
	public int getNumPuertas() {
		return numPuertas;
	}
	
	public void setNumPuertas(int numPuertas) {
		this.numPuertas = numPuertas;
	}
	
	public String toString() {
		return getPlaca()+" "+getMarca()+" "+ modelo +" "+cilindros+" "+numPuertas;
	}
}