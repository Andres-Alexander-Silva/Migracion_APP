package models;

public class Bicicleta extends Vehiculo{
	private String ccPropietario;
	private String color;
	private String marca;
	private boolean esPrestada;
	
	public String getCcPropietario() {
		return ccPropietario;
	}
	
	public void setCcPropietario(String ccPropietario) {
		this.ccPropietario = ccPropietario;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	public String getMarca() {
		return marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public boolean isEsPrestada() {
		return esPrestada;
	}

	public void setEsPrestada(boolean esPrestada) {
		this.esPrestada = esPrestada;
	}
	
	public String toString() {
		return ccPropietario+" "+marca+" "+color+" "+esPrestada;
	}
	
	@Override
	public boolean equals(Object obj) {
		boolean rta = false;
		if(obj instanceof Bicicleta) {
		 Bicicleta tmp = (Bicicleta)obj;
		 rta = this.ccPropietario.equals(tmp.ccPropietario);
		}
		return rta;
	}
}