package fachada;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import models.Bicicleta;
import models.Vehiculo;
import models.Carro;
import models.Moto;

public class Parqueadero {
	private ArrayList<Vehiculo> vehiculos;
	private static Parqueadero instancia;
	private int totalCarros,totalMotos,totalBiciletas;
	
	public Parqueadero() {
		vehiculos = new ArrayList<Vehiculo>();
	}
	
	public static Parqueadero obtenerInstancia() {
		if (instancia == null) {
			instancia = new Parqueadero();
		}
		return instancia;
	}
	
	public String totalizarPrecioVehiculos() {
		String inf = "";
		int totalVehiculos;
		
		totalVehiculos = totalCarros + totalMotos + totalBiciletas;
		
		inf = "El valor a total recaudado es: "+totalVehiculos+"\n"+"El valor total por carros es: "+totalCarros+"\n"+
		"El valor total por motos es: "+totalMotos+"\n"+"El valor total por bicicletas es: "+totalBiciletas;
		return inf;
	}
	
	public String retirarVehiculo(String CcOPlaca, String tipo) {
		String info = "";
		int precioCarro,precioMoto,precioBicicleta;
		long entrada,salida,restaHora;
		
		for (int i = 0; i < vehiculos.size(); i++) {
	
			Vehiculo veh = vehiculos.get(i);
			
			if (veh instanceof Carro) {
				
				if(veh.getPlaca().equals(CcOPlaca)) {
					veh.setHoraSalida(Calendar.getInstance());
					entrada = veh.getHoraEntrada().getTimeInMillis();
					salida = veh.getHoraSalida().getTimeInMillis();
					restaHora = TimeUnit.MILLISECONDS.toSeconds(Math.abs(salida-entrada));
					precioCarro = (int) (restaHora * 60);
					totalCarros += precioCarro;
					String aviso = obtenerMinutosYSegundos(restaHora);
					info = "El precio a pagar es: "+precioCarro+"\nEl carro duro parqueado: "+aviso;;
				}
			}
			if (veh instanceof Moto) {
				if(veh.getPlaca().equals(CcOPlaca)) {
					veh.setHoraSalida(Calendar.getInstance());
					entrada = veh.getHoraEntrada().getTimeInMillis();
					salida = veh.getHoraSalida().getTimeInMillis();
					restaHora = TimeUnit.MILLISECONDS.toSeconds(Math.abs(salida-entrada));
					precioMoto = (int) (restaHora * 30);
					totalMotos += precioMoto;
					String aviso = obtenerMinutosYSegundos(restaHora);
					info = "El precio a pagar es: "+precioMoto+"\nLa moto duro parqueado: "+aviso;
				}
			}
			if (veh instanceof Bicicleta) {			
				Bicicleta b = (Bicicleta) veh;
				if(b.getCcPropietario().equals(CcOPlaca)) {
					b.setHoraSalida(Calendar.getInstance());
					entrada = b.getHoraEntrada().getTimeInMillis();
					salida = b.getHoraSalida().getTimeInMillis();
					restaHora = TimeUnit.MILLISECONDS.toSeconds(Math.abs(salida-entrada));
					precioBicicleta = (int) (restaHora * 10);
					totalBiciletas += precioBicicleta;
					String aviso = obtenerMinutosYSegundos(restaHora);
					info = "El precio a pagar es: "+precioBicicleta+"\nLa bicicleta duro parqueado: "+aviso;
				}
			}
		}
		
		return info;
	}
	
	public static void main(String[] args) {
		Calendar sn = Calendar.getInstance();
		Calendar sn2 = Calendar.getInstance();
		Parqueadero p = new Parqueadero();
		
		sn2.add(Calendar.MINUTE, 5);
		long salida = sn.getTimeInMillis();
		long entrada = sn2.getTimeInMillis();
		
		long resta = TimeUnit.MILLISECONDS.toSeconds(Math.abs(salida-entrada));
		
		System.out.println(p.obtenerMinutosYSegundos(resta));
	}
	
	private String obtenerMinutosYSegundos(long c) {
		String aviso = "";
		int seg = (int) (c);
		int minutos = seg/60;
		int val = minutos * 60;
		int segundos = seg - val;
		aviso = minutos+":"+segundos;
		return aviso;
	}
	
	public boolean obtenerPlacaRepetida(String placa) {
		boolean esRepetida = false;
		int contador = 0;
		
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = vehiculos.get(i);
			
			if(v instanceof Carro || v instanceof Moto) {
				if (vehiculos.get(i).getPlaca().equals(placa)) {
					contador++;
				}
			}
		}
		if (contador != 0) {
			esRepetida = true;
		}
		
		return esRepetida;
	}
	
	public void agregarVehiculos(String tipoVehiculo,String placa, String modelo, String marca
			, int numPuertas, int cilindros, String tipo, String ccPropietario, String color, 
			boolean esPrestada) throws Exception {
		
		if (tipoVehiculo.equals("Carro")){
			if(!placa.isEmpty() && !modelo.isEmpty() && !marca.isEmpty()) {
				if (obtenerPlacaRepetida(placa) == false) {
					if (placa.length() == 6) {
						Carro c = new Carro();
						c.setPlaca(placa);
						c.setMarca(marca);
						c.setModelo(modelo);
						c.setNumPuertas(numPuertas);
						c.setCilindros(cilindros);
						c.setHoraEntrada(Calendar.getInstance());
						
						vehiculos.add(c);
					} else throw new Exception("La placca ingresada no es de un carro");
				} else {
					throw new Exception("La placa que estas tratando de ingresar ya esta registrada"); 
				}
			}else
				throw new Exception("Ingrese todos los campos"); 
		}
		
		if (tipoVehiculo.equals("Moto")) {
			if (obtenerPlacaRepetida(placa) == false) {
				if (placa.length() == 5) {
					Moto m = new Moto();
					m.setPlaca(placa);
					m.setMarca(marca);
					m.setCilindro(cilindros);
					m.setTipo(tipo);
					m.setHoraEntrada(Calendar.getInstance());
					
					vehiculos.add(m);
				} else throw new Exception("La placa ingresada no es de moto");
			} else {
				throw new Exception("La placa que estas tratando de ingresar ya esta registrada");
			}
		}
		
		if (tipoVehiculo.equals("Bicicleta")) {
			Bicicleta b = new Bicicleta();
			b.setMarca(marca);
			b.setCcPropietario(ccPropietario);
			b.setColor(color);
			b.setEsPrestada(esPrestada);
			b.setHoraEntrada(Calendar.getInstance());
			
			vehiculos.add(b);
		}
	}
	
	public Bicicleta mostrarInfoBicicleta(String ccPropietario) {
		Bicicleta pObj = null;
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = vehiculos.get(i);
			if (v != null) {
				if (v instanceof Bicicleta) {
					Bicicleta b = (Bicicleta) v;
					if (b.getCcPropietario().equals(ccPropietario)) {
						pObj = (Bicicleta) vehiculos.get(i);
					}
				}
			}
		}
		return pObj;
	}
	
	public void actualizarDatosBicicleta(String ccPropietario, String marca, String color) {
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = vehiculos.get(i);
			if (v != null) {
				if (v instanceof Bicicleta) {
					Bicicleta b = (Bicicleta) v;
					if (b.getCcPropietario().equals(ccPropietario) && !b.isEsPrestada()) {
						b.setMarca(marca);
						b.setColor(color);
						System.out.println("Actualizado");
					}
				}
			}
		}
	}
	
	public ArrayList<Vehiculo> mostrarListaVehiculosCondicion(String tipoV, String condicion, int hora){
		ArrayList<Vehiculo> listaV = new ArrayList<>();
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = vehiculos.get(i);
			if (tipoV.equals("Carro")) {
				if (v instanceof Carro) {
					Carro c = (Carro) v;
					System.out.println(c.getHoraSalida());
					if (c.getHoraSalida() == null) {
						Calendar horaActual = Calendar.getInstance();
						int resta = (int) (TimeUnit.MILLISECONDS.toSeconds(Math.abs(horaActual.getTimeInMillis() 
								- c.getHoraEntrada().getTimeInMillis())));
						if (condicion.equals(">")) {
							if(resta>hora) {
								listaV.add(c);
							}
						}
						if (condicion.equals("<")) {
							if (resta<hora) {
								listaV.add(c);
							}
						}
						if (condicion.equals("=")) {
							if (resta==hora) {
								listaV.add(c);
							}
						}
					}
				}
			}
			if (tipoV.equals("Moto")) {
				if (v instanceof Moto) {
					Moto m = (Moto) v; 
					if (m.getHoraSalida() == null) {
						Calendar horaActual = Calendar.getInstance();
						int resta = (int) (TimeUnit.MILLISECONDS.toSeconds(Math.abs(horaActual.getTimeInMillis() - m.getHoraEntrada().getTimeInMillis())));
						System.out.println(resta);
						if (condicion.equals(">")) {
							if(resta>hora) {
								listaV.add(m);
							}
						}
						if (condicion.equals("<")) {
							if (resta<hora) {
								listaV.add(m);
							}
						}
						if (condicion.equals("=")) {
							if (resta==hora) {
								listaV.add(m);
							}
						}
					}
				}
			}
			if (tipoV.equals("Bicicleta")) {
				if (v instanceof Bicicleta) {
					Bicicleta b = (Bicicleta) v;
					if (b.getHoraSalida() == null) {
						Calendar horaActual = Calendar.getInstance();
						int resta = (int) (TimeUnit.MILLISECONDS.toSeconds(Math.abs(horaActual.getTimeInMillis() - b.getHoraEntrada().getTimeInMillis())));
						System.out.println(resta);
						if (condicion.equals(">")) {
							if(resta>hora) {
								listaV.add(b);
							}
						}
						if (condicion.equals("<")) {
							if (resta<hora) {
								listaV.add(b);
							}
						}
						if (condicion.equals("=")) {
							if (resta==hora) {
								listaV.add(b);
							}
						}
					}
				}
			}
		}
		return listaV;
	}
	
	public String listarVehiculosParqueadosPorHora() {
		HashMap<String, ArrayList<Vehiculo>> hashVehiculos = new HashMap<String, ArrayList<Vehiculo>>();
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = (Vehiculo) vehiculos.get(i);
			if (v != null ) {
				if (v.getHoraSalida() == null) {
					long horaActual = Calendar.getInstance().getTimeInMillis();
					long horaEntrada = v.getHoraEntrada().getTimeInMillis();
					int resta = (int) TimeUnit.SECONDS.toSeconds(Math.abs(horaActual- horaEntrada));
					int segundos = resta / 1000;
					ArrayList<Vehiculo> listSecondsVehiculos = hashVehiculos.get(segundos+" s");
					if (listSecondsVehiculos == null) {
						listSecondsVehiculos = new ArrayList<Vehiculo>();
						hashVehiculos.put(segundos+" s", listSecondsVehiculos);
					}
					listSecondsVehiculos.add(v);
				}
			}
				
		}
		
		String mensaje = imprimirListaVehiculosPorTiempo(hashVehiculos);
		System.out.println(mensaje);
		
		return mensaje;
	}
	
	
	public String impresionHashMapVehiculos(HashMap<String, ArrayList<Vehiculo>> hashVehiculos) {
		String mensaje = "";
		if (hashVehiculos != null) {
			Iterator<String> iterator = hashVehiculos.keySet().iterator();
			while (iterator.hasNext()) {
				String llave = iterator.next();
				ArrayList<Vehiculo> lista = hashVehiculos.get(llave);
				mensaje += llave+" = "+lista.size()+"\n";
			}
		}
		return mensaje;
	}
	
	public String imprimirListaVehiculosPorTiempo(HashMap<String, ArrayList<Vehiculo>> hashVehiculos) {
		String mensaje = "";
		int[] vectorV = ordenarHashMap(hashVehiculos);
		for (int i = 0; i < vectorV.length; i++) {
			mensaje += i+" s"+vectorV[i]+"\n";
		}
		return mensaje;
	}
	
	public int[] ordenarHashMap(HashMap<String, ArrayList<Vehiculo>> hashVehiculos) {
		int[] listaMaOrdenado = new int[61];
		for (int i = 0; i < listaMaOrdenado.length; i++) {
			if (hashVehiculos.get(i+" s") != null) {				
				listaMaOrdenado[i] = hashVehiculos.get(i+" s").size();
			}
		}
		return listaMaOrdenado;
	}
	
	public ArrayList<Vehiculo> obtenerListaPorPlaca(String placaB, String tipoV, boolean isEmpieza){
		ArrayList<Vehiculo> listaPlaca = new ArrayList<>();
		for (int i = 0; i < vehiculos.size(); i ++) {
			Vehiculo v = (Vehiculo) vehiculos.get(i);
			if (v != null) {
				if (tipoV.equals("Carro")) {
					if (v instanceof Carro) {
						if (v.getHoraSalida() == null) {
							int indice = -1;
							indice = v.getPlaca().indexOf(placaB);
							if (isEmpieza == true) {
								if(indice==0) {
									listaPlaca.add(v);
								}
							} else {
								if(indice>0) {
									listaPlaca.add(v);
								}
							}
						}
					}
				}
				if (tipoV.equals("Moto")) {
					if (v instanceof Moto) {
						if (v.getHoraSalida() == null) {
							int indice = -1;
							indice = v.getPlaca().indexOf(placaB);
							if (isEmpieza == true) {
								if (indice == 0) {
									listaPlaca.add(v);
								}
							} else {
								if (indice > 0) {
									listaPlaca.add(v);
								}
							}
						}
					}
				}
			}
		}
		return listaPlaca;
	}
	
	public String listarPorCedulaBicicletas() {
		HashMap<String, Integer> listaBibicletas = new HashMap<String, Integer>();
		for (int i = 0; i < vehiculos.size(); i++) {
			Bicicleta v = (Bicicleta) vehiculos.get(i);
			if ( v != null) {
				if (v instanceof Bicicleta) {
					if (listaBibicletas.containsKey(v.getCcPropietario())) {
						int num = listaBibicletas.get(v.getCcPropietario());
						listaBibicletas.put(v.getCcPropietario(), ++num);
					}
					else {
						listaBibicletas.put(v.getCcPropietario(), 1);
					}
						
				}
			}
		}
		String mensaje = imprimirHashMapBicicletas(listaBibicletas);
		return mensaje;
	}
	
	public String imprimirHashMapBicicletas(HashMap<String, Integer> listaBibicletas) {
		String sms = "";
		for (HashMap.Entry<String, Integer> lista : listaBibicletas.entrySet()) {
			sms += "CC Propietario: "+lista.getKey()+" = "+lista.getValue()+"\n";
		}
		return sms;
	}
	
	public ArrayList<String> obtenerListaCarros(){
		ArrayList<String> listCarros = new ArrayList<String>();
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = (Vehiculo) vehiculos.get(i);
			if (v != null) {
				if (v instanceof Carro) {
					listCarros.add(((Carro)v).toString());
				}
			}
		}
		return listCarros;
	}
	
	public ArrayList<String> obtenerListaMotos(){
		ArrayList<String> listMotos = new ArrayList<String>();
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = (Vehiculo) vehiculos.get(i);
			if (v != null) {
				if (v instanceof Moto) {
					listMotos.add(((Moto)v).toString());
				}
			}
		}
		return listMotos;
	}
	
	public ArrayList<String> obtenerListaBicicleta(){
		ArrayList<String> listaBiciletas = new ArrayList<String>();
		for (int i = 0; i < vehiculos.size(); i++) {
			Vehiculo v = (Vehiculo) vehiculos.get(i);
			if (v != null) {
				System.out.println(v.getClass());
				if (v instanceof Bicicleta) {
					System.out.println("v");
					listaBiciletas.add(((Bicicleta)v).toString());
				}
			}
		}
		return listaBiciletas;
	}
}
