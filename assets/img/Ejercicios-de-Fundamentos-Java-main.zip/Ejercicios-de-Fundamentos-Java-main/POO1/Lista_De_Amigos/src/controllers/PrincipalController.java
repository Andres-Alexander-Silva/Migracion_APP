package controllers;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import models.Amigos; 

public class PrincipalController{
	@FXML private ComboBox<String> cmbAmigos;
	@FXML private ListView<String> listAmigosGrupo;
    @FXML private TextField txtNuevoAmigo;
    private Amigos amix;
    
    public PrincipalController() {
    	amix = new Amigos();
    }
    
    public void agregarAgrupo(ActionEvent event) {
    	String amigoElegido = cmbAmigos.getValue();
    	String estaElAmigo = amix.agregarAmigoAlGrupo(amigoElegido);
    	
    	if (estaElAmigo.equals("OK")) {
    		ArrayList<String> listaGrupoAmigos = amix.obtenerGrupoAmigos();
    		listAmigosGrupo.getItems().clear();
    		listAmigosGrupo.getItems().addAll(listaGrupoAmigos);
    	}
    	else {
    		Alert aviso = new Alert(AlertType.ERROR);
			aviso.setContentText(estaElAmigo);
			aviso.show();
    	}
    }

    public void agregarAmigo(ActionEvent event) {
    	String amigo = txtNuevoAmigo.getText();
    	String ms = amix.agregarAmigo(amigo);
    	
    	cmbAmigos.getItems().add(amigo);
    	
    	txtNuevoAmigo.clear();
    	
    	Alert alert = new Alert(AlertType.INFORMATION);
    	alert.setContentText(ms);
    	alert.show();
    }

    public void eliminarAmigo(ActionEvent event) {
    	String eliminarAmigo = listAmigosGrupo.getSelectionModel().getSelectedItem();
    	String eliminado = amix.elimiarAmigoDelGrupo(eliminarAmigo);
    	
    	if (eliminado.equals("OK")) {
    		System.out.println("Entra");
    		ArrayList<String> listaGrupoAmogos = amix.obtenerGrupoAmigos();
    		listAmigosGrupo.getItems().clear();
    		listAmigosGrupo.getItems().addAll(listaGrupoAmogos);
    	}
    	
    	else {
    		Alert alert = new Alert(AlertType.INFORMATION);
        	alert.setContentText(eliminado);
        	alert.show();
    	}
    }

    public void mostrarAmigos(ActionEvent event) {
    	ArrayList<String> listaDeAmigos = amix.obtenerGrupoAmigos();
    	String mensaje = "Los amigos del grupo son:\n";
    	for(String amigo: listaDeAmigos) {
    		mensaje += amigo + "\n";
    	}
    	Alert alert = new Alert(AlertType.INFORMATION);
    	alert.setContentText(mensaje);
    	alert.show();
    }
}