package models;

import java.util.ArrayList;

public class Amigos {
	private ArrayList<String> listAmigos, listGrupoAmigos;
	
	public Amigos() {
		listAmigos = new ArrayList<String>();
		listGrupoAmigos = new ArrayList<String>();
	}
	
	public String agregarAmigo(String amigo) {
		listAmigos.add(amigo);
		String mensaje = "Amigo agregado satisfactoriamente";
		return mensaje;
	}
	
	public ArrayList<String> obtenerGrupoAmigos() {
		return listGrupoAmigos;
	}
	
	public String agregarAmigoAlGrupo(String amigoElegido) {
		String ms = "";
		
		for (String amigoLista: listGrupoAmigos) {
			if (amigoLista.equals(amigoElegido)) {
				ms = "Error el amigo elegido ya esta en la lista";
				break;
			}
		}
		
		if (ms.isEmpty()) {
			listGrupoAmigos.add(amigoElegido);
			ms = "OK";
		}
		
		return ms;
	}
	
	public String elimiarAmigoDelGrupo(String amigoEliminar) {
		String ms = "";
		
		for (String amigoList: listGrupoAmigos) {
			if (amigoList.equals(amigoEliminar)) {
				listGrupoAmigos.remove(amigoEliminar);
				ms = "OK";
				break;
			}
		}
		
		if (ms.isBlank()) {
			ms = "Error el amigo a eliminar no esta en el grupo";
		}
		
		return ms;
	}
}