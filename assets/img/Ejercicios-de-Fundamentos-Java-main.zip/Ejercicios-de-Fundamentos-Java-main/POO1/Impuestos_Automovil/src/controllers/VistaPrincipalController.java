package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import fachada.ConcesionarioCliente;

public class VistaPrincipalController {
	@FXML private TextField txtMarca,txtlinea,txtModelo,txtValor,txtTotalPagar;
	@FXML private CheckBox chkProntoPago,chkServicioPublico,chkTrasladoCuenta;
	private ConcesionarioCliente ccObj;
	
	public VistaPrincipalController() {
		ccObj = ConcesionarioCliente.obtenerInstancio();
	}
	
	public void calcularTotalAPagar() {
		String marca = txtMarca.getText();
		String linea = txtlinea.getText();
		int modelo = Integer.parseInt(txtModelo.getText());
		int precio = Integer.parseInt(txtValor.getText());
		
		ccObj.agregarVehiculo(marca, linea, modelo, precio);
		
		boolean estaProntoPagaSeleccionado = chkProntoPago.isSelected();
		boolean estaServicioPublicoSeleccionado = chkServicioPublico.isSelected();
		boolean estaTrasladoCuentaSeleccionado = chkTrasladoCuenta.isSelected();
		
		int valorTotal = ccObj.calcularDescuentos(estaProntoPagaSeleccionado, estaServicioPublicoSeleccionado, estaTrasladoCuentaSeleccionado);
		String strValorTotal = valorTotal + "";
		txtTotalPagar.setText(strValorTotal);
	}
	
	public void limpiar() {
		txtMarca.clear();
		txtlinea.clear();
		txtModelo.clear();
		txtValor.clear();
		txtTotalPagar.clear();
		chkProntoPago.setSelected(false);
		chkServicioPublico.setSelected(false);
		chkTrasladoCuenta.setSelected(false);
	}
}
