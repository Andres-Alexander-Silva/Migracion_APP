package fachada;

import models.Vehiculo;

public class ConcesionarioCliente {
	private Vehiculo v;
	private static ConcesionarioCliente instancia;
	
	public static ConcesionarioCliente obtenerInstancio() {
		if(instancia==null)
			instancia = new ConcesionarioCliente();
		
		return instancia;
	}
	
	public void agregarVehiculo(String marca, String linea, int modelo, int precio) {
		v = new Vehiculo();
		
		v.setMarca(marca);
		v.setLinea(linea);
		v.setModelo(modelo);
		v.setPrecio(precio);
	}
	
	public int calcularImpuestoDelVehiculo() {
		int impuesto = 0;
		if (v.getPrecio() >= 0 && v.getPrecio() <= 30000000) {
			impuesto = (int) ((v.getPrecio() * 1.5) / 100);
		}
		else if (v.getPrecio() >= 30000000 && v.getPrecio() <= 70000000) {
			impuesto = (int) ((v.getPrecio() * 2) / 100);
		}
		else if(v.getPrecio() >= 70000000 && v.getPrecio() <= 200000000) {
			impuesto = (int) ((v.getPrecio() * 2.5) / 100);
		}
		else if (v.getPrecio() > 200000000) {
			impuesto = (int) ((v.getPrecio() * 4) / 100);
		}
		return impuesto;
	}
	
	public int calcularDescuentos(boolean estaProntoPago, boolean estaServicioPublico, boolean estaTrasladoCuenta) {
		
		int impuesto = calcularImpuestoDelVehiculo(); 
		System.out.println("imouesto = "+impuesto);
		
		if (estaProntoPago) {
			int descuento1 = ((impuesto * 10) / 100);
			impuesto -= descuento1;
		}
		
		if (estaServicioPublico) {
			int descuento2 = 50000;
			impuesto -= descuento2;
		}
		
		if (estaTrasladoCuenta) {
			int descuento3 = ((impuesto * 5) / 100);
			impuesto -= descuento3;
		}
		
		return impuesto;
	}
}