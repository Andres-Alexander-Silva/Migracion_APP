package Ejercicio7;

public class Criptografia {
    int cantidadLetras,desplazamiento;
    char[] caracteres,textoCifrado;

    void algoritmo(){
        int[] codigosAscci;
        codigosAscci = new int[cantidadLetras];
        for (int i = 0; i < textoCifrado.length; i++){
            codigosAscci[i] = textoCifrado[i];
            System.out.println(codigosAscci[i]);
        }
    }
}
