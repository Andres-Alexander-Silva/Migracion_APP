package Ejercicio7;

import java.util.Scanner;

class CriptografiaMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Criptografia c = new Criptografia();

        c.cantidadLetras = entrada.nextInt();

        c.caracteres = new char[c.cantidadLetras];

        c.textoCifrado = new char[c.cantidadLetras];
        for (int i = 0; i < c.textoCifrado.length; i++){
            c.textoCifrado[i] = entrada.next().charAt(0);
        }

        c.desplazamiento = entrada.nextInt();

        c.algoritmo();

        entrada.close();
    }    
}
