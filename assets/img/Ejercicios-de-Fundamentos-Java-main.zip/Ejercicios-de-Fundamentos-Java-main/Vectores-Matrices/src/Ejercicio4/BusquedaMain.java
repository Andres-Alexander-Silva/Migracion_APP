package Ejercicio4;

import java.util.Scanner;

class BusquedaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Busqueda b = new Busqueda();

        int n = c.nextInt();
        b.numeros = new int[n];

        for (int i = 0; i < n; i++){
            b.numeros[i] = c.nextInt();
        }
        
        b.numero = c.nextInt();
        b.BuscarNum(b.numeros,b.numero);

        if (b.existe) System.out.println("Numero " + b.numero + " SI existe");
        else System.out.println("Numero " + b.numero + " NO existe");

        c.close();
    }
}