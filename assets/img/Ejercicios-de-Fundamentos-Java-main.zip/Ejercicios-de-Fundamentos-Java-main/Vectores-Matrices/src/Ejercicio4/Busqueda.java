package Ejercicio4;


public class Busqueda {
    int[] numeros;
    int numero;
    boolean existe = false;

    boolean BuscarNum(int[] numeros, int num){
        for (int i = 0; i < numeros.length; i++){
            if (numeros[i] == num) existe = true;
        }
        return existe;
    }
}