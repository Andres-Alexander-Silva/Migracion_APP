package Ejercicio9;

import java.util.Scanner;

class NumHexadecimalMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        NumHexadecimal h = new NumHexadecimal();

        h.tamaño = entrada.nextInt();

        h.hexadecimal = new char[h.tamaño];
        for (int i = 0; i < h.hexadecimal.length; i++){
            h.hexadecimal[i] = entrada.next().charAt(0);
        }

        h.algoritmo();

        entrada.close();
    }    
}
