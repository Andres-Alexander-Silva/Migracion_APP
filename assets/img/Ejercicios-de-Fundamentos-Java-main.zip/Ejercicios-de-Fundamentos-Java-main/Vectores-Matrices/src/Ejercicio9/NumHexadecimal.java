package Ejercicio9;

class NumHexadecimal {
    char[] hexadecimal;
    int tamaño;
    long numeroDecimal=0,base=1;

    void algoritmo(){
        for (int i = hexadecimal.length - 1; i >= 0; i--){
            if (hexadecimal[i] >= '0' && hexadecimal[i] <= '9'){
                numeroDecimal += (hexadecimal[i] - 48) * base;
                base *= 16;
            } else if (hexadecimal[i] >= 'A' && hexadecimal[i] <= 'F'){
                numeroDecimal += (hexadecimal[i] - 55) * base;
                base *= 16;
            }
        }
        System.out.println(numeroDecimal);
    }
}
