package EjemplosMatrices;

class matrices {
    public static void main(String[] args) {
        int[][] a = {{2,4,5,6},{5,6,3,5},{3,8,9,2},{5,4,6,4}};
        //Recorrer una matriz
        for(int i = 0; i < a.length; i++){
            for (int j = 0; j < a[i].length; j++){
                System.out.print(a[i][j]+" ");
            }
            System.out.println("");
        }
        int[][] datos = new int[5][5];
        //Llenar la matriz con valores aleatorios
        for(int i = 0; i < datos.length; i++){
            for (int j = 0; j < datos[i].length; j++){
                int nota = (int) (Math.round(Math.random()*5));
                datos[i][j] = nota;
            }
        }
        //Imprimir la matriz de datos con las notas
        int suma=0;
        double promedio=0;
        for(int i = 0; i < datos.length; i++){
            suma = 0;
            for (int j = 0; j < datos[i].length; j++){
                suma += datos[i][j];
                System.out.println("Estudiante "+(i+1)+" Nota "+(j+1)+": "+datos[i][j]);
            }
            promedio = (double) suma / (double) datos.length;
            System.out.println("Estudiante "+(i+1)+", Definitiva "+promedio);
        }
    }
}
