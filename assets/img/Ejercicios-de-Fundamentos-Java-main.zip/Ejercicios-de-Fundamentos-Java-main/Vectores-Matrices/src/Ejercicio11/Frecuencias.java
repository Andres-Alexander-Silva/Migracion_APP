package Ejercicio11;

import java.util.Arrays;

class Frecuencias {
    int elementos,contador=0;
    char[] digitos0A9;
    char aux;
    boolean valido;

    void frecuencia(){
        if (validar()){
            Arrays.sort(digitos0A9);
            aux = digitos0A9[0];
            for (int i = 0; i < digitos0A9.length; i++){
                if (aux == digitos0A9[i]){
                    contador++;
                } else {
                    System.out.println("frecuencia("+aux+") = "+contador);
                    contador = 1;
                    aux=digitos0A9[i];
                }
            }  
            System.out.println("frecuencia("+aux+") = "+contador);
        } else System.out.println("¡Datos Incorrectos!");
    }
    boolean validar(){
        Arrays.sort(digitos0A9);
        for (int i = 0; i < digitos0A9.length; i++){
            if (digitos0A9[i] >= '0' && digitos0A9[i] <= '9') valido = true;
            else valido = false;
        }
        return valido;
    }
}