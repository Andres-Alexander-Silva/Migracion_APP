package Ejercicio11;

import java.util.Scanner;

class FrecuenciasMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Frecuencias f = new Frecuencias();

        f.elementos = entrada.nextInt();
        f.digitos0A9 = new char[f.elementos];

        for (int i = 0; i < f.digitos0A9.length; i++){
            f.digitos0A9[i] = entrada.next().charAt(0); 
        }

        f.frecuencia();

        entrada.close();
    }
}
