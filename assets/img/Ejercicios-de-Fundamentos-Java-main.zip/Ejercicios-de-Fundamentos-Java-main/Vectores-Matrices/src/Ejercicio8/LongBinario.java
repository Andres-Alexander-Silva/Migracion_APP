package Ejercicio8;

public class LongBinario {
    long numero,dig,contador=0,i=0;
    String numB = "";
    String[] binario;

    void algoritmo(){
        long copia = numero;
        if (copia >= 1000000000000000000L){
            while (copia > 0){
                dig = copia % 2;
                numB = dig + numB;
                contador++;
                copia /= 2;
            }
            binario = new String[(int)contador];
            for (int i = 0; i < binario.length; i++){
                binario[i] = numB;
            }
        } else System.out.println("Error. Debe ser >= 1000000000000000000");
    }
}
