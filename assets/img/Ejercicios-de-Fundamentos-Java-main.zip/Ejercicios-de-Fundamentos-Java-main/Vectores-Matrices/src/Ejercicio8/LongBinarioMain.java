package Ejercicio8;

import java.util.Scanner;

public class LongBinarioMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        LongBinario lb = new LongBinario();

        lb.numero = entrada.nextLong();

        lb.algoritmo();

        System.out.println(lb.numero + "==" + lb.binario[0] + " ");

        entrada.close();
    }
}
