package Ejercicio2;

class DivisoresDeUnNumero {
    int numero=0,contador=0,residuo=0;
    int[] divisores;

    void principal(){
        int n = contadorDiv(numero);
        divisores = new int[n];
        calcularDiv(numero);
    }
    int contadorDiv(int num){
        for (int i = 1; i <= numero; i++){
            residuo = numero % i;
            if (residuo == 0){
                contador++;
            }
        }
        return contador;
    }
    void calcularDiv(int num){
        int contador2 = 0;
        for (int j = 1; j <= numero; j++){
            if (numero % j == 0) divisores[contador2++] = j;
        }
    }
}