package Ejercicio2;

import java.util.Scanner;

class DivisoresDeUnNumeroMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        DivisoresDeUnNumero d = new DivisoresDeUnNumero();

        d.numero = c.nextInt();
        c.close();

        d.principal();

        System.out.println(d.numero+" tiene "+d.contador+" divisores: ");

        for(int i = 0; i < d.divisores.length; i++){
            System.out.println(""+d.divisores[i]);
        }
    }
}