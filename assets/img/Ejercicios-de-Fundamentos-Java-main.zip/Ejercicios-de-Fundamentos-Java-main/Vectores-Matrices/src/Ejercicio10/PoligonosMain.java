package Ejercicio10;

import java.util.Scanner;

class PoligonosMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Poligonos p = new Poligonos();

        p.cantidadPuntos = entrada.nextInt();

        p.puntos = new int [p.cantidadPuntos*2];
        for(int i=0; i<p.puntos.length; i++){
           p.puntos[i] = entrada.nextInt();
        }

        p.algoritmo();

        int lado=1;
        for(int i=0; i<p.distancia.length; i++,lado++ ){
           System.out.println("Lado "+lado+" : "+p.distancia[i]);
        }

        entrada.close();
    }
}
