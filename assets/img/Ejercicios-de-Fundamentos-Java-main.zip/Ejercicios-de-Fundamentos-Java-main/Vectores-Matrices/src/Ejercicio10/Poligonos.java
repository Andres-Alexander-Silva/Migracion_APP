package Ejercicio10;

class Poligonos {
    int cantidadPuntos;
    int [] puntos;
    int [] ladosx;
    int [] ladosy;
    double [] distancia;

    void algoritmo(){
        ladosx= new int [cantidadPuntos];
        int p=1;
        for ( int i =0; i<puntos.length;i=i+2 ,p++){
            if(i==puntos.length-2){
                ladosx[p-p]=(puntos[i-i]-puntos[i])*(puntos[i-i]-puntos[i]);
            }
            else{
                ladosx[p]=(puntos[i+2]-puntos[i])*(puntos[i+2]-puntos[i]);
            }
        }
        ladosy= new int [cantidadPuntos];
        int y=1;
        for ( int i =1; i<puntos.length;i=i+2 ,y++){
            if(i==puntos.length-1){
                ladosy[y-y]=(puntos[i-(i-1)]-puntos[i])*(puntos[i-(i-1)]-puntos[i]);
            }
            else{
                ladosy[y]=(puntos[i+2]-puntos[i])*(puntos[i+2]-puntos[i]);
            }
        }
        distancia=new double[cantidadPuntos];
        for(int i=0; i<distancia.length; i++){
            distancia[i]=Math.sqrt(ladosx[i]+ladosy[i]);
        }
    }
}