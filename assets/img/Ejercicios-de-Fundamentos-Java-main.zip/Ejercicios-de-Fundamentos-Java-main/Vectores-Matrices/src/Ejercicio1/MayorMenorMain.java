package Ejercicio1;

import java.util.Scanner;

class MayorMenorMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        MayorMenor m = new MayorMenor();

        int num = c.nextInt();
        m.estaturas = new int [num];
        
        for (int i = 0; i < num; i++){
            m.estaturas[i] = c.nextInt();
        }

        m.MayorEstatura();
        m.MenorEstatura();

        System.out.println("Posicion Mayor: "+m.posicionMayor+", Mayor: "+m.mayor+", Posicion Menor: "+m.posicionMenor+", Menor: "+m.menor);

        c.close();
    }
}