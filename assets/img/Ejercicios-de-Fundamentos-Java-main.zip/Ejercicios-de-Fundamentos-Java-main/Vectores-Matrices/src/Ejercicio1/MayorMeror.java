package Ejercicio1;

class MayorMenor{
    int[] estaturas; 
    int posicionMayor=0,posicionMenor=0,mayor,menor;
    
    void MayorEstatura(){
        mayor = estaturas[0];
        for (int i = 0; i < estaturas.length; i++){
            if (estaturas[i] > mayor){
                mayor = estaturas[i];
                posicionMayor = i;
            }
        }
    }

    void MenorEstatura(){
        menor = estaturas[0];
        for (int i = 0; i < estaturas.length; i++){
            if (estaturas[i] < menor){
                menor = estaturas[i];
                posicionMenor = i;
            }
        }
    }
}