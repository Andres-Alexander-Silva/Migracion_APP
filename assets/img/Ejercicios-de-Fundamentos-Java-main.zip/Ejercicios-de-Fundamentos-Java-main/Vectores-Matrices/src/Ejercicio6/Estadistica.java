package Ejercicio6;

class Estadistica {
    float[] calificaciones;
    float num;
    float reprodao,aprovado,bueno,excelente,condicional;
    float contadorRe=0,contadorApro=0,contadorBue=0,contadorCondi=0,contadorExc=0;

    void algoritmo(){
        for (int i = 0; i < num; i++){
            if (calificaciones[i] >= 4.5 && calificaciones[i] <= 5.0){
                contadorExc++;
            }
            if (calificaciones[i] >= 4.0 && calificaciones[i] < 4.5){
                contadorBue++;
            }
            if (calificaciones[i] >= 3.5 && calificaciones[i] < 4.0){
                contadorApro++;
            }
            if (calificaciones[i] >= 3.0 && calificaciones[i] < 3.5){
                contadorCondi++;
            }
            if (calificaciones[i] < 3.0){
                contadorRe++;
            }
        }
        excelente = (contadorExc/num)*100;
        bueno = (contadorBue/num)*100;
        aprovado = (contadorApro/num)*100;
        condicional = (contadorCondi/num)*100;
        reprodao = (contadorRe/num)*100;
    }
}