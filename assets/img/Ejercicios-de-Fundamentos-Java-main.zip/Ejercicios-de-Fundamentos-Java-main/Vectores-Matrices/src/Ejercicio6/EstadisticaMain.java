package Ejercicio6;

import java.util.Scanner;

class EstadisticaMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Estadistica e = new Estadistica();

        e.num = entrada.nextFloat();
        e.calificaciones = new float[ (int) e.num ];
        for (int i = 0; i < e.calificaciones.length; i++){
            e.calificaciones[i] = entrada.nextFloat();
        }
        
        e.algoritmo();
        
        System.out.println("% Excelente: "+e.excelente);
        System.out.println("% Bueno: "+e.bueno);
        System.out.println("% Aprovado: "+e.aprovado);
        System.out.println("% Condicional: "+e.condicional);
        System.out.println("% Reprobado: "+e.reprodao);
        
        entrada.close();
    }
}