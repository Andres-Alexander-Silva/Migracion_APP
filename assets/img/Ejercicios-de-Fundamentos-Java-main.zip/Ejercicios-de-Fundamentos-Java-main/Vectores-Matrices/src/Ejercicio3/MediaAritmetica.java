package Ejercicio3;

class MediaAritmetica {
    int[] datos;
    int media = 0,suma = 0,div = 0;

    void CalcularMedia(){
        for (int i = 0; i < datos.length; i++){
            suma = suma + datos[i];
        }
        div = suma / datos.length;
        media = div;
    }
}