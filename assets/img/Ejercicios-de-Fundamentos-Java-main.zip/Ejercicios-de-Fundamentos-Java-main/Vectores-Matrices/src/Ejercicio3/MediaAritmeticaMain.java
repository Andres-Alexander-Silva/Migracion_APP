package Ejercicio3;

import java.io.PrintWriter;
import java.util.Scanner;

class MediaAritmeticaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        PrintWriter in = new PrintWriter(System.out);
        MediaAritmetica m = new MediaAritmetica();

        int n = c.nextInt();
        m.datos = new int[n];

        for (int i = 0; i < n; i++){
            m.datos[i] = c.nextInt();
        }

        m.CalcularMedia();

        in.println("Media: "+m.media);

        in.close();
        c.close();
    }    
}
