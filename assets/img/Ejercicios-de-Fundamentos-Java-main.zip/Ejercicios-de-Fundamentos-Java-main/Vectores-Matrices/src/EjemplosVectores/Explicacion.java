package EjemplosVectores;

class Explicacion {
    int cantidaPersonas,posicionMayor=0,posicionMenor=0,mayor,menor;
    int[] estatura;

    void calcularMayor(){
        mayor = estatura[0];
        for (int i = 0; i < estatura.length; i++){
            if (estatura[i] > mayor){
                mayor = estatura[i];
                posicionMayor = i;
            }
        }
    }
    void calcularMenor(){
        menor = estatura[0];
        for (int i = 0; i < estatura.length; i++){
            if (estatura[i] < menor){
                mayor = estatura[i];
                posicionMayor = i;
            }
        }
    }
}