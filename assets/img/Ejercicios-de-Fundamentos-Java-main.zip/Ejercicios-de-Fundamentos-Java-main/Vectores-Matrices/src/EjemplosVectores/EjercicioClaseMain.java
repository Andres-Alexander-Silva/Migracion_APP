package EjemplosVectores;

import java.io.PrintWriter;
import java.util.Scanner;

public class EjercicioClaseMain {
    public static void main(String[] args) {
        Scanner con = new Scanner(System.in);
        PrintWriter imprimir = new PrintWriter(System.out);
        EjercicioClase r = new EjercicioClase();

        System.out.println("Digite la cantidad de datos");
        int n = con.nextInt();
        r.sensores = new int[n];

        for(int i = 0; i < r.sensores.length; i++){
            r.sensores[i] = con.nextInt();
        }

        r.algoritmo();

        if(r.promedio < 30){
            imprimir.println("Activar Sistema de riego");
        } 
        else{
            imprimir.println("Desactivar Sistema de riego:");
        }

        con.close();
        imprimir.close();
    }
}