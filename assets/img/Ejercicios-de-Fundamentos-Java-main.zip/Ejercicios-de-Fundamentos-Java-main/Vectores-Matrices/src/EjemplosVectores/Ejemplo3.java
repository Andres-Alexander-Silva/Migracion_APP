package EjemplosVectores;

import java.util.Arrays;

class Ejemplo3 {
    int[] numeros;
    int suma = 0,promedio = 0;

    public void llenarVector(int nums){
        for (int i = 0; i < numeros.length; i++){
            numeros[i] = nums;
        }
    }
    public void ordenarVector(){
        Arrays.sort(numeros);
        for (int i = 0; i < numeros.length-1; i++){
            System.out.println("Numero["+i+"]: "+numeros[i]);
        }
    }
    public void promedio(){
        for (int i = 0; i < numeros.length; i++){
            suma = suma + numeros[i];
        }
        promedio = suma / numeros.length;
    }
}
