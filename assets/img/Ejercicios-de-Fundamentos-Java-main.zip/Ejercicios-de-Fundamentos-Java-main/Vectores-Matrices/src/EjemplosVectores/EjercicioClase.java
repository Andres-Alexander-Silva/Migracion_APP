package EjemplosVectores;

class EjercicioClase {
    int[] sensores;
    int promedio = 0, suma = 0;

    public void algoritmo(){
        for (int i = 0; i < sensores.length; i++){
            suma = suma + sensores[i];
        }
        promedio = suma / sensores.length;
    }
}
