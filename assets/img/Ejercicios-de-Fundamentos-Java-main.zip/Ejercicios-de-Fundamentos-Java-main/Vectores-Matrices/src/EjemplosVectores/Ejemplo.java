package EjemplosVectores;

class Ejemplo {
    int contador = 0;
    int[] vectro1 = {1,2,3,4,5,6,7,8,9}, vector2 = {1,2,3,4,5,6,7,8,9};
    boolean iguales = false;

    public boolean vectoresIguales(){
        for (int i = 0; i<vectro1.length; i++){
            if (vectro1[i] == vector2[i]){
                contador++;
            } else {
                break;
            }
        }
        if (contador == vectro1.length){
            iguales = true;
        }
        return iguales;
    }
}