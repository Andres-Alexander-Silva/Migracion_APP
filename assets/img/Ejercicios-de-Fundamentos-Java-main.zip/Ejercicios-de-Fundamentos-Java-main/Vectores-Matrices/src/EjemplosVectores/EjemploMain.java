package EjemplosVectores;

class EjemploMain {
    public static void main(String[] args) {
        Ejemplo eje = new Ejemplo();

        System.out.println(eje.vectoresIguales());
    }
}
