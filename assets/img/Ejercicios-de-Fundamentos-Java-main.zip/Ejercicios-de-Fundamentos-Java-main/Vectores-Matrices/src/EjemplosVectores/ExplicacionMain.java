package EjemplosVectores;

import java.util.Scanner;

class ExplicacionMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Explicacion e = new Explicacion();

        e.cantidaPersonas = entrada.nextInt();
        e.estatura = new int[e.cantidaPersonas];

        for(int i = 0; i < e.estatura.length; i++){
            e.estatura[i] = entrada.nextInt();
        }

        e.calcularMayor();
        e.calcularMenor();

        System.out.println("Posicion Mayor: "+e.posicionMayor+", Mayor: "+e.mayor+", Posicion Menor: "+e.posicionMenor+", Menor: "+e.menor);

        entrada.close();
    }
}