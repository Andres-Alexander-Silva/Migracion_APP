package EjemplosVectores;

import java.util.Scanner;

class Ejemplo3Main {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Ejemplo3 e = new Ejemplo3();

        int n = c.nextInt();
        e.numeros = new int[n];
        int num = c.nextInt();
        e.llenarVector(num);
        System.out.println("Vector Ordenado");
        e.ordenarVector();
        
        c.close();
    }    
}
