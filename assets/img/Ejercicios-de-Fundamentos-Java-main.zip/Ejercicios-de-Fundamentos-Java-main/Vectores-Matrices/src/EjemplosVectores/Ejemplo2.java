package EjemplosVectores;

import java.io.PrintWriter;
import java.util.Scanner;

public class Ejemplo2 {
    public void OrdenarString(){
        String[] palabras = {"Perro","Vaca","Banco","Carro","Moto","Cabra","Gato","Avion"};
        String aux = "";
        for (int i = 0; i < palabras.length-1; i++){
            for (int j = i+1; j < palabras.length; j++){
                if (palabras[j].compareTo(palabras[i])<0){
                    aux = palabras[j];
                    palabras[j] = palabras[i];
                    palabras[i] = aux;
                }
            }
        }
    }
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        PrintWriter salida = new PrintWriter(System.out);

        

        entrada.close();
        salida.close();
    }

    
}
