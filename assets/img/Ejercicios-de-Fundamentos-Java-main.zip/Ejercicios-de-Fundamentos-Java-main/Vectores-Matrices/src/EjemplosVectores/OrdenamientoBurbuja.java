package EjemplosVectores;

//import java.util.Arrays;
import java.util.Scanner;

class OrdenamientoBurbuja {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        int[] numeros = new int[100];

        for ( int i = 0; i < numeros.length; i++){
            int numero = (int) (Math.random()*100);
            numeros[i] = numero;
        }
        for (int i = 0; i < numeros.length; i++){
            System.out.println("Numero["+i+"]"+numeros[i]);
        }
        /*//Ordenamiento Con Arrays.sort
        Arrays.sort(numeros);
        //De mayor a menor
        for (int i = numeros.length; i >= 0; i++){
            System.out.println("Numero["+i+"]"+numeros[i]);
        }
        //De menor a mayor
        for (int i = 0; i < numeros.length; i--){
            System.out.println("Numero["+i+"]"+numeros[i]);
        }*/
        //ordenamiento Burbuja
        for (int i = 0; i < numeros.length-1; i++){
            int aux;
            for (int j = i+1; j < numeros.length; j++){
                if (numeros[j] > numeros[i]){
                    aux = numeros[j];
                    numeros[j] = numeros[i];
                    numeros[i] = aux;
                }
            }
        }
        System.out.println("Vector ordenado Burbuja");
        for (int i = 0; i < numeros.length; i++){
            System.out.println("Numero["+i+"]"+numeros[i]);
        }
        c.close();
    }
}
