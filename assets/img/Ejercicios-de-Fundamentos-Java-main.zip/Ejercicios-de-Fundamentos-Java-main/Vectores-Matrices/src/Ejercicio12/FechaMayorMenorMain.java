package Ejercicio12;

import java.util.Scanner;

class FechaMayorMenorMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        FechaMayorMenor f = new FechaMayorMenor();

        f.cantidadFechas = entrada.nextInt();
        f.fechas = new int[f.cantidadFechas];

        for(int i = 0; i < f.fechas.length; i++){
            f.fechas[i] = entrada.nextInt();
        }

        entrada.close();
    }
}
