package Ejercicio12;

class FechaMayorMenor {
    int dia,mes,anio;
    int cantidadFechas;
    int[] fechas;

    int diaSemana(){//int dia,int mes,int anio
        int factorCorreccion = 0,diaZeller=0;
        factorCorreccion = (14-mes)/12;
        int mesZeller = mes -2 + 12 * factorCorreccion;
        int anioZeller = anio-factorCorreccion;
        diaZeller = (dia+anioZeller+(anioZeller/4)+
        (anioZeller/400)+(31*mesZeller)/12-anioZeller/100)%7; 
        return diaZeller;
    }

    boolean validarFecha(){
        return false;
    }
}