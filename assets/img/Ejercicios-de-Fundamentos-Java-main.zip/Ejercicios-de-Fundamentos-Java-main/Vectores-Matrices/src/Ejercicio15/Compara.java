package Ejercicio15;

class Compara {
    
}
