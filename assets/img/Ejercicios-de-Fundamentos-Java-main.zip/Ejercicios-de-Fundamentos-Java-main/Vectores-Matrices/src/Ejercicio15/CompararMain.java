package Ejercicio15;

import java.util.Scanner;

class CompararMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        //Compara c = new Compara();

        

        entrada.close();
    }
}
