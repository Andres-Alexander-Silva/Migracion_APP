package Ejercicio5;

import java.util.Scanner;

class CasaDeCambioMain {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        CasaDeCambio cc = new CasaDeCambio();

        cc.cantidadMonedas = entrada.nextInt();

        cc.simboloMonedas = new char[cc.cantidadMonedas];
        for (int i = 0; i < cc.simboloMonedas.length; i++){
            cc.simboloMonedas[i] = entrada.next().charAt(0);
        }

        cc.precioMonedas = new float[cc.cantidadMonedas];
        for (int j = 0; j < cc.precioMonedas.length; j++){
            cc.precioMonedas[j] = entrada.nextFloat();
        }

        cc.simboloAComprar = entrada.next().charAt(0);
        cc.simboloAPagar = entrada.next().charAt(0);
        cc.cantidadDinero = entrada.nextInt();

        cc.algoritmo();

        System.out.println("Valor a pagar: "+cc.valorAPagar+", en pesos $ "+cc.valorAPagarPesos);
        entrada.close();
    }
}
