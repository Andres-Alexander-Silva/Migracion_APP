package Ejercicio5;

public class CasaDeCambio {
    int cantidadMonedas,cantidadDinero;
    float valorMoneda1,valorMoneda2,valorAPagar,valorAPagarPesos,conversion;
    char[] simboloMonedas;
    float[] precioMonedas;
    char simboloAComprar,simboloAPagar;

    void algoritmo(){
        if (simboloAComprar != simboloAPagar){
            for (int i = 0; i < simboloMonedas.length; i++){
                if (simboloAComprar == simboloMonedas[i]){
                    valorMoneda1 = precioMonedas[i];
                }
                if (simboloAPagar == simboloMonedas[i]){
                    valorMoneda2 = precioMonedas[i];
                }
            }
            conversion = cantidadDinero * valorMoneda1;
            valorAPagar = conversion / valorMoneda2;
            valorAPagar = conversion;
        } else {
            valorAPagar = 0;
            valorAPagarPesos = 0;
        }

    }
}
