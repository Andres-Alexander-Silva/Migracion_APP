package Ejercicio8;

class SistemaNumeracionInvertida {
    long numCombertir,bDecimal,ocDecimal,b3Decimal,b5Decimal,b7Decimal;
    int baseOrigen;

    void algoritmo(){
        switch (baseOrigen){
            case 2:
                System.out.println("Decimal: "+BinarioADecimal());
                break;
            case 8:
                System.out.println("Decimal: "+OctalADecimal());
                break;
            case 3:
                System.out.println("Decimal: "+Base3ADecimal());
                break;
            case 5:
                System.out.println("Decimal: "+Base5Decimal());
                break;
            case 7:
                System.out.println("Decimal: "+Base7Decimal());
                break;
        }
    }

    public long BinarioADecimal(){
        long dig,num1=numCombertir,potencia=0,sum,sum1=0,decimal;
        while (num1 > 0){
            dig = num1 % 10;
            num1 /= 10;
            decimal = dig * (long) Math.pow(2,potencia);
            potencia++;
            sum = sum1 + decimal;
            sum1 = sum;
        }
        bDecimal = sum1;
        return bDecimal;
    }
    public long OctalADecimal(){
        long dig,exp=0,num=numCombertir;
        while (num > 0){
            dig = num % 10;
            ocDecimal += dig * (long) Math.pow(8,exp++);
            num /= 10;
        }
        return ocDecimal;
    }
    public long Base3ADecimal(){
        long dig,expo=0,num=numCombertir,potencia;
        while (num > 0){
            dig = num % 10;
            potencia = (long) Math.pow(3, expo++) * dig;
            b3Decimal += potencia;
            num /= 10;
        }
        return b3Decimal;
    }
    public long Base5Decimal(){
        long dig,expo=0,num=numCombertir,potencia;
        while (num > 0){
            dig = num % 10;
            potencia = (long) Math.pow(5, expo++) * dig;
            b5Decimal += potencia;
            num /= 10;
        }
        return b5Decimal;
    }
    public long Base7Decimal(){
        long dig,expo=0,num=numCombertir,potencia;
        while (num > 0){
            dig = num % 10;
            potencia = (long) Math.pow(7, expo++) * dig;
            b7Decimal += potencia;
            num /= 10;
        }
        return b7Decimal;
    }
}