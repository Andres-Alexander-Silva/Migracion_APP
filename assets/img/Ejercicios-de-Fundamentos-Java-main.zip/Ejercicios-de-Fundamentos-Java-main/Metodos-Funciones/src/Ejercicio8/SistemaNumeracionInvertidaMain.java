package Ejercicio8;

import java.util.Scanner;

class SistemaNumeracionInvertidaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        SistemaNumeracionInvertida sni = new SistemaNumeracionInvertida();

        sni.numCombertir = c.nextLong();
        sni.baseOrigen = c.nextInt();
        sni.algoritmo();

        c.close();
    }
}