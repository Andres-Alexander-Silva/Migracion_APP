package Ejercicio3;

class MovimientoCaballo {
    int posicionInicial;
    long secuencia;
    int posicionFinal;
    boolean valida;

    void principal(){
        valida = PosicionValida(posicionInicial);
        posicionFinal = movimientos(posicionInicial, secuencia);
        if(!valida||posicionFinal<=0){
            posicionFinal = 99;
        }
    }

    boolean PosicionValida(int posicionInicial){
        int noVale=posicionInicial%10;
        if((posicionInicial>=11&&posicionInicial<=88)&& noVale!=9){ 
            return true;
        }
        else {
            return false;
        }
    }

    int movimientos(int posicionInicial, long secuencia){
        long numero1;
        long copia=secuencia;
        long invertir = 0;
        while(copia>0){
            numero1 = copia%10;
            copia = copia/10;
            invertir = (invertir*10)+numero1;
        }      
        int copiaPosicion = posicionInicial;
        boolean validacion = true;
        while(invertir!=0){
            long movimiento = invertir%10;
            int fila = copiaPosicion/10;
            int columna = copiaPosicion%10;
            if(movimiento==1){
                copiaPosicion = ((fila + 2)*10) + (columna+1);
                validacion = true;
            }
            if(movimiento==2){
                copiaPosicion = ((fila + 1)*10) + (columna+2);
                validacion = true;
            }
            if(movimiento==3){
                copiaPosicion = ((fila - 1)*10) + (columna+2);
                validacion = true;
            }
            if(movimiento==4){
                copiaPosicion = ((fila - 2)*10) + (columna+1);
                validacion = true;
            }
            if(movimiento==5){
                copiaPosicion = ((fila - 2)*10) + (columna-1);
                validacion = true;
            }
            if(movimiento==6){
                copiaPosicion = ((fila - 1)*10) + (columna-2);
                validacion = true;
            }
            if(movimiento==7){
                copiaPosicion = ((fila + 1)*10) + (columna-2);
                validacion = true;
            }
            if(movimiento==8){
                copiaPosicion = ((fila + 2)*10) + (columna-1);
                validacion = true;
            }
            if(movimiento==0){
                //copiaPosicion = copiaPosicion;
                validacion = true;
            }
            if(movimiento==9){
                validacion = false;
                invertir = 0;
            }
            invertir = invertir/10;
        }
        if(!validacion){
            copiaPosicion=0;   
        }
        return copiaPosicion;
    }
}
