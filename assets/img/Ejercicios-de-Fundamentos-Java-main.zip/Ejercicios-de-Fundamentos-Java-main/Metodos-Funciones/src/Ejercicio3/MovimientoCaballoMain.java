package Ejercicio3;

import java.util.Scanner;

class MovimientoCaballoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        MovimientoCaballo m = new MovimientoCaballo();

        m.posicionInicial = c.nextInt();
        m.secuencia = c.nextInt();

        m.principal();

        System.out.println("Posición Final: "+m.posicionFinal);
        c.close();
    }
}
