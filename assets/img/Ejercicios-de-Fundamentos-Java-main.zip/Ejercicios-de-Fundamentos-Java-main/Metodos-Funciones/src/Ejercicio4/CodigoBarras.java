package Ejercicio4;

class CodigoBarras {
    long codigoB,invertido,precio,existencia,fechaV,dia,mes,anio,multiHexa;
    long par,impar,sumPar,sumImpar,nums16,multiImpar,diviPar,sumT,numLetra,numHexa;
    char letraH;
    String diaS,mesS;
    boolean verificacion;

    public void codigoDeBarras(){
        invertirNumero();
        if (digitoVerificacion()){
            extraerDatos();
            System.out.println("Precio: $"+precio);
            System.out.println("Existencias: "+existencia);
            System.out.println("Fecha Vencimiento: "+diaS+"/"+mesS+"/"+anio);
        } else {
            System.out.println("¡Código de Barras Inválido!");
        }
    }
    public long invertirNumero(){
        long dig,num16;
        num16 = codigoB / 10;
        while (num16 != 0){
            dig = num16 % 10;
            num16 /= 10;
            invertido = invertido * 10 + dig;
        }
        return invertido;
    }
    public void extraerDatos(){
        precio = (invertido / 100000)/1000000;
        existencia = (invertido / 100000000) % 1000;
        fechaV = invertido % 100000000;
        dia = fechaV / 1000000;
        if (dia >= 1 && dia <= 9) diaS = "0"+dia;
        else diaS = String.valueOf(dia);
        mes = (fechaV / 10000) % 100;
        if (mes >= 1 && mes <= 9) mesS = "0"+mes;
        else mesS = String.valueOf(mes);
        anio = fechaV % 10000;
    }
    public boolean digitoVerificacion(){
        nums16 = codigoB / 10;
        while (nums16 != 0){
            impar = nums16 % 10;
            nums16=nums16/10;
            par=nums16%10;
            nums16=nums16/10;
            multiImpar=impar*2;
            sumImpar=sumImpar+multiImpar;
            diviPar=par/2;
            sumPar=sumPar+diviPar;
        }
        sumT = sumImpar + sumPar;
        numHexa = codigoB % 10;
        if (letraH >= 65 && letraH <= 70){
            if (letraH == 65) numLetra = 10;
            if (letraH == 66) numLetra = 11;
            if (letraH == 67) numLetra = 12;
            if (letraH == 68) numLetra = 13;
            if (letraH == 69) numLetra = 14;
            if (letraH == 70) numLetra = 15;
        } else {
            if (letraH>= 48 && letraH <=57){
                if (letraH == 48) numLetra = 0;
                if (letraH == 49) numLetra = 1;
                if (letraH == 50) numLetra = 2;
                if (letraH == 51) numLetra = 3;
                if (letraH == 52) numLetra = 4;
                if (letraH == 53) numLetra = 5;
                if (letraH == 54) numLetra = 6;
                if (letraH == 55) numLetra = 7;
                if (letraH == 56) numLetra = 8;
                if (letraH == 57) numLetra = 9;
            }
        }
        multiHexa = (numHexa * 16) + numLetra;
        verificacion = multiHexa == sumT;
        return verificacion;
    }
}