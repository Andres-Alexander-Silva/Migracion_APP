package Ejercicio4;

import java.util.Scanner;

public class CodigoBarrasMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CodigoBarras cb = new CodigoBarras();

        cb.codigoB = c.nextLong(); cb.letraH = c.next().charAt(0);
        cb.codigoDeBarras();
        c.close();
    }
}
