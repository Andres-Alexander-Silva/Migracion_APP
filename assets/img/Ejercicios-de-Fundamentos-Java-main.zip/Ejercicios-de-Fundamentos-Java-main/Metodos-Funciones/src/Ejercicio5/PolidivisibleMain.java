package Ejercicio5;

import java.util.Scanner;

public class PolidivisibleMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Polidivisible pd = new Polidivisible();

        pd.numero = c.nextInt();

        if (pd.noEsPolidivisible(pd.numero)){
            System.out.println("NO");
        } else {
            System.out.println("SI");
        }
        c.close();
    }
}
