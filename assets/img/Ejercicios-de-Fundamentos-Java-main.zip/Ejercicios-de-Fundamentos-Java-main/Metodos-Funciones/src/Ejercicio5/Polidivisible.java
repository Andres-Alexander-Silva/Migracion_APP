package Ejercicio5;

public class Polidivisible {
    int numero,resultado;
    boolean noEsPolidivisible;

    public int logitud(int num){
        resultado = 1;
        while (num / 10 != 0){
            num /= 10;
            resultado++;
        }
        return resultado;
    }
    public boolean noEsPolidivisible(int numero){
        noEsPolidivisible = false;
        for (int i = logitud(numero); i > 0; i--){
            if (numero % i == 0){
                numero /= 10;
            } else {
                noEsPolidivisible = true;
            }
        }
        return noEsPolidivisible;
    }
}
