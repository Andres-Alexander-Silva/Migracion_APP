package Ejercicio7;

import java.util.Scanner;

public class SistemaNumeracionMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        SistemaNumeracion sn = new SistemaNumeracion();

        sn.numero = c.nextInt();

        System.out.println("Binario: "+sn.convertirABinario(sn.numero));
        System.out.println("Base 3: "+sn.convertirBase3(sn.numero));
        System.out.println("Base 5: "+sn.convertirBase5(sn.numero));
        System.out.println("Base 7: "+sn.convertirBase7(sn.numero));
        System.out.println("Octal: "+sn.convertirAOctal(sn.numero));
        
        c.close();
    }
}
