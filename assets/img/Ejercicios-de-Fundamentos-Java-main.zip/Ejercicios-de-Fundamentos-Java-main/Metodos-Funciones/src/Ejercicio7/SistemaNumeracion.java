package Ejercicio7;

public class SistemaNumeracion {
    int numero;
    long binario,octal,base3,base5,base7;

    public long convertirABinario (int num){
        int exp=0,digito;
        binario = 0;
        while (num != 0){
            digito = num % 2;
            binario += digito * Math.pow(10,exp);
            exp++;
            num /= 2;
        }
        return binario;
    }
    public long convertirAOctal(int num){
        int digito,place=1;
        octal = 0;
        while (num > 0){
           digito = num % 8;
           octal += digito * place;
           num /= 8;
           place *= 10;
        }
        return octal;
    }
    public long convertirBase3(int num){
        int dig,place=1;
        while (num > 0){
            dig = num % 3;
            base3 = dig*place + base3;
            num /= 3;
            place *= 10;
        }
        return base3;
    }
    public long convertirBase5(int num){
        int dig,place=1;
        while (num > 0){
            dig = num % 5;
            base5 = dig * place + base5;
            num /= 5;
            place *= 10; 
        }
        return base5;
    }
    public long convertirBase7(int num){
        int dig,place=1;
        while (num > 0){
            dig = num % 7;
            base7 = dig * place + base7;
            num /= 7;
            place *= 10; 
        }
        return base7;
    }
}
