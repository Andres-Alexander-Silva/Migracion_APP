package Ejercicio10;

class TheNextDay {
    int fecha;
    char letraDia;
    String aviso;
    boolean valido;

    int siguienteDia;
    int siguienteMes;
    int siguienteAño;

    void principal( ){
        int año=fecha/10000;
        int mes=fecha/100%100;
        int dia=fecha%100;
        valido=valida(dia,mes,año,letraDia);
        if ( letraDia=='S'){
            aviso=("Sunday");                    
        }
        if ( letraDia=='M'){
            aviso=("Monday ");
        }
        if (letraDia=='T'){
            aviso=("Tuesday");
        }
        if (letraDia=='W'){
            aviso=("Wednesday");
        }
        if( letraDia=='H'){
            aviso=("Thursday");
        }
        if ( letraDia=='F'){
            aviso=("Friday");
        }
        if(letraDia=='D'){
            aviso=("Saturday");
        }
        char diaSiguiente;
        diaSiguiente=diasemana(dia,mes,año,letraDia);
        if(letraDia!=diaSiguiente){
            while(letraDia!=diaSiguiente){
                if(año%4==0){
                    if(mes==2){
                        if(dia>=29){
                            dia=1;
                            mes++;
                        }
                        else{
                            dia++;
                        }
                    }
                    else{
                        if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
                            if(dia>=31){
                                dia=1;
                                mes++;
                            }
                            else{
                                dia++;
                            }

                        }
                        else{
                            if(mes>=12){
                                if(dia>=31){
                                    dia=1;
                                    mes=1;
                                    año++;
                                }
                                else{
                                    dia++;
                                }
                            }
                            else{
                                if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
                                    if(dia>=30){
                                        dia=1;
                                        mes++;
                                    }
                                    else{
                                        dia++;
                                    }
                                }
                            }
                        }
                    }
                }
                else{
                    if(mes==2){
                        if(dia>=28){
                            dia=1;
                            mes++;
                        }
                        else{
                            dia++;
                        }
                    }
                    else{
                        if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
                            if(dia>=31){
                                dia=1;
                                mes++;
                            }
                            else{
                                dia++;
                            }
                        }
                        else{
                            if(mes>11){
                                if(dia>=31){
                                    dia=1;
                                    mes=1;
                                    año++;
                                }
                                else{
                                    dia++;
                                }
                            }
                            else{
                                if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
                                    if(dia>=30){
                                        dia=1;  
                                        mes++;
                                    }
                                    else{
                                        dia++;
                                    }
                                }
                            }
                        }
                    }
                }
                diaSiguiente=diasemana(dia,mes,año,letraDia);
            }
            siguienteDia=dia;
            siguienteMes=mes;
            siguienteAño=año;
        }
        else{
            if(año%4==0){
                if(mes==2){
                    if(dia>=29){
                        dia=1;
                        mes++;
                    }
                    else{
                        dia++;
                    }
                }
                else{
                    if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
                        if(dia>=31){
                            dia=1;
                            mes++;
                        }
                        else{
                            dia++;
                        }

                    }
                    else{
                        if(mes>=12){
                            if(dia>=31){
                                dia=1;
                                mes=1;
                                año++;
                            }
                            else{
                                dia++;
                            }
                        }
                        else{
                            if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
                                if(dia>=30){
                                    dia=1;
                                    mes++;
                                }
                                else{
                                    dia++;
                                }
                            }
                        }
                    }
                }
            }
            else{
                if(mes==2){
                    if(dia>=28){
                        dia=1;
                        mes++;
                    }
                    else{
                        dia++;
                    }
                }
                else{
                    if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
                        if(dia>=31){
                            dia=1;
                            mes++;
                        }
                        else{
                            dia++;
                        }
                    }
                    else{
                        if(mes>11){
                            if(dia>=31){
                                dia=1;
                                mes=1;
                                año++;
                            }
                            else{
                                dia++;
                            }
                        }
                        else{
                            if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
                                if(dia>=30){
                                    dia=1;  
                                    mes++;
                                }
                                else{
                                    dia++;
                                }
                            }
                        }
                    }
                }
            }
            diaSiguiente=diasemana(dia,mes,año,letraDia);
            while(letraDia!=diaSiguiente){
                if(año%4==0){
                    if(mes==2){
                        if(dia>=29){
                            dia=1;
                            mes++;
                        }
                        else{
                            dia++;
                        }
                    }
                    else{
                        if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
                            if(dia>=31){
                                dia=1;
                                mes++;
                            }
                            else{
                                dia++;
                            }

                        }
                        else{
                            if(mes>=12){
                                if(dia>=31){
                                    dia=1;
                                    mes=1;
                                    año++;
                                }
                                else{
                                    dia++;
                                }
                            }
                            else{
                                if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
                                    if(dia>=30){
                                        dia=1;
                                        mes++;
                                    }
                                    else{
                                        dia++;
                                    }
                                }
                            }
                        }
                    }
                }
                else{
                    if(mes==2){
                        if(dia>=28){
                            dia=1;
                            mes++;
                        }
                        else{
                            dia++;
                        }
                    }
                    else{
                        if((mes==1)||(mes==3)||(mes==5)||(mes==7)||(mes==8)||(mes==10)){
                            if(dia>=31){
                                dia=1;
                                mes++;
                            }
                            else{
                                dia++;
                            }
                        }
                        else{
                            if(mes>11){
                                if(dia>=31){
                                    dia=1;
                                    mes=1;
                                    año++;
                                }
                                else{
                                    dia++;
                                }
                            }
                            else{
                                if((mes==4)||(mes==6)||(mes==9)||(mes==11)){
                                    if(dia>=30){
                                        dia=1;  
                                        mes++;
                                    }
                                    else{
                                        dia++;
                                    }
                                }
                            }
                        }
                    }
                }
                diaSiguiente=diasemana(dia,mes,año,letraDia);
            }
            siguienteDia=dia;
            siguienteMes=mes;
            siguienteAño=año;
        }


    }
    boolean valida(int dia, int mes, int año, char letraDia){
        boolean  fechaValida=((mes==11 && dia>0 &&dia<=30 ||mes==4 && dia>0 &&dia<=30||mes==6&& dia>0 &&dia<=30 || mes==9 && dia>0 &&dia<=30) ||
                (mes==1 && dia>0 && dia <=31||mes==3 && dia>0 && dia <=31 ||mes==5 && dia>0 && dia <=31 ||mes==7 && dia>0 && dia <=31||
                    mes==8 && dia>0 && dia <=31 ||mes==10 && dia>0 && dia <=31||mes==12 && dia>0 && dia <=31)||
                (mes==2 && dia>0 && dia<=28 || mes==2 && dia>0 && dia<=29 && (año % 4 == 0) && (año % 100 != 0) || (año % 400 == 0))) ;
        return fechaValida;
    } 

    char diasemana(int dia, int mes, int año, char letraDia){
        int diaZeller;
        int factorCorecion;
        int mesZeller;
        int añoZeller;
        int añoBisiesto;
        int añosZellerCompletos;
        int corecionAñosCentenarios;
        char dia1Siguiente=letraDia;
        factorCorecion=(14-mes)/12;
        mesZeller=(mes-2)+(12*factorCorecion);
        añoZeller=año-factorCorecion;
        añoBisiesto=((añoZeller*1)/400 );
        añosZellerCompletos= (31*mesZeller)/12;
        corecionAñosCentenarios=((año*1)/100);
        diaZeller= ((( dia + añoZeller+ ( (añoZeller*1)/4) - corecionAñosCentenarios + añoBisiesto + añosZellerCompletos ) )%7);
        if(diaZeller==0){
            dia1Siguiente=83;
        }
        if(diaZeller==1){
            dia1Siguiente=77;
        }
        if(diaZeller==2){
            dia1Siguiente=84;
        }
        if(diaZeller==3){
            dia1Siguiente=87;
        }
        if(diaZeller==4){
            dia1Siguiente=72;
        }
        if(diaZeller==5){
            dia1Siguiente=70;
        }
        if(diaZeller==6){
            dia1Siguiente=68;
        }
        return dia1Siguiente;
    }
}