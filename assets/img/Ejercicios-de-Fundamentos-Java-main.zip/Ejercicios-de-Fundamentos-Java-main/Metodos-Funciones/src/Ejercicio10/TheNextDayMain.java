package Ejercicio10;

import java.util.Scanner;

class TheNextDayMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TheNextDay n = new TheNextDay();

        n.fecha = c.nextInt();
        n.letraDia = c.next().charAt(0);
        n.principal();

        if(n.valido){
            System.out.println("The next"+ n.aviso + " is " + String.format("%02d/%02d",n.siguienteDia,n.siguienteMes)  + "/"+ n.siguienteAño);
        }
        else{
            System.out.println("Datos de entrada inválidos");
        }
        
        c.close();
    }    
}
