package Ejercicio9;

class ParejaIdeal {
    int fecha1,fecha2;
    int año1,año2,mes1,mes2,dia1,dia2;
    String aviso;
    boolean años,digitoSemilla,fechasadyacentes,faseLunar,mesDia;

    void algoritmo( ){
        año1=fecha1/10000;
        mes1=fecha1/100%100;
        dia1=fecha1%100;
        año2=fecha2/10000;
        mes2=fecha2/100%100;
        dia2=fecha2%100;
        años= año1==año2;
        digitoSemilla=semilla(fecha1,fecha2);
        fechasadyacentes=adyacente(fecha1,fecha2);
        faseLunar=lunaFase(fecha1,fecha2);
        mesDia=restaMesDia(fecha1,fecha2);

    }
    boolean restaMesDia(int fecha1, int fecha2){
        int mes1=fecha1/100%100;
        int dia1=fecha1%100;
        int mes2=fecha2/100%100;
        int dia2=fecha2%100;
        int restames= Math.abs(mes1-mes2);
        int restadia= Math.abs(dia1-dia2);
        boolean restas= (restames==restadia);
        return restas;
    }
    boolean lunaFase(int fecha1, int fecha2){
        int año1=fecha1/10000;
        int mes1=fecha1/100%100;
        int dia1=fecha1%100;
        int numeroAureo1;
        int epactaAño1;
        int epactaFecha1=0;
        int total1;
        numeroAureo1=(año1+1)%19;
        epactaAño1=((numeroAureo1-1)*11)%30;
        if (mes1==1 || mes1==3){
            epactaFecha1= dia1;
        }
        if ( mes1==2){
            epactaFecha1= dia1+1;
        }
        if (mes1==4 || mes1==5 || mes1==6 || mes1==7 || mes1==8 || mes1==9 || mes1==10 || mes1==11 || mes1==12 ){
            epactaFecha1= (mes1-3)+dia1;
        }
        total1=epactaAño1 + epactaFecha1;
        if (total1 >= 30){
            total1%=30;
        }
        int año2=fecha2/10000;
        int mes2=fecha2/100%100;
        int dia2=fecha2%100;
        int numeroAureo2;
        int epactaAño2;
        int epactaFecha2=0;
        int total2;
        numeroAureo2=(año2+1)%19;
        epactaAño2=((numeroAureo2-1)*11)%30;
        if (mes2==1 || mes2==3){
            epactaFecha2= dia2;
        }
        if ( mes2==2){
            epactaFecha2= dia2+1;
        }
        if (mes2==4 || mes2==5 || mes2==6 || mes2==7 || mes2==8 || mes2==9 || mes2==10 || mes2==11 || mes2==12 ){
            epactaFecha2= (mes2-3)+dia2;
        }
        total2=epactaAño2 + epactaFecha2;
        if (total2 >= 30){
            total2%=30;
        }
        boolean faseLunar;
        if((total1>=0 && total1 <=6||total1==29) && (total2>=0 && total2 <=6||total2==29)){
            faseLunar=true;
        }
        else{
            if((total1>=7 && total1<=13)&&(total2>=7 && total2<=13)){
                faseLunar=true;
            }else{
                if((total1>=14 && total1<=20)&&(total2>=14 && total2<=20)){
                    faseLunar=true;
                }
                else{
                    if((total1>=21 && total1<=28)&&(total2>=21 && total2<=28)){
                        faseLunar=true;
                    }
                    else{
                        faseLunar=false;
                    }
                }
            }
        }
        return faseLunar;
    }

    boolean adyacente(int fecha1, int fecha2){
        int año1=fecha1/10000;
        int mes1=fecha1/100%100;
        int dia1=fecha1%100;
        int diaZeller1;
        int factorCorecion1;
        int mesZeller1;
        int añoZeller1;
        int añoBisiesto1;
        int añosZellerCompletos1;
        int corecionAñosCentenarios1;
        factorCorecion1=(14-mes1)/12;
        mesZeller1=(mes1-2)+(12*factorCorecion1);
        añoZeller1=año1-factorCorecion1;
        añoBisiesto1=((añoZeller1*1)/400 );
        añosZellerCompletos1= (31*mesZeller1)/12;
        corecionAñosCentenarios1=((año1*1)/100);
        diaZeller1= ((( dia1 + añoZeller1+ ( (añoZeller1*1)/4) - corecionAñosCentenarios1 + añoBisiesto1 + añosZellerCompletos1 ) )%7);

        int año2=fecha2/10000;
        int mes2=fecha2/100%100;
        int dia2=fecha2%100;
        int diaZeller2;
        int factorCorecion2;
        int mesZeller2;
        int añoZeller2;
        int añoBisiesto2;
        int añosZellerCompletos2;
        int corecionAñosCentenarios2;
        factorCorecion2=(14-mes2)/12;
        mesZeller2=(mes2-2)+(12*factorCorecion2);
        añoZeller2=año2-factorCorecion2;
        añoBisiesto2=((añoZeller2*1)/400 );
        añosZellerCompletos2= (31*mesZeller2)/12;
        corecionAñosCentenarios2=((año2*1)/100);
        diaZeller2= ((( dia2 + añoZeller2+ ( (añoZeller2*1)/4) - corecionAñosCentenarios2 + añoBisiesto2 + añosZellerCompletos2 ) )%7);
        boolean fechasadyacentes;
        fechasadyacentes=((diaZeller1==0 && diaZeller2==1)||(diaZeller1==1 && diaZeller2==2)||(diaZeller1==2 && diaZeller2==3)||
        (diaZeller1==3 && diaZeller2==4)||(diaZeller1==4 && diaZeller2==5)||(diaZeller1==5 && diaZeller2==6) ||
        (diaZeller1==6 && diaZeller2==5)||(diaZeller1==5 && diaZeller2==4)||
        (diaZeller1==4 && diaZeller2==3)||(diaZeller1==3 && diaZeller2==2)||(diaZeller1==2 && diaZeller2==1)|| 
        (diaZeller1==1 && diaZeller2==0));
        return fechasadyacentes;
    }

    boolean semilla(int fecha1,int fecha2){
        int suma=0;
        boolean sumatoria;
        while(fecha1!=0){
            int digito=fecha1%10;
            suma=suma+digito;
            fecha1=fecha1/10;
        }
        while (suma>9){
            int n=suma%10;
            int m=suma/10;
            suma=n+m;
        }
        int suma2=0;
        while(fecha2!=0){
            int digito=fecha2%10;
            suma2=suma2+digito;
            fecha2=fecha2/10;
        }
        while(suma2>9){
            int n2=suma2%10;
            int m2=suma2/10;
            suma2=n2+m2;
        }

        sumatoria=suma==suma2;
        return sumatoria;
    }
}