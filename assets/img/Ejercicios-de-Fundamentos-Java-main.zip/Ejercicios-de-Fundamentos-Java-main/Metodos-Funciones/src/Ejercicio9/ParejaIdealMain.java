package Ejercicio9;

import java.util.Scanner;

class ParejaIdealMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        ParejaIdeal ideal = new ParejaIdeal();

        ideal.fecha1 = c.nextInt();
        ideal.fecha2 = c.nextInt();

        ideal.algoritmo();

        if(ideal.años && ideal.digitoSemilla && ideal.fechasadyacentes && ideal.faseLunar && ideal.mesDia){
            System.out.println("\u2605"+"\u2605"+"\u2605"+"\u2605"+"\u2605");
        }
        else{
            if((ideal.años && ideal.digitoSemilla &&  ideal.fechasadyacentes && ideal.faseLunar)||(ideal.años && ideal.digitoSemilla &&  ideal.faseLunar && ideal.mesDia)||
            (ideal.años && ideal.fechasadyacentes &&  ideal.faseLunar && ideal.mesDia)||(ideal.digitoSemilla &&  ideal.fechasadyacentes && ideal.faseLunar && ideal.mesDia)){
                System.out.println("\u2605"+"\u2605"+"\u2605"+"\u2605");
            }
            else{
                if((ideal.años && ideal.digitoSemilla &&  ideal.fechasadyacentes)||(ideal.años && ideal.digitoSemilla &&  ideal.faseLunar)||
                (ideal.años && ideal.digitoSemilla &&  ideal.mesDia)|| (ideal.años && ideal.fechasadyacentes &&  ideal.faseLunar)|| 
                (ideal.años && ideal.faseLunar &&  ideal.mesDia)||
                (ideal.digitoSemilla && ideal.fechasadyacentes && ideal.faseLunar)||(ideal.digitoSemilla && ideal.fechasadyacentes && ideal.mesDia)
                ||(ideal.digitoSemilla && ideal.faseLunar && ideal.mesDia)||
                (ideal.fechasadyacentes && ideal.faseLunar && ideal.mesDia)){
                    System.out.println("\u2605"+"\u2605"+"\u2605");
                }
                else{
                    if((ideal.años && ideal.digitoSemilla)||(ideal.años && ideal.fechasadyacentes)||(ideal.años && ideal.faseLunar)||((ideal.años && ideal.mesDia)||
                        (ideal.digitoSemilla  && ideal.fechasadyacentes)||(ideal.digitoSemilla  && ideal.faseLunar)||(ideal.digitoSemilla  && ideal.mesDia) ||
                        (ideal.fechasadyacentes && ideal.faseLunar)||(ideal.fechasadyacentes && ideal.mesDia)||(ideal.faseLunar &&ideal.mesDia))){
                            System.out.println("\u2605"+"\u2605");
                    }
                    else{
                        if(ideal.años||ideal.digitoSemilla||ideal.fechasadyacentes||ideal.faseLunar||ideal.mesDia){
                            System.out.println("\u2605");
                        }
                        else{
                            if(!ideal.años && !ideal.digitoSemilla && !ideal.fechasadyacentes && !ideal.faseLunar && !ideal.mesDia){
                                System.out.println("!");
                            }
                        }
                    }
                }
            }
        }
        c.close();
    }
}
