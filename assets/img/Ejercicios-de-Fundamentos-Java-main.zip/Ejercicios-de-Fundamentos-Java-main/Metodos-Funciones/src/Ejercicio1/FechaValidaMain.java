package Ejercicio1;

import java.util.Scanner;

class FechaValidaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        FechaValida fv = new FechaValida();

        fv.dia = c.nextInt();
        fv.mes = c.next().charAt(0);
        fv.anio = c.nextInt();

        fv.CalcularFechaValida();
        c.close();
    }
}
