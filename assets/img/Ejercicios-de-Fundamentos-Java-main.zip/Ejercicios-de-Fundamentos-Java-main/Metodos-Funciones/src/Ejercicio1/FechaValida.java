package Ejercicio1;

import java.util.GregorianCalendar;

class FechaValida {
    GregorianCalendar bisiesto = new GregorianCalendar();
    int dia,anio;
    char mes;

    void CalcularFechaValida(){
        if ((mes == 'E' && dia > 0 && dia <= 31) || (mes == 'F' && dia >0 && dia <= 29 && bisiesto.isLeapYear(anio)) || (mes == 'M' && dia > 0 && dia <= 31) ||
                (mes == 'A' && dia > 0 && dia <= 30) || (mes == 'Y' && dia > 0 && dia <= 31 ) || (mes == 'J' && dia > 0 && dia <= 30) ||
                (mes == 'L' && dia > 0 && dia <= 31) || (mes == 'G' && dia > 0 && dia <= 31) || (mes == 'S' && dia > 0 && dia <= 30) ||
                (mes == 'O' && dia > 0 && dia <= 31) || (mes == 'N' && dia > 0 && dia <= 30) || (mes == 'D' && dia > 0 && dia <= 31)){
            System.out.println("Fecha Válida");
        }
        if (((mes == 'E'&& dia >= 0 && dia <= 31) || (mes == 'F' && dia >= 0 && dia <= 29 && bisiesto.isLeapYear(anio)) || (mes == 'M' && dia >= 0 && dia <= 31)
                || (mes == 'A' && dia >= 0 && dia <= 30) || (mes == 'Y' && dia >= 0 && dia <= 31) || (mes == 'J' && dia >= 0 && dia <= 30) ||
                (mes == 'L' && dia >= 0 && dia <= 31) || (mes == 'G' && dia >= 0 && dia <= 31) || (mes == 'S' && dia >= 0 && dia <= 30) ||
                (mes == 'O' && dia >= 0 && dia <= 31) || ( mes == 'N' && dia >= 0 && dia <= 30) || (mes == 'D' && dia >= 0 && dia <= 31))==false){//
            System.out.println("Fecha No Válida");
        }
        if (((mes == 'E' && dia > 0 && anio > 0) || (mes == 'F' && dia > 0 && anio > 0) || (mes == 'M' && dia > 0 && anio > 0) ||
                (mes == 'A' && dia > 0 && anio > 0) || (mes == 'Y' && dia > 0 && anio > 0) || (mes == 'J' && dia > 0 && anio > 0) ||
                (mes == 'L' && dia > 0 && anio > 0) || (mes == 'G' && dia > 0 && anio > 0) || (mes == 'S' && dia > 0 && anio > 0) ||
                (mes == 'O' && dia > 0 && anio > 0) || (mes == 'N' && dia > 0 && anio > 0) || (mes == 'D' && dia > 0 && anio > 0))==false){
            System.out.println("Datos de entrada incorrectos");
        }
    }
}