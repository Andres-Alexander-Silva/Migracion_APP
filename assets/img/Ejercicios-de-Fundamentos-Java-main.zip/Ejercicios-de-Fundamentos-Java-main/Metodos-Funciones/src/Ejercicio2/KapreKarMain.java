package Ejercicio2;

import java.util.Scanner;

class KapreKarMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        KapreKar kp = new KapreKar();

        kp.numero = c.nextInt();
        kp.ConstanteKprecar();
        c.close();
    }
}
