package ejemplo1;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner();
        PrintWriter bw = new PrintWriter(System.out);

        int n = Integer.parseInt(sc.next());

        while (n > 0){
            int a = Integer.parseInt(sc.next());
            int b = Integer.parseInt(sc.next());
            if (a > b) bw.println("perdimos");
            if(b > a) bw.println("ganamos");
            if(a == b) bw.println("casi ganamos");
            n--;
        }

        bw.flush();
    }
    static class Scanner {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer("");
        int spaces = 0;
    
        public String nextLine() throws IOException {
            if (spaces-- > 0) return "";
            else if (st.hasMoreTokens()) return new StringBuilder(st.nextToken("\n")).toString();
            return br.readLine();
        }
    
        public String next() throws IOException {
            spaces = 0;
            while (!st.hasMoreTokens()) st = new StringTokenizer(br.readLine());
            return st.nextToken();
        }
    
        public boolean hasNext() throws IOException {
            while (!st.hasMoreTokens()) {
                String line = br.readLine();
                if (line == null) return false;
                if (line.equals("")) spaces = Math.max(spaces, 0) + 1;
                st = new StringTokenizer(line);
            }
            return true;
        }
    }
}