package EjercicioE;

import java.io.*;
import java.util.*;

public class Join {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner();
        PrintWriter bw = new PrintWriter(System.out);

        int cc = Integer.parseInt(sc.next());
        //int p = Integer.parseInt(sc.next());

        while (cc > 0){
            int pj = Integer.parseInt(sc.next());
            //int v = Integer.parseInt(sc.next());
            
            if (cc <= pj){
                
            }
        }

        bw.flush();
    }
    static class Scanner {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer("");
        int spaces = 0;
    
        public String nextLine() throws IOException {
            if (spaces-- > 0) return "";
            else if (st.hasMoreTokens()) return new StringBuilder(st.nextToken("\n")).toString();
            return br.readLine();
        }
    
        public String next() throws IOException {
            spaces = 0;
            while (!st.hasMoreTokens()) st = new StringTokenizer(br.readLine());
            return st.nextToken();
        }
    
        public boolean hasNext() throws IOException {
            while (!st.hasMoreTokens()) {
                String line = br.readLine();
                if (line == null) return false;
                if (line.equals("")) spaces = Math.max(spaces, 0) + 1;
                st = new StringTokenizer(line);
            }
            return true;
        }
    }
}
