package EjercicioI;

import java.io.*;
import java.util.*;

public class Ivan {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner();
        
        int t,c,b,g,cc,i=0;
        int[] juegos;

        t = Integer.parseInt(sc.next());
        juegos = new int[t];
        while(t>0){
            int mayor=0;
            c = Integer.parseInt(sc.next());
            b = Integer.parseInt(sc.next());
            while(c > 0){
                cc = Integer.parseInt(sc.next());
                g = Integer.parseInt(sc.next());
                if (cc <= b){
                    if(g > mayor){
                        mayor = g;
                        
                    }
                   juegos[i] = mayor; 
                }
                c--;
            }
            t--;
            i++;
        }
        for ( i =0; i < juegos.length; i++){
            System.out.println(juegos[i]);
            
        }
    }
    static class Scanner {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer("");
        int spaces = 0;
    
        public String nextLine() throws IOException {
            if (spaces-- > 0) return "";
            else if (st.hasMoreTokens()) return new StringBuilder(st.nextToken("\n")).toString();
            return br.readLine();
        }
    
        public String next() throws IOException {
            spaces = 0;
            while (!st.hasMoreTokens()) st = new StringTokenizer(br.readLine());
            return st.nextToken();
        }
    
        public boolean hasNext() throws IOException {
            while (!st.hasMoreTokens()) {
                String line = br.readLine();
                if (line == null) return false;
                if (line.equals("")) spaces = Math.max(spaces, 0) + 1;
                st = new StringTokenizer(line);
            }
            return true;
        }
    }
}