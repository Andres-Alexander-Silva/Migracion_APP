package Ejercicio2;

import java.util.Scanner;

class PowMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Pow p = new Pow();

        p.base = c.nextInt();
        p.exponente = c.nextInt();

        p.CalcularPotencia();

        System.out.println("La potencia de "+p.base+" con exponente "+p.exponente+" es: "+p.potencia);
        c.close();
    }
}
