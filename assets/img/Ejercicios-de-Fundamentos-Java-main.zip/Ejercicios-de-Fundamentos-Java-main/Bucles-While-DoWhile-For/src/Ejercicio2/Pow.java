package Ejercicio2;

class Pow {
    long base,exponente;
    long potencia=1,i=1;

    void CalcularPotencia(){
        while (i < exponente){
            potencia *= base;
            i += 1;
        }
    }
}
