package ExplicacionMVC;

class SistemaNum {
    
}
