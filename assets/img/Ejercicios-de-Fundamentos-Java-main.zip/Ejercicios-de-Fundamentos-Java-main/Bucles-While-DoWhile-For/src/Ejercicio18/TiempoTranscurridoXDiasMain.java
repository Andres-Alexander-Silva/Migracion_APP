package Ejercicio18;

import java.util.Scanner;

class TiempoTranscurridoXDiasMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TiempoTranscurridoXDias temp = new TiempoTranscurridoXDias();

        temp.fecha2 = c.nextInt();
        temp.dias = c.nextInt();
        temp.TiempoXDias();

        System.out.println("Dentro de "+temp.dias+" días será "+String.format("%02d/%02d",temp.dia2,temp.mes2)+"/"+temp.año2);
        c.close();
    }
}