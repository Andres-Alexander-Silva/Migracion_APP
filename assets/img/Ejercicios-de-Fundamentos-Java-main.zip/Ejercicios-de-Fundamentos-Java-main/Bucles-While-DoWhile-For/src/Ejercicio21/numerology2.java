package Ejercicio21;

class numerology2 {
    long numero,sumaResiduo,digito=0;
    boolean divExacto;
    
    void algoritmo(){
        long numero1 = numero,division;
        while (numero1 > 0){
            division = numero1 % 10;
            if (division > 1){
                boolean divisor = numero % division == 0;
                if (divisor){
                    sumaResiduo = division + sumaResiduo;
                }
            }
            numero1 = numero1 / 10;
        }
        if (numero > 0){
            divExacto = numero % sumaResiduo == 0;
        }
    }
}