package Ejercicio21;

import java.util.Scanner;

class numerology2Main {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        numerology2 n2 = new numerology2();

        n2.numero = c.nextLong();
        n2.algoritmo();

        String numS = String.valueOf(n2.numero); 

        if (numS.length() >= 18){
            if(n2.divExacto){
                System.out.println("¡Buena Suerte: juegue en la lotería el número "+n2.sumaResiduo+" y será millonario!");
            } else {
                System.out.println("¡Incertidumbre: pruebe su suerte en la lotería con el número "+n2.sumaResiduo+"!");
            }
        } else {
            System.out.println("¡Mala Suerte!");
        }

        c.close();
    }
}
