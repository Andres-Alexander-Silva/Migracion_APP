package Ejercicio3;

import java.util.Scanner;

class ContadorDeDigitosMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        ContadorDeDigitos cd = new ContadorDeDigitos();

        cd.numero = c.nextLong();

        cd.CalcularDigitos();

        System.out.println(cd.numDigitos);
        c.close();
    }
}
