package Ejercicio3;

class ContadorDeDigitos {
    long numero;
    long numDigitos;

    void CalcularDigitos(){
        if (numero >= 0 && numero <= 9){
            numDigitos = 1;
        }
        else {
            while (numero != 0){
                numero /= 10;
                numDigitos++;
            }
        }
    }
}
