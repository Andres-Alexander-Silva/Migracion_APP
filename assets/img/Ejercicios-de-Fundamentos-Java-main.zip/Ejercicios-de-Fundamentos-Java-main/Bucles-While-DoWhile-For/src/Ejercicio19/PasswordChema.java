package Ejercicio19;

class PasswordChema {
    long contrasena;
    char tipoContrasena;
    
    public String algoritmo(){
        String aviso="";
        
        if (contrasena>0){
            switch (tipoContrasena){
                case 'S':
                    long numero = contrasena;
                    int cifra = (int)(numero % 10);
                    int contador=0;
                    int digito = cifra;
                    String clave="";
                    while (numero>0){
                        if (digito==cifra)
                            contador++;
                        else {
                            clave = contador + "" + digito + clave;
                            digito=cifra;
                            contador=1;
                        }
                        numero = numero / 10;
                        cifra = (int)(numero % 10);
                        if (contador>9) {
                            aviso = "¡Desbordamiento!";
                            break;
                        }
                    }
                    if (aviso.equals("")){
                        clave = contador + "" + digito + clave;
                        int digitos = clave.length();
                        if (digitos>18)
                            aviso = "¡Desbordamiento!";
                        else {
                            long claveL = Long.parseLong(clave);
                            numero= claveL;
                            cifra = (int)(numero % 10);
                            clave = "";
                            while (numero>0){
                                int nuevaCifra = 10 - cifra;
                                if (nuevaCifra==10) nuevaCifra=0;
                                clave = nuevaCifra + "" + clave;
                                numero = numero / 10;
                                cifra = (int)(numero % 10);
                            }
                            aviso = "Clave compleja: " + clave;                                                        
                        }
                    }
                    break;
                case 'C':
                    numero = contrasena;
                    cifra = (int)(numero % 10);
                    clave="";
                    while (numero>0){
                        int nuevaCifra = 10 - cifra;
                        if (nuevaCifra==10) nuevaCifra = 0;
                        numero /= 10;
                        clave = nuevaCifra + clave;
                    }
                    numero = Long.parseLong(clave);
                    cifra = (int)(numero % 100); 
                    clave = "";
                    contador=0;
                    while (numero>0){
                        int cifra1 = cifra % 10;
                        int cifra2 = cifra / 10;
                        
                        while(contador<=cifra2){
                            clave = cifra1 + clave;
                            contador++;
                        }
                        numero = numero / 10; 
                        cifra = (int)(numero % 100); 
                    }
                    if (contador>18)
                        aviso = "¡Desbordamiento!";
                    else
                        aviso = "Clave simple: " + clave;
                    break;
                default:
                   aviso = "¡El Chema no te entiende, tío!"; 
            }
        } else {
            aviso = "¡El Chema no te entiende, tío!";
        }
        return aviso;
    }
}