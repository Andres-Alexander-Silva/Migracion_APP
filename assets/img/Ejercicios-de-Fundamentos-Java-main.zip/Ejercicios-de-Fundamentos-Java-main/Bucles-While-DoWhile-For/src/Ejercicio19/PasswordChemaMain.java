package Ejercicio19;

import java.util.Scanner;

class PasswordChemaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        PasswordChema pwc = new PasswordChema();

        pwc.contrasena = c.nextLong();
        pwc.tipoContrasena = c.next().charAt(0);

        System.out.println(pwc.algoritmo());
        c.close();
    }
}