package Ejercicio7;

class BinarioDecimal {
    long numero;
    String aviso;
    long variable,numero2,decimal,suma,suma1,numero3,invalido;
    int p=0;
    boolean invalidos;
    void CalcularBinarioDecimal( ){
        numero2=numero;

        while (numero2>0){
            variable=numero2%10;
            numero2=numero2/10;
            decimal=variable*(int)Math.pow(2,p);
            p++;
            suma=suma1+decimal;
            suma1=suma;
        }
        invalido=(numero/10)%10;
        long invalido2;
        invalido2=numero%10;

        if (invalido!=0 && invalido!=1 || invalido2!=0 && invalido2!=1){
            invalidos=true;
        }

        if (invalidos){
            aviso="Datos Inválidos";
        }
        else {
            aviso=("Decimal: " + suma1);
        }
    }
}