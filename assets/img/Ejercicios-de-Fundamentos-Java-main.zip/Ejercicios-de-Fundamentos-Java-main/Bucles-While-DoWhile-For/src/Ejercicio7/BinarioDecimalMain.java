package Ejercicio7;

import java.util.Scanner;

class BinarioDecimalMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        BinarioDecimal bd = new BinarioDecimal();

        bd.numero = c.nextLong();

        bd.CalcularBinarioDecimal();
        c.close();
    }
}
