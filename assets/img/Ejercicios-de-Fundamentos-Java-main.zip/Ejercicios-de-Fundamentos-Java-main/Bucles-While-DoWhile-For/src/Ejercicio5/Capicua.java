package Ejercicio5;

class Capicua {
    long numero,numeroInvertido;
    String cadena,cadenaInv="";

    void CalcularCapicua(){
        cadena = String.valueOf(numero);
        for (int i = 0; i < cadena.length(); i++){
            cadenaInv = cadena.charAt(i) + cadenaInv;
        }
        if (cadena.equals(cadenaInv)){
            System.out.println("Capicúa: SI");
        } else {
            System.out.println("Capicúa: NO");
        }
    }
}