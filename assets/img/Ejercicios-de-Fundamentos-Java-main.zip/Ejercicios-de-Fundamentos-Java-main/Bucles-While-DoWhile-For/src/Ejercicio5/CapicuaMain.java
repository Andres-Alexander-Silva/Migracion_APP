package Ejercicio5;

import java.util.Scanner;

class CapicuaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Capicua cp = new Capicua();

        cp.numero = c.nextLong();

        cp.CalcularCapicua();
        c.close();
    }
}
