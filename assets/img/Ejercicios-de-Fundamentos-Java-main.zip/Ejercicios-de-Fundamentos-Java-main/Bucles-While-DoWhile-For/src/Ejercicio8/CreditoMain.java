package Ejercicio8;

import java.util.Scanner;

class CreditoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Credito ct = new Credito();

        ct.valorTC = c.nextDouble();
        ct.tasaIM = c.nextDouble();
        ct.cantidadM = c.nextDouble();

        ct.CalcularCredito();

        System.out.println("El total a pagar por intereses es: "+ct.interesPagado);
        c.close();
    }
}
