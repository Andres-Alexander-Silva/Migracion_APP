package Ejercicio8;

class Credito {
    double valorTC,tasaIM,cantidadM;
    double interesPagado;

    void CalcularCredito(){
        double valorC = valorTC / cantidadM;
        double saldo = valorTC;
        double interes = 0;
        interesPagado = 0;
        for (int i = 1;i<=cantidadM;i++){
            interes = (saldo * tasaIM) / 100;
            saldo -= valorC;
            interesPagado += interes;
        }
    }
}
