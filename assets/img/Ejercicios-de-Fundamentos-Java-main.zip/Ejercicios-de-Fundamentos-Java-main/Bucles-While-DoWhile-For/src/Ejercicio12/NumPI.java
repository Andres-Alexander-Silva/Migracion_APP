package Ejercicio12;

class NumPI {
    int numeroS,n,nVeces;

    public double Aproximacion(){
        double aprox = 3.0;
        n = 2;
        nVeces = 1;
        while (nVeces <=numeroS){
            if (nVeces % 2 == 1) aprox += (4.0/(n*(n+1)*(n+2)));
            else aprox -= (4.0/(n*(n+1)*(n+2)));
            n+=2;
            nVeces++;
        }
        return aprox;
    }
}
