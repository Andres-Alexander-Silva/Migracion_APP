package Ejercicio12;

import java.util.Scanner;

class NumPIMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        NumPI pi = new NumPI();

        pi.numeroS = c.nextInt();

        System.out.println("Pi aproximado: "+pi.Aproximacion());
        c.close();
    }
}
