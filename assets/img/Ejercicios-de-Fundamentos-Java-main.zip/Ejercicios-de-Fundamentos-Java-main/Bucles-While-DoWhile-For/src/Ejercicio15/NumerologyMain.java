package Ejercicio15;

import java.util.Scanner;

class NumerologyMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Numerology ng = new Numerology();

        ng.numero = c.nextLong();
        ng.Numerologia();
        c.close();
    }
}
