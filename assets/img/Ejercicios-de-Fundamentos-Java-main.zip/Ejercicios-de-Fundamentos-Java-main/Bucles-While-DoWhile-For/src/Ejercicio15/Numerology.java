package Ejercicio15;

class Numerology {
    long numero,numDiv,num,dig;
    String aviso="";
    boolean numerology,divisibilidad;

    void Numerologia(){
        num = numero;
        while (numero > 1){
            dig = numero % 10;
            if (dig > 1){
                divisibilidad = num % dig == 0;
                if (divisibilidad) numDiv++;
            }
            numero /= 10;
        }
        if (numDiv > 1) numerology = num % numDiv == 0;
        else numerology = false;
        if (numerology) System.out.println("Dígitos Divisores = "+numDiv+". Cumple = SI.");
        else System.out.println("Dígitos Divisores = "+numDiv+". Cumple = NO.");
    }
}
