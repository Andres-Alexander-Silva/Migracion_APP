package Ejercicio9;

class CreditoEntero {
    int valorTC,tasaIM,cantidadM;
    int interesPagado;

    void CalcularCredito(){
        int valorC = valorTC / cantidadM;
        int saldo = valorTC;
        int interes = 0;
        interesPagado = 0;
        for (int i = 0;i<=cantidadM;i++){
            interes = (saldo * tasaIM) / 100;
            saldo -= valorC;
            interesPagado += interes;
        }
    }
}
