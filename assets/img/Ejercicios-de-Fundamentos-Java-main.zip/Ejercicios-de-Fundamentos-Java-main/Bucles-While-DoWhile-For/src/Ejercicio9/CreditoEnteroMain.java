package Ejercicio9;

import java.util.Scanner;

class CreditoEnteroMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CreditoEntero cte = new CreditoEntero();

        cte.valorTC = c.nextInt();
        cte.tasaIM = c.nextInt();
        cte.cantidadM = c.nextInt();

        cte.CalcularCredito();

        System.out.println("El total a pagar por intereses es: "+cte.interesPagado);
        c.close();
    }
}
