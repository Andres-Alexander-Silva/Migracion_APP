package Ejercicio14;

class SimpleBigLong {
    long num1,num2;
    long numeroS1,numeroS2;

    void sumaLong(){
        long separacion1,separacion2,lleva=0,suma=0,potencia=1,n=1,numero=0,cero=0;
        numeroS1 = 0;
        long numero1 = num1,numero2 = num2;
        while (numero1>0 || numero2>0){
            separacion1 = numero1 % 10;
            separacion2 = numero2 % 10;
            suma = (separacion1+separacion2)+lleva;
            if (n == 18){
                numeroS2 = numero;
                numero = 0;
                potencia = cero;
            }
            lleva = suma / 10;
            suma = suma % 10;
            if (suma == 0){
                cero *= 10;
            } else {
                cero = 1;
            }
            n++;
            numero = (suma*potencia) + numero;
            potencia *=10;
            numero1 /= 10;
            numero2 /= 10;
        }
        numeroS1 = (lleva*potencia) + numero;
    }
}

