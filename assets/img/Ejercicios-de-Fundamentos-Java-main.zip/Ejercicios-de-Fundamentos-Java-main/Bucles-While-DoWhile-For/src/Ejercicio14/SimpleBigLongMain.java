package Ejercicio14;

import java.util.Scanner;

class SimpleBigLongMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        SimpleBigLong sbp = new SimpleBigLong();

        sbp.num1 = c.nextLong();
        sbp.num2 = c.nextLong();

        sbp.sumaLong();

        System.out.println("Suma: "+sbp.numeroS1+ sbp.numeroS2);
        c.close();
    }
}
