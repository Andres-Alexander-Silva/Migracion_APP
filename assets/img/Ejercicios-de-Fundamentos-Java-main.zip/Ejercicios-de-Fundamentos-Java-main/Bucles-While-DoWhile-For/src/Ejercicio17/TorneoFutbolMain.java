package Ejercicio17;

import java.util.Scanner;

class TorneoFutbolMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TorneoFutbol torneo = new TorneoFutbol();

        torneo.numero1 = c.nextLong();
        torneo.numero2 = c.nextLong();
        torneo.ToreneoFutbol();

        System.out.println("Partidos Ganados:   "+torneo.ganados);
        System.out.println("Partidos Empatados: "+torneo.empates);
        System.out.println("Partidos Perdidos:  "+torneo.perdidos);
        System.out.println("Puntos:             "+torneo.puntos);
        System.out.println("Goles a favor:      "+torneo.SumaaFavor);
        System.out.println("Goles en contra:    "+torneo.SumaEnContra);

        c.close();
    }    
}