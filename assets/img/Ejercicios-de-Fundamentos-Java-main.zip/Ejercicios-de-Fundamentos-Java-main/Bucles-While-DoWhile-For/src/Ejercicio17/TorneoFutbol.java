package Ejercicio17;

class TorneoFutbol {
    long numero1,numero2,sumaAFavor1,sumaEncontra1,sumaAFavor2,sumaEncontra2,enContra;
    long aFavor,enContra2,aFavor2,SumaaFavor,SumaEnContra,ganados1,empates1,perdidos1;
    long ganados2,empates2,perdidos2,ganados,empates,perdidos,puntos,digito1,digito2;
    long em,ndigito1,ndigito2;
    
    void ToreneoFutbol(){
        long n1=numero1;
        long n2=numero2;

        while(ndigito1!=0){
            ndigito1=ndigito1/10;
            digito1++;
        }
        while(ndigito2!=0){
            ndigito2=ndigito2/10;
            digito2++;
        }

        while(n1!=0){
            enContra=n1%10;
            sumaEncontra1=sumaEncontra1+enContra;
            n1=n1/10;
            aFavor=n1%10;
            sumaAFavor1=sumaAFavor1+aFavor;
            if(aFavor>enContra) ganados1++;

            if(aFavor==enContra)empates1++;

            if (aFavor<enContra)perdidos1++;

            n1=n1/10;

        }

        while(n2!=0){
            aFavor2 =n2%10;
            sumaAFavor2=sumaAFavor2+aFavor2;
            n2=n2/10;
            enContra2=n2%10;
            sumaEncontra2 =sumaEncontra2+enContra2;
            if(aFavor2>enContra2)ganados2++;
            if(aFavor2==enContra2)empates2++;
            if(aFavor2<enContra2)perdidos2++;

            n2=n2/10;  
        }

        SumaaFavor=sumaAFavor2+sumaAFavor1;
        SumaEnContra=sumaEncontra2+sumaEncontra1;
        ganados=ganados1+ganados2;
        perdidos=perdidos1+perdidos2;
        

        long empates0=empates1+empates2;
        if (digito1<18 || digito2<18){
            if (digito1<18 && digito2<18){
                long resta1=18-digito1;
                long resta2=18-digito2;
                empates=empates0+resta1+resta2;
            }
            if (digito1<18){
                long resta1=18-digito1;
                empates=((resta1-ganados)-perdidos);
            }
            if (digito2<18){
                long resta2=18-digito2;
                empates=((resta2-ganados)-perdidos);
            }
        }
        else {
            empates=empates1+empates2;
        }
        puntos=(ganados*3) + empates;

    }
}