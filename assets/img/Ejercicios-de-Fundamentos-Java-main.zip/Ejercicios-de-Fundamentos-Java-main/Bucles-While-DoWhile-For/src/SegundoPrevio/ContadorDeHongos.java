package SegundoPrevio;

class ContadorDeHongos {
    int cantidadH,codigoH,dig=0,contador=0,primerDig,segundoDig,tercerDig,tresUltimasCifras;
    int residuo=0,suma=0,porcentajeT=0,porcentajeNT=0,totalH=0;
    int contadorMixo=0,contadorMono=0,contadorAmo=0,contadorPluri=0,contadorAsco=0,contadorNoH=0,contadorToxi=0,contadorNTox=0;
    boolean esParImpar,primerDigito,primo,mixofitos,monadomicetes,amonadomicetes,plurimonadomicetes,ascomicetos;
    boolean toxicidad;


    boolean Mixofitos(int num){
        if (DigDistinto2y8(num)){
            segundoDig = (codigoH / 10000) % 10;
            tercerDig = (codigoH / 1000) % 100;
            if (segundoDig == 2 && esParOImpar(tercerDig) && digitos(num) == 6){
                mixofitos = true;
            } 
            else mixofitos = false;
        }
        return mixofitos;
    }

    boolean Monadomicetes(int num){
        if (DigDistinto2y8(num)){
            segundoDig = (codigoH / 10000) % 10;
            tercerDig = (codigoH / 1000) % 100;
            if (segundoDig == 4 && esParOImpar(tercerDig) && tercerDig != 3 && digitos(num) == 6){
                monadomicetes = true;
            } 
            else monadomicetes = false;
        }
        return monadomicetes;
    }

    boolean Amonadomicetes(int num){
        if (DigDistinto2y8(num)){
            segundoDig = (codigoH / 10000) % 10;
            tercerDig = (codigoH / 1000) % 100;
            if (segundoDig == 6 && esParOImpar(tercerDig) && tercerDig != 2 && digitos(num) == 6){
                amonadomicetes = true;
            }
            else amonadomicetes = false;
        }
        return amonadomicetes;
    }

    boolean Plurimonadomicetes(int num){
        if (DigDistinto2y8(num)){
            segundoDig = (codigoH / 10000) % 10;
            tercerDig = (codigoH / 1000) % 100;
            if (segundoDig == 8 && esParOImpar(tercerDig) && tercerDig != 5 && digitos(num) == 6){
                plurimonadomicetes = true;
            }
            else plurimonadomicetes = false;
        }
        return plurimonadomicetes;
    }

    boolean Ascomicetos(int num){
        if (!Mixofitos(num) && !Monadomicetes(num) && !Amonadomicetes(num) && !Plurimonadomicetes(num)){
            ascomicetos = true;
        }
        else ascomicetos = false;
        return ascomicetos;
    }

    boolean DigDistinto2y8(int num){
        primerDig = codigoH / 100000;
        if (primerDig == 2 || primerDig == 8){
            primerDigito = false;
        } else {
            primerDigito = true;
        }
        return primerDigito;
    }

    boolean Toxicidad(int num){
        tresUltimasCifras = codigoH % 1000;
        while (tresUltimasCifras > 0){
            residuo = tresUltimasCifras % 10;
            suma = suma + residuo;
            tresUltimasCifras /= 10;
        }
        if (esPrimo(suma)) toxicidad = true;
        else toxicidad = false;
        return toxicidad;
    }

    void TotalHongos(int num1,int num2,int num3,int num4,int num5){
        totalH = num1 + num2 + num3 + num4 + num5;
    }
    void porcentajeToxi(int num1, int num2, int num3){
       porcentajeT = Math.round(num1*100/num3);
       porcentajeNT = Math.round(num2*100/num3); 
    }

    boolean esPrimo(int num){
        for (int i = 2; i < num / 2; i++){
            if(num % 2 == 0) primo = false;
            else primo = true;
        }
        return primo;
    }

    boolean esParOImpar(int num){
        if (num == 2 || num == 8) esParImpar = false;
        if (num % 2 == 0) esParImpar = true;
        else esParImpar = false;
        return esParImpar;
    }

    int digitos(int num){
        while (codigoH > 0){
            dig = codigoH % 10;
            contador++;
            codigoH /= 10;
        }
        return contador;
    }
}