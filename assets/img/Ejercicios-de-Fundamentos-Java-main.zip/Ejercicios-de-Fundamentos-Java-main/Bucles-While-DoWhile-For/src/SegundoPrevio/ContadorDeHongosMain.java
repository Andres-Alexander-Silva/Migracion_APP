package SegundoPrevio;

import java.util.Scanner;

class ContadorDeHongosMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        ContadorDeHongos h = new ContadorDeHongos();

        h.cantidadH = c.nextInt();

        for (int i = 1; i <= h.cantidadH; i++){
            h.codigoH = c.nextInt();
            if (h.Mixofitos(h.codigoH)) h.contadorMixo++;
            if (h.Monadomicetes(h.codigoH)) h.contadorMono++;
            if (h.Amonadomicetes(h.codigoH)) h.contadorAmo++;
            if (h.Plurimonadomicetes(h.codigoH)) h.contadorPluri++;
            if (h.Ascomicetos(h.codigoH)) h.contadorAsco++;
            if (h.Toxicidad(h.codigoH)) h.contadorToxi++;
            else h.contadorNTox++;
        }
        
        h.TotalHongos(h.contadorMixo, h.contadorMono, h.contadorAmo, h.contadorPluri, h.contadorAsco);
        h.porcentajeToxi(h.contadorToxi, h.contadorNTox,h.totalH);

        System.out.println("Hongos mixofitos: "+h.contadorMixo);
        System.out.println("Hongos monadomicetes: "+h.contadorMono);
        System.out.println("Hongos amonadomicetes: "+h.contadorAmo);
        System.out.println("Hongos plurimonadomicetes: "+h.contadorPluri);
        System.out.println("Hongos ascomicetos: "+h.contadorAsco);
        System.out.println("Total Hongos: "+h.totalH);
        System.out.println("Hongos tóxicos: "+h.contadorToxi+"("+h.porcentajeT+")");
        System.out.println("Hongos no tóxicos: "+h.contadorNTox+"("+h.porcentajeNT+")");
        System.out.println("Número que no son hongos: "+h.contadorNoH);
        System.out.println("Número de códigos inválidos: ");

        c.close();
    }    
}
