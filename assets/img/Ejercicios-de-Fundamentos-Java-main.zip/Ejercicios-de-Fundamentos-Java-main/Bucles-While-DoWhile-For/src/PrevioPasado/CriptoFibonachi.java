package PrevioPasado;

class CriptoFibonachi{
    String accion="",claveEncriptada="",encriptada="";
    int sinEncirptar,llaveK,claveDesencriptada;

    public String Encriptar(){
        long a=0,b=1,suma,kEnecimo=0,multNumero,dig;
        String letraNum="";
        for (int i = 0; i <= llaveK; i++){
            suma = a + b;
            a = b;
            b = suma;
            kEnecimo = a;
        }
        multNumero = kEnecimo * sinEncirptar;
        while (multNumero > 0){
            dig = multNumero % 10;
            if(dig == 0) letraNum = "A";
            if(dig == 1) letraNum = "E";
            if(dig == 2) letraNum = "I";
            if(dig == 3) letraNum = "O";
            if(dig == 4) letraNum = "U";
            if(dig == 5) letraNum = "Z";
            if(dig == 6) letraNum = "X";
            if(dig == 7) letraNum = "Y";
            if(dig == 8) letraNum = "V";
            if(dig == 9) letraNum = "W";
            claveEncriptada = letraNum + claveEncriptada;
            multNumero /= 10;
        }
        return claveEncriptada;
    }
    public int Desencriptar(){
        String num = encriptada,numLetra="",numDesencriptado="";
        for (int i = 0; i < num.length(); i++){
            if (num.charAt(i) == 'A') numLetra = "0";
            if (num.charAt(i) == 'E') numLetra = "1";
            if (num.charAt(i) == 'I') numLetra = "2";
            if (num.charAt(i) == 'O') numLetra = "3";
            if (num.charAt(i) == 'U') numLetra = "4";
            if (num.charAt(i) == 'Z') numLetra = "5";
            if (num.charAt(i) == 'X') numLetra = "6";
            if (num.charAt(i) == 'Y') numLetra = "7";
            if (num.charAt(i) == 'V') numLetra = "8";
            if (num.charAt(i) == 'W') numLetra = "9";
            numDesencriptado += numLetra;
        }
        long passEncriptado = Long.parseLong(numDesencriptado);
        long a=0,b=1,suma,kEnecimo=0,divNumero;
        for (int i = 0; i <= llaveK; i++){
            suma = a + b;
            a = b;
            b = suma;
            kEnecimo = a;
        }
        divNumero = passEncriptado / kEnecimo;
        claveDesencriptada = (int) divNumero;
        return claveDesencriptada;
    }
}