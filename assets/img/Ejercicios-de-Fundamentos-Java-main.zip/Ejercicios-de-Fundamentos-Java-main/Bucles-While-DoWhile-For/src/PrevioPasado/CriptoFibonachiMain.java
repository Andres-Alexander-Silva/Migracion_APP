package PrevioPasado;

import java.util.Scanner;

public class CriptoFibonachiMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CriptoFibonachi cf = new CriptoFibonachi();

        cf.accion = c.next();

        switch (cf.accion){
            case "Encriptar":
                cf.sinEncirptar = c.nextInt();
                cf.llaveK = c.nextInt();
                System.out.println("Clave encriptada: "+cf.Encriptar());
                break;
            case "Desencriptar":
                cf.encriptada = c.next();
                cf.llaveK = c.nextInt();
                System.out.println("Clave encriptada: "+cf.Desencriptar());
                break;
        }

        c.close();
    }
}