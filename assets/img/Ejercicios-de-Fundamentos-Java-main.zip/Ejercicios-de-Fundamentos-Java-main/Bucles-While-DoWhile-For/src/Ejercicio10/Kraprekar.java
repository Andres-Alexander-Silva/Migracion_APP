package Ejercicio10;

class Kraprekar {
    int numero;
    int cicloK;
    int numAscen,numDescen;

   void ConstanteKprecar(){
        String numeroC = String.valueOf(numero);
        int resta = 0;
        cicloK = 0;
        if (numeroC.length() <= 4){
            do {
                ordenAscendente(numero);
                if (numAscen > numDescen) resta = numAscen-numDescen;
                else resta = numDescen - numAscen;
                cicloK++;
                numero = resta;
            } while (resta != 6174 && resta != 0);
            if (resta == 0) cicloK = 8;
            System.out.printf("Ciclos Kaprekar: %d",cicloK);
        } else {
            System.out.println("Datos Inválidos");
        }
   }
   void ordenAscendente(int numOrdenar){
       int cifra1,cifra2,cifra3,cifra4,valor,aux;
       cifra1 = numero % 10;
       valor = numero / 10;
       cifra2 = valor % 10;
       valor = valor / 10;
       cifra4 = valor % 10;
       cifra3  = valor / 10;
       if (cifra3<cifra4){
            aux = cifra4;
            cifra4 = cifra3;
            cifra3 = aux;
       }
       if (cifra2<cifra4){
           aux= cifra2;
           cifra2= cifra4;
           cifra4 = aux;
       }
       if (cifra1<cifra4){
           aux = cifra4;
           cifra4 = cifra1;
           cifra1 = aux;
       }
       if (cifra2<cifra3){
            aux = cifra2;
            cifra2 = cifra3;
            cifra3 = aux;
       }
       if (cifra1<cifra3){
           aux = cifra1;
           cifra1 = cifra3;
           cifra3 = aux;
       }
       if (cifra1<cifra2){
           aux = cifra1;
           cifra1 = cifra2;
           cifra2 = aux;
       }
       numAscen = cifra4 * 1000 + cifra3 * 100 + cifra2 * 10 + cifra1;
       numDescen = cifra1 * 1000 + cifra2 * 100 + cifra3 * 10 + cifra4;
   }
}