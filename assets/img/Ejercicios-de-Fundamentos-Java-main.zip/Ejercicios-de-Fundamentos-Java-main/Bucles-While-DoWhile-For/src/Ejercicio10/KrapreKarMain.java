package Ejercicio10;

import java.util.Scanner;

class KrapreKarMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Kraprekar kp = new Kraprekar();

        kp.numero = c.nextInt();
        kp.ConstanteKprecar();
        c.close();
    }
}
