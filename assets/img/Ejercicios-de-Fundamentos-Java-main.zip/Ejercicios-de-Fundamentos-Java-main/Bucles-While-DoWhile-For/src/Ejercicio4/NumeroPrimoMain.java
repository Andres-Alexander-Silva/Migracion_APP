package Ejercicio4;

import java.util.Scanner;

class NumeroPrimoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        NumeroPrimo np = new NumeroPrimo();

        np.numero = c.nextLong();

        np.CalcularPrimo();
        c.close();
    }
}
