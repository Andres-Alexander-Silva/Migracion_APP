package Ejercicio4;

class NumeroPrimo {
    long numero;
    int x=2;
    boolean esPrimo = false;

    void CalcularPrimo(){
        if (numero > 0){
            while ( x <= numero/2 && !esPrimo){
                if (numero % x == 0){
                    esPrimo = true;
                }
                x++;
            }
            if (!esPrimo && numero > 1){
                System.out.println("Primo: SI");
            } else {
                System.out.println("Primo: No");
            }
        }
    }
}
