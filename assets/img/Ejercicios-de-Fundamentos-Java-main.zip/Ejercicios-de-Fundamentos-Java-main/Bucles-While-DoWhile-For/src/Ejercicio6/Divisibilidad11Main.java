package Ejercicio6;

import java.util.Scanner;

class Divisibilidad11Main {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        Divisibilidad11 d = new Divisibilidad11();

        d.numero = c.nextLong();

        d.algoritmo();
        c.close();
    }
}
