package Ejercicio6;

class Divisibilidad11 {
    long numero;
    long sumaImpar,sumaPar;

    void algoritmo(){
        while(numero!=0){
            long posicionImpar = numero % 10;
            numero=numero/10;
            long posicionPar = numero % 10;
            numero=numero/10;
            sumaImpar=sumaImpar+posicionImpar;
            sumaPar=sumaPar+posicionPar;
        }
        long resta = sumaPar - sumaImpar;
        long digitoR1=resta%10;
        long digitoR2=resta/10;
        boolean divisible = digitoR1==digitoR2;
        if (resta==0 || divisible ){
            System.out.println("Si");
        }
        else{
            System.out.println("No");
        }
    }
}