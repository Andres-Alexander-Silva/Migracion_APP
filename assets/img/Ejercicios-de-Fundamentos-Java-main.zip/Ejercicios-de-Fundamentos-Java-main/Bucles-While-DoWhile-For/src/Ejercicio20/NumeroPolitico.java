package Ejercicio20;

class NumeroPolitico {
    long numero;
    long digito=0,sumaDig=0,residuo=0;
    
    void numPolitico(){
        long num1 = numero;
        if (numero > 0){
            while (num1 != 0){
                digito = num1 % 10;
                sumaDig = digito + sumaDig;
                num1 /= 10;
            }
            residuo = numero % sumaDig;
        }
    }
}