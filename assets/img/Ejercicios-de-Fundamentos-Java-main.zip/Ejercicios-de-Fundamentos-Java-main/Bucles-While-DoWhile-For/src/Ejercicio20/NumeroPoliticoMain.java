package Ejercicio20;

import java.util.Scanner;

class NumeroPoliticoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        NumeroPolitico politico = new NumeroPolitico();

        politico.numero = c.nextLong();
        politico.numPolitico();

        if (politico.residuo == 0){
            System.out.println("El número "+politico.numero+" SI es político y la suma de sus dígitos es "+politico.sumaDig+".");
        }
        if (politico.residuo > 0){
            System.out.println("El número "+politico.numero+" NO es político. La suma de sus dígitos es "+politico.sumaDig+" y el residuo de la división es "+politico.residuo+".");
        }
        if ((politico.numero < 0) || (politico.numero >= 0 && politico.numero <= 9)){
            System.out.println("ERROR");
        }
        
        c.close();
    }    
}