package Ejercicio16;

import java.util.Scanner;

class TienpoTranscurridomain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TiempoTranscurrido tt = new TiempoTranscurrido();

        tt.fecha1 = c.nextInt();
        tt.fecha2 = c.nextInt();
        tt.algoritmo();

        System.out.println("Diferencia en dias: "+tt.incremento);
        
        c.close();
    }
}
