package Ejercicio16;

class TiempoTranscurrido {
    int fecha1,fecha2;
    int diferenciaDias;
    int residuo;
    int incremento = 0;

    void algoritmo( ){
        int mes2,año2,dia2;
        dia2 = fecha2%100;
        mes2 = (fecha2/100)%100;
        año2 = (fecha2/10000);

        while(fecha1>fecha2){
            if(año2%4==0){

                if((mes2==1)||(mes2==3)||(mes2==5)||(mes2==7)||(mes2==8)||(mes2==10)){
                    if(dia2>=31){
                        dia2=1;
                        mes2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }

                }
                if(mes2>=12){
                    if(dia2>=31){
                        dia2=1;
                        mes2=1;
                        año2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }

                }
                if((mes2==4)||(mes2==6)||(mes2==9)||(mes2==11)){
                    if(dia2>=30){
                        dia2=1;
                        mes2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }
                }
                if(mes2==2){
                    if(dia2>=29){
                        dia2=1;
                        mes2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }

                }
                fecha2 = año2*10000+mes2*100+dia2;
            }
            else{
                if(mes2==2){
                    if(dia2>=28){
                        dia2=1;
                        mes2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }
                }
                if((mes2==1)||(mes2==3)||(mes2==5)||(mes2==7)||(mes2==8)||(mes2==10)){
                    if(dia2>=31){
                        dia2=1;
                        mes2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }
                }
                if(mes2>11){
                    if(dia2>=31){
                        dia2=1;
                        mes2=1;
                        año2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }
                }
                if((mes2==4)||(mes2==6)||(mes2==9)||(mes2==11)){
                    if(dia2>=30){
                        dia2=1;  
                        mes2++;
                        incremento++;
                    }
                    else{
                        dia2++;
                        incremento++;
                    }
                }
                fecha2 = año2*10000+mes2*100+dia2;
                if(fecha2>fecha1){
                    incremento--;   
                }
            }
        }

    }
}  