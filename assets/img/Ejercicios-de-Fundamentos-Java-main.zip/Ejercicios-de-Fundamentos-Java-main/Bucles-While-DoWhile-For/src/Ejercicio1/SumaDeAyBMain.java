package Ejercicio1;

import java.util.Scanner;

class SumaDeAyBMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        SumaDeAyB sumaAB = new SumaDeAyB();

        sumaAB.numA = c.nextLong();
        sumaAB.numB = c.nextLong();

        sumaAB.CalcularSuma();

        System.out.println("La suma entre "+sumaAB.menor+" y "+sumaAB.mayor+" es: "+sumaAB.suma);
        c.close();
    }
}
