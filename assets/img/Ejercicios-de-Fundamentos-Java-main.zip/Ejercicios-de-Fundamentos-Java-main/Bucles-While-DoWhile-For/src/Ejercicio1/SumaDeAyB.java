package Ejercicio1;

class SumaDeAyB {
    long numA,numB,mayor,menor,suma,numero;

    public void CalcularSuma(){
        if (numA >= numB){
            mayor = numA;
            menor = numB;
        } else {
            mayor = numB;
            menor = numA;
        }

        numero = menor;
        suma = 0;

        while (numero<=mayor){ // 22 <= 21 false 
            suma += numero; // 15 + 16 + 17 + 18 + 19 + 20 + 21 = 126
            numero += 1; // 22
        }
    }
}