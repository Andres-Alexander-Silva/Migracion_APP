package Modelo.entity;

public class Producto {

    private String nombre;
    private double precio;
    private int cantidadStock;
    private String descripcion;
    private String referencia;

    public Producto() {
    }

    public Producto(String nombre, double precio, int cantidadStock, String descripcion, String referencia) {
        this.setNombre(nombre);
        this.setPrecio(precio);
        this.setCantidadStock(cantidadStock);
        this.setDescripcion(descripcion);
        this.setReferencia(referencia);
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidadStock() {
        return cantidadStock;
    }

    public void setCantidadStock(int cantidadStock) {
        this.cantidadStock = cantidadStock;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "nombre='" + nombre + '\'' +
                ", precio=" + precio +
                ", cantidadStock=" + cantidadStock +
                ", descripcion='" + descripcion + '\'' +
                ", referencia='" + referencia + '\'' +
                '}';
    }
}