package Modelo.entity;

public class Administrador extends Persona{
}
