package Modelo.entity;

public class Cliente extends Persona{
}
