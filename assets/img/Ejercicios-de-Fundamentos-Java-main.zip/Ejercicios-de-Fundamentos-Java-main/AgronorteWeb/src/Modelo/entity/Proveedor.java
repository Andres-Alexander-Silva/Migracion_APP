package Modelo.entity;

public class Proveedor extends Persona{
}
