package Ejercicio13;

import java.util.Scanner;

class CalendarioLunarMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CalendarioLunar cl = new CalendarioLunar();

        cl.dia = c.nextInt();
        cl.mes = c.nextInt();
        cl.anio = c.nextInt();

        cl.CalcularLuna();

        if ((cl.total >= 0 && cl.total <= 6) || (cl.total == 29)){
            System.out.println("Luna Nueva");
        }
        else if (cl.total >= 7 && cl.total <= 13){
            System.out.println("Cuarto Creciente");
        }
        else if (cl.total >= 14 && cl.total <= 20){
            System.out.println("Luna Llena");
        }
        else {
            System.out.println("Cuarto Menguante");
        }
    }
}
