package Ejercicio13;

class CalendarioLunar {
    int dia,mes,anio;
    int aureo,epecta,epectaC,total;

    void CalcularLuna(){
        aureo = (anio + 1) % 19;
        epecta = ((aureo - 1) * 11) % 30;
        if (mes == 1 || mes == 3){
            epectaC = dia;
        }
        if (mes == 2){
            epectaC = dia + 1;
        }
        if (mes == 4 || mes == 5 || mes == 6 || mes == 7 || mes == 8 || mes == 9 || mes == 10 || mes == 11 || mes == 12){
            epectaC = (mes - 3) + dia;
        }
        total = epecta + epectaC;
        if (total >= 30){
            total %= 30;
        }
    }
}
