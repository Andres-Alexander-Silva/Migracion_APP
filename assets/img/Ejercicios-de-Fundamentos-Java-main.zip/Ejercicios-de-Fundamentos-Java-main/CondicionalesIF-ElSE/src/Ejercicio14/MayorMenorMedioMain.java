package Ejercicio14;

import java.util.Scanner;

class MayorMenorMedioMain {
    public static void main(String[] args) {
        Scanner co = new Scanner(System.in);

        int a,b,c;
        int mayor,menor,medio;

        a = co.nextInt();
        b = co.nextInt();
        c = co.nextInt();

        if (a >= b && a >= c){
            mayor = a;
            if (b >= c){
                medio = b;
                menor = c;
            } else {
                medio = c;
                menor = b;
            }
        }
        else if (b >= a && b >= c){
            mayor = b;
            if (a >= c){
                medio = a;
                menor = c;
            } else {
                medio = c;
                menor = a;
            }
        }
        else {
            mayor = c;
            if (a >= b){
                medio = a;
                menor = b;
            } else {
                medio = b;
                menor = a;
            }
        }
        System.out.println("Mayor = "+mayor);
        System.out.println("Medio = "+medio);
        System.out.println("Menor = "+menor);
    }
}
