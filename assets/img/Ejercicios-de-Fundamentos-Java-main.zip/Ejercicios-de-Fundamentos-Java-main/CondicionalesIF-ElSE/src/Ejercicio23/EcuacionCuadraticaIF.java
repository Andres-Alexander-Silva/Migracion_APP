package Ejercicio23;

import java.util.Scanner;

class EcuacionCuadraticaIF {
    public static void main(String[] args) {
        Scanner co = new Scanner(System.in);

        double a,b,c;
        double discriminante,solucion,ecuacion1,ecuacion2,parteReal,parteImaginaria,uno,dos;

        a = co.nextDouble();
        b = co.nextDouble();
        c = co.nextDouble();

        discriminante = (b*b) - (4*a*c);
        ecuacion1 = (double) ((b*-1) / (2*a));
        ecuacion2 = Math.sqrt(discriminante)/(2*a);

        if (a != 0){
            if (discriminante == 0){
                if (a > 0){
                    solucion =(b*-1) / (2 * a);
                    System.out.println("Hay una solución real y la concavidad es hacia arriba = "+solucion);
                } else {
                    solucion = (b*-1) / (2 * a);
                    System.out.println("Hay una solución real y la concavidad es hacia abajo = "+solucion);
                }
            }
            if (discriminante > 0){
                if (a > 0) {
                    uno = ecuacion1 + ecuacion2;
                    dos = ecuacion1 - ecuacion2;
                    System.out.println("Hay dos soluciones reales y la concavidad es hacia arriba = " + uno + " y " + dos);
                } else {
                    uno = ecuacion1 + ecuacion2;
                    dos = ecuacion1 - ecuacion2;
                    System.out.println("Hay dos soluciones reales y la concavidad es hacia abajo = " + uno + " y " + dos);
                }
            }
            if (discriminante < 0){
                if ( a > 0){
                    discriminante = Math.abs(discriminante);
                    parteReal = ((b*(-1)) / (2 * (a)));
                    parteImaginaria = (Math.sqrt(discriminante)) / (2 * (a));
                    System.out.println("Hay dos soluciones complejas y la concavidad es hacia arriba = "+parteReal+" \u00b1 "+parteImaginaria+"*i");
                } else {
                    discriminante = Math.abs(discriminante);
                    parteReal = ((b*(-1)) / (2 * (a)));
                    parteImaginaria = (Math.sqrt(discriminante)) / (2 * (a));
                    System.out.println("Hay dos soluciones complejas y la concavidad es hacia abajo = "+parteReal+" \u00b1 "+parteImaginaria+"*i");
                }
            }
        } else {
            System.out.println("No es una ecuación cuadrática");
        }
    }
}
