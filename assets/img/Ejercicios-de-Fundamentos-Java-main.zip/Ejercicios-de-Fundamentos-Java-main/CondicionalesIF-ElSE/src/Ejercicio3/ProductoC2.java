package Ejercicio3;

class ProductoC2 {
    int cantidadI,cantidadC,cantidadV,precioDC;
    int precioDV,gananciasB,gananciasN,impuestos,ingresos,egresos;

    void calcularProductoC(){
        precioDV = (precioDC * 29) / 100;
        precioDV += precioDC;
        ingresos = precioDV * cantidadV;
        egresos = precioDC * cantidadC;
        gananciasB = ingresos - egresos;
        impuestos = (ingresos * 19) / 100;
        gananciasN = gananciasB - impuestos;
    }
}
