package Ejercicio3;

import java.util.Scanner;

class ProductoC2Main {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        ProductoC2 pc2 = new ProductoC2();

        pc2.cantidadI = c.nextInt();
        pc2.cantidadC = c.nextInt();
        pc2.cantidadV = c.nextInt();
        pc2.precioDC = c.nextInt();

        pc2.calcularProductoC();

        if (pc2.cantidadI < 0 || pc2.cantidadC < 0 || pc2.cantidadV < 0 || pc2.precioDC < 0 || pc2.cantidadV > pc2.cantidadI + pc2.cantidadC || pc2.gananciasB < 0 || pc2.gananciasN < 0){
            if (pc2.cantidadI > 0) {
                if (pc2.cantidadV > pc2.cantidadI + pc2.cantidadC) {
                    System.out.println("Error, la cantidad vendida supera las existencias.");
                }
            }
            if (pc2.cantidadI < 0 || pc2.cantidadC < 0 || pc2.cantidadV < 0 || pc2.precioDC < 0) {
                System.out.println("Error, los siguientes datos son negativos:");

                if (pc2.cantidadI < 0){
                    System.out.println("Cantidad Inicial.");
                }
                if (pc2.cantidadC < 0) {
                    System.out.println("Cantidad Comprada.");
                }
                if (pc2.cantidadV < 0) {
                    System.out.println("Cantidad Vendida.");
                }
                if (pc2.precioDC < 0) {
                    System.out.println("Precio de Compra.");
                }
            }
            if (pc2.cantidadI > 0 && pc2.cantidadC > 0 && pc2.cantidadV > 0 && pc2.precioDC > 0) {
                if (pc2.gananciasB < 0 && pc2.gananciasN < 0) {
                    pc2.calcularProductoC();

                    System.out.println("Precio de Venta: " + pc2.precioDV);
                    System.out.println("Ingresos: " + pc2.ingresos);
                    System.out.println("Egresos: " + pc2.egresos);
                    System.out.println("Pérdidas Brutas: " + pc2.gananciasB);
                    System.out.println("Impuestos: " + pc2.impuestos);
                    System.out.println("Pérdidas Netas: " + pc2.gananciasN);
                }
            }
        } else {
            pc2.calcularProductoC();

            System.out.println("Precio de Venta: " + pc2.precioDV);
            System.out.println("Ingresos: " + pc2.ingresos);
            System.out.println("Egresos: " + pc2.egresos);
            System.out.println("Ganancias Brutas: " + pc2.gananciasB);
            System.out.println("Impuestos: " + pc2.impuestos);
            System.out.println("ganancias Netas: " + pc2.gananciasN);
        }
    }
}
