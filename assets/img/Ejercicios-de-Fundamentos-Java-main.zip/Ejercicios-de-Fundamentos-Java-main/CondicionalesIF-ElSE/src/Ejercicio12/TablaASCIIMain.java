package Ejercicio12;

import java.util.Scanner;

class TablaASCIIMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        char caracter;

        caracter = c.next().charAt(0);

        if ((caracter == '0') || (caracter == '1') || (caracter == '2') || (caracter == '3') || (caracter == '4') || (caracter == '5') || (caracter == '6') ||
                (caracter == '7') || (caracter == '8') || (caracter == '9')){
            System.out.println("1=Dígito");
        }
        if ((caracter == 'A') || (caracter == 'B') || (caracter == 'C') || (caracter == 'D') || (caracter == 'E') || (caracter == 'F') ||
                (caracter == 'G') || (caracter == 'H') || (caracter == 'I') || (caracter == 'J') || (caracter == 'K') || (caracter == 'L') ||
                (caracter == 'M') || (caracter == 'N') || (caracter == 'O') || (caracter == 'P') || (caracter == 'Q') || (caracter == 'R') ||
                (caracter == 'S') || (caracter == 'T') || (caracter == 'U') || (caracter == 'V') || (caracter == 'W') || (caracter == 'X') ||
                (caracter == 'Y') || (caracter == 'Z')){
            System.out.println("2=Alfabético Consonante MAYÚSCULA");
        }
        if ((caracter == 'a') || (caracter == 'b') || (caracter == 'c') || (caracter == 'd') || (caracter == 'e') || (caracter == 'f') ||
                (caracter == 'g') || (caracter == 'h') || (caracter == 'i') || (caracter == 'j') || (caracter == 'k') || (caracter == 'l') ||
                (caracter == 'm') || (caracter == 'n') || (caracter == 'o') || (caracter == 'p') || (caracter == 'q') || (caracter == 'r') ||
                (caracter == 's') || (caracter == 't') || (caracter == 'u') || (caracter == 'v') || (caracter == 'w') || (caracter == 'x') ||
                (caracter == 'y') || (caracter == 'z')){
            System.out.println("3=Alfabético Consonante minúscula");
        }
        if ((caracter == 'A') || (caracter == 'E') || (caracter == 'I') || (caracter == 'O') || (caracter == 'U')){
            System.out.println("4=Alfabético Vocal MAYÚSCULA");
        }
        if ((caracter == 'a') || (caracter == 'e') || (caracter == 'i') || (caracter == 'o') || (caracter == 'u')){
            System.out.println("5=Alfabético Vocal minúscula");
        }
        if ((caracter == '!') || (caracter == '"') || (caracter == '#') || (caracter == '$') || (caracter == '%') || (caracter == '&') || (caracter == '(') ||
                (caracter == ')') || (caracter == '*') || (caracter == '+') || (caracter == '-') || (caracter == ',') || (caracter == '.') || (caracter == '/') ||
                (caracter == ':') || (caracter == ';') || (caracter == '<') || (caracter == '=') || (caracter == '>') || (caracter == '?') || (caracter == '@') ||
                (caracter == '[') || (caracter == ']') || (caracter == '^') || (caracter == '_') || (caracter == '´') || (caracter == '{') || (caracter == '|') ||
                (caracter == '}') || (caracter == '~')){
            System.out.println("6=Otro tipo de símbolo");
        }
    }
}
