package Ejercicio4;

class CreditoC {
    long montoC;
    long tasaI,plazoM,valorCM,valorMC,valorMI;
    long gananciaT;

    void calcularCreditoC(){
        valorMC = (montoC /  plazoM);
        valorMI = ((montoC * tasaI) / 100);
        valorCM = valorMC + valorMI;
        gananciaT = ((valorCM * plazoM - montoC) * 100) / montoC;
    }
}
