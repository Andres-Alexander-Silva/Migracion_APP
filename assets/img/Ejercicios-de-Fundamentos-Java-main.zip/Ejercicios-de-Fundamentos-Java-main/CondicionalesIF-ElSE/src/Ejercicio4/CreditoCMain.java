package Ejercicio4;

import java.util.Scanner;

class CreditoCMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CreditoC cc = new CreditoC();

        cc.montoC = c.nextLong();
        cc.tasaI = c.nextLong();
        cc.plazoM = c.nextLong();

        if (cc.montoC < 0 || cc.tasaI < 0 || cc.plazoM < 0 || cc.tasaI > 35){
            if (cc.montoC < 0 || cc.tasaI < 0 || cc.plazoM < 0){
                System.out.println("Error los siguientes datos son negativos");
                if (cc.montoC < 0)
                    System.out.println("Monto.");
                if (cc.tasaI < 0)
                    System.out.println("Tasa de Interés.");
                if (cc.plazoM < 0)
                    System.out.println("Plazo en meses.");
            }
            if (cc.tasaI > 35){
                System.out.println("Error, la tasa de interés supera el umbral de usura");
            }
        }
        if (cc.montoC > 0 && cc.tasaI > 0 && cc.plazoM > 0 && cc.tasaI <= 35){
            cc.calcularCreditoC();

            System.out.println("Valor Cuota Mensual: " + cc.valorCM);
            System.out.println("Valor Mensual Capital: " + cc.valorMC);
            System.out.println("Valor Mensual Interes: " + cc.valorMI);
            System.out.println("Ganancia ToTal: " + cc.gananciaT + "%");
        }
    }
}
