package Ejercicio18;

import java.util.Scanner;
import java.util.GregorianCalendar;

class HoroscopoMainC {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        GregorianCalendar bisiesto = new GregorianCalendar();

        int fecha,anio,mes,dia,hc;

        fecha = c.nextInt();

        anio = fecha / 10000;
        mes = (fecha % 10000) / 100;
        dia = fecha % 100;
        hc = anio % 12;

        if ((mes == 1 && dia > 0 && dia <= 31) || (mes == 2 && dia >0 && dia <= 29 && bisiesto.isLeapYear(anio)) || (mes == 3 && dia > 0 && dia <= 31) ||
                (mes == 4 && dia > 0 && dia <= 30) || (mes == 5 && dia > 0 && dia <= 31 ) || (mes == 6 && dia > 0 && dia <= 30) ||
                (mes == 7 && dia > 0 && dia <= 31) || (mes == 8 && dia > 0 && dia <= 31) || (mes == 9 && dia > 0 && dia <= 30) ||
                (mes == 10 && dia > 0 && dia <= 31) || (mes == 11 && dia > 0 && dia <= 30) || (mes == 12 && dia > 0 && dia <= 31)){
            if ((mes == 12 && dia >= 22 && dia <= 31)||(mes == 1 && dia >= 0 && dia <= 19)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Capricornio / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Capricornio / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Capricornio / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Capricornio / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Capricornio / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Capricornio / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Capricornio / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Capricornio / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Capricornio / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Capricornio / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Capricornio / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Capricornio / Cabra");
                }
            }
            if ((mes == 1 && dia >= 20 && dia <= 31)||(mes == 2 && dia >= 18 && dia <= 29)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Acuario / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Acuario / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Acuario / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Acuario / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Acuario / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Acuario / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Acuario / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Acuario / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Acuario / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Acuario / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Acuario / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Acuario / Cabra");
                }
            }
            if ((mes == 2 && dia >= 19 && dia <= 29)||(mes == 3 && dia >= 20 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Piscis / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Piscis / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Piscis / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Piscis / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Piscis / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Piscis / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Piscis / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Piscis / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Piscis / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Piscis / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Piscis / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Piscis / Cabra");
                }
            }
            if ((mes == 3 && dia >= 21 && dia <= 31)||(mes == 4 && dia >= 19 && dia <= 30)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Aries / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Aries / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Aries / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Aries / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Aries / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Aries / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Aries / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Aries / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Aries / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Aries / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Aries / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Aries / Cabra");
                }
            }
            if ((mes == 4 && dia >= 20 && dia <= 30)||(mes == 5 && dia >= 20 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Tauro / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Tauro / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Tauro / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Tauro / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Tauro / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Tauro / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Tauro / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Tauro / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Tauro / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Tauro / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Tauro / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Tauro / Cabra");
                }
            }
            if ((mes == 5 && dia >= 21 && dia <= 30)||(mes == 6 && dia >= 20 && dia <= 30)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Géminis / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Géminis / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Géminis / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Géminis / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Géminis / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Géminis / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Géminis / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Géminis / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Géminis / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Géminis / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Géminis / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Géminis / Cabra");
                }
            }
            if ((mes == 6 && dia >= 21 && dia <= 30)||(mes == 7 && dia >= 22 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Cáncer / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Cáncer / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Cáncer / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Cáncer / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Cáncer / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Cáncer / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Cáncer / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Cáncer / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Cáncer / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Cáncer / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Cáncer / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Cáncer / Cabra");
                }
            }
            if ((mes == 7 && dia >= 23 && dia <= 31)||(mes == 8 && dia >= 22 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Leo / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Leo / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Leo / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Leo / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Leo / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Leo / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Leo / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Leo / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Leo / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Leo / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Leo / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Leo / Cabra");
                }
            }
            if ((mes == 8 && dia >= 23 && dia <= 31)||(mes == 9 && dia >= 22 && dia <= 30)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Virgo / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Virgo / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Virgo / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Virgo / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Virgo / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Virgo / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Virgo / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Virgo / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Virgo / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Virgo / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Virgo / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Virgo / Cabra");
                }
            }
            if ((mes == 9 && dia >= 23 && dia <= 30)||(mes == 10 && dia >= 22 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Libra / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Libra / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Libra / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Libra / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Libra / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Libra / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Libra / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Libra / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Libra / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Libra / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Libra / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Libra / Cabra");
                }
            }
            if ((mes == 10 && dia >= 23 && dia <= 30)||(mes == 11 && dia >= 22 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Escorpión / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Escorpión / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Escorpión / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Escorpión / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Escorpión / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Escorpión / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Escorpión / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Escorpión / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Escorpión / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Escorpión / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Escorpión / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Escorpión / Cabra");
                }
            }
            if ((mes == 11 && dia >= 22 && dia <= 31)||(mes == 12 && dia >= 21 && dia <= 31)){
                if (hc==0){
                    System.out.println("Su Horóscopo es Sagitario / Mono");
                }
                if (hc==1){
                    System.out.println("Su Horóscopo es Sagitario / Gallo");
                }
                if (hc==2){
                    System.out.println("Su Horóscopo es Sagitario / Perro");
                }
                if (hc==3){
                    System.out.println("Su Horóscopo es Sagitario / Marrano");
                }
                if (hc==4){
                    System.out.println("Su Horóscopo es Sagitario / Rata");
                }
                if (hc==5){
                    System.out.println("Su Horóscopo es Sagitario / Bufalo");
                }
                if (hc==6){
                    System.out.println("Su Horóscopo es Sagitario / Tigre");
                }
                if (hc==7){
                    System.out.println("Su Horóscopo es Sagitario / Liebre");
                }
                if (hc==8){
                    System.out.println("Su Horóscopo es Sagitario / Dragon");
                }
                if (hc==9){
                    System.out.println("Su Horóscopo es Sagitario / Serpiente");
                }
                if (hc==10){
                    System.out.println("Su Horóscopo es Sagitario / Caballo");
                }
                if (hc==11){
                    System.out.println("Su Horóscopo es Sagitario / Cabra");
                }
            }
        } else {
            System.out.println("Fecha ");
        }
    }
}