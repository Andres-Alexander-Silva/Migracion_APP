package Ejercicio7;

import java.util.Scanner;

class RelojRaroMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        RelojRaroC rrc = new RelojRaroC();

        rrc.horaMS = c.nextInt();
        rrc.jornada =  c.next().charAt(0);

        rrc.calcularRelogR();

        if (rrc.datosValidos){
            System.out.println("Hora Valida");
        } else {
            System.out.println("Hora no Valida");
        }
    }
}
