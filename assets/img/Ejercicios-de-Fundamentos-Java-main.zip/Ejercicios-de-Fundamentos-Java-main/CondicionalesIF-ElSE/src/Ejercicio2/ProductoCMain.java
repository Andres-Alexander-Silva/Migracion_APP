package Ejercicio2;

import java.util.Scanner;

class ProductoCMain{
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        ProductoC pc = new ProductoC();

        pc.cantidadI = c.nextInt();
        pc.cantidadC = c.nextInt();
        pc.cantidadV = c.nextInt();
        pc.precioDC = c.nextInt();

        if (pc.cantidadI < 0 || pc.cantidadC < 0 || pc.cantidadV < 0 || pc.precioDC < 0 || pc.cantidadV > pc.cantidadI + pc.cantidadC){
            if (pc.cantidadI > 0) {
                if (pc.cantidadV > pc.cantidadI + pc.cantidadC) {
                    System.out.println("Error, la cantidad vendida supera las existencias.");
                }
            }
            if (pc.cantidadI < 0 || pc.cantidadC < 0 || pc.cantidadV < 0 || pc.precioDC < 0) {
                System.out.println("Error, los siguientes datos son negativos:");

                if (pc.cantidadI < 0){
                    System.out.println("Cantidad Inicial.");
                }
                if (pc.cantidadC < 0) {
                    System.out.println("Cantidad Comprada.");
                }
                if (pc.cantidadV < 0) {
                    System.out.println("Cantidad Vendida.");
                }
                if (pc.precioDC < 0) {
                    System.out.println("Precio de Compra.");
                }
            }
        } else {
            pc.calcularProductoC();

            System.out.println("Precio de Venta: " + pc.precioDV);
            System.out.println("Ingresos: " + pc.ingresos);
            System.out.println("Egresos: " + pc.egresos);
            System.out.println("Ganancias Brutas: " + pc.gananciasB);
            System.out.println("Impuestos: " + pc.impuestos);
            System.out.println("ganancias Netas: " + pc.gananciasN);
        }
    }
}
