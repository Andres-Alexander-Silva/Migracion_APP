package Ejercicio15;

import java.util.Scanner;

class DiaSemanaMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        DiaSemana ds = new DiaSemana();

        ds.dia = c.nextInt();
        ds.mes = c.nextInt();
        ds.anio = c.nextInt();

        ds.calcularSemana();

        if (ds.diaSemana == 0){
            System.out.println("Domingo");
        }
        if (ds.diaSemana == 1){
            System.out.println("Luens");
        }
        if (ds.diaSemana == 2){
            System.out.println("Martes");
        }
        if (ds.diaSemana == 3){
            System.out.println("Miercoles");
        }
        if (ds.diaSemana == 4){
            System.out.println("Jueves");
        }
        if (ds.diaSemana == 5){
            System.out.println("Viernes");
        }
        if (ds.diaSemana == 6){
            System.out.println("Sabado");
        }
    }
}
