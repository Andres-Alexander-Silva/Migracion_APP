package Ejercicio15;

public class DiaSemana {
    int dia,mes,anio;
    int factorCorreccion,mesZeller,anioZeller;
    int anioZellerCuarto,anioZellerCien,anioZellerCuatroCientos;
    int diaSemana;

    void calcularSemana(){
        factorCorreccion = (14 - mes)/12;
        mesZeller = (mes - 2) + (12 * factorCorreccion);
        anioZeller = anio - factorCorreccion;
        anioZellerCuarto = anio / 4;
        anioZellerCien = anio / 100;
        anioZellerCuatroCientos = anio / 400;
        diaSemana = (dia + anioZeller + anioZellerCuarto - anioZellerCien + anioZellerCuatroCientos + (31 * mesZeller)/12)%7;
    }
}
