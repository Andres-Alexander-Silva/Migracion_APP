package Ejercicio10;

import java.util.Scanner;

class EdadPerroMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        int edadH;
        double edadP;

        edadH = c.nextInt();

        if (edadH >= 0){
            if (edadH == 0) {
                edadP = 0.0;
                System.out.println("Edad del Perro: " + edadP);
            }
            if (edadH == 1){
                edadP = 5.0;
                System.out.println("Edad del Perro: " + edadP);
            }
            if (edadH == 2){
                edadP = 10.5;
                System.out.println("Edad del Perro: " + edadP);
            }
            if (edadH > 2){
                edadH -= 2;
                edadP = (edadH * 4.5) + 10.5;
                System.out.println("Edad del Perro: " + edadP);
            }
        } else {
            System.out.println("Datos no Válidos.");
        }
    }
}
