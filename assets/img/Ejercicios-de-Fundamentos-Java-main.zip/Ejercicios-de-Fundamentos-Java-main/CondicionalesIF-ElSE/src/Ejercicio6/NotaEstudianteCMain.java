package Ejercicio6;

import java.util.Scanner;

class NotaEstudianteCMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        float notaEstudiante;

        notaEstudiante = c.nextFloat();

        if (notaEstudiante >= 0 && notaEstudiante <= 5) {
            if (notaEstudiante > 0 && notaEstudiante < 2.9) {
                System.out.println("La calificación es muy deficiente");
            }
            if (notaEstudiante >= 3 && notaEstudiante < 3.4) {
                System.out.println("La calificación es deficiente");
            }
            if (notaEstudiante >= 3.5 && notaEstudiante < 3.9) {
                System.out.println("La calificación es aceptable");
            }
            if (notaEstudiante >= 4 && notaEstudiante < 4.4) {
                System.out.println("La calificación es buena");
            }
            if (notaEstudiante >= 4.5 && notaEstudiante < 4.9) {
                System.out.println("La calificación es excelente");
            }
        } else {
            System.out.println("La calificación no es válida  (fuera del rango [0,5])");
        }
    }
}
