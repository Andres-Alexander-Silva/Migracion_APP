package Ejercicio24;

public class JuegoNaipes {
    long manoC,c1,c2,c3,c4,c5,numc1,numc2,numc3,numc4,numc5;
    long paloc1,paloc2,paloc3,paloc4,paloc5;
    String numc1S,numc2S,numc3S,numc4S,numc5S;
    char paloc1S=0,paloc2S=0,paloc3S=0,paloc4S=0,paloc5S=0;
    String manoCS;

    void algoritmo(){
        manoCS = String.valueOf(manoC);

        c1 = manoC / 1000000000000L;
        c2 = (manoC % 1000000000000L) / 1000000000;
        c3 = ((manoC % 1000000000000L) % 1000000000) / 1000000;
        c4 = (((manoC % 1000000000000L) % 1000000000) % 1000000) / 1000;
        c5 = ((((manoC % 1000000000000L) % 1000000000) % 1000000) % 1000);

        numc1 = c1 / 10;
        numc2 = c2 / 10;
        numc3 = c3 / 10;
        numc4 = c4 / 10;
        numc5 = c5 / 10;

        paloc1 = c1 % 10;
        paloc2 = c2 % 10;
        paloc3 = c3 % 10;
        paloc4 = c4 % 10;
        paloc5 = c5 % 10;

        if (((numc1 >= 1 && numc1 <= 13)&&(numc2 >= 1 && numc2 <= 13)&&(numc3 >= 1 && numc3 <= 13)&&
                (numc4 >= 1 && numc4 <= 13)&&(numc5 >= 1 && numc5 <= 13))&&((paloc1 >= 0 && paloc1 <= 3)&&
                (paloc2 >= 0 && paloc2 <= 3)&&(paloc3 >= 0 && paloc3 <= 3)&&(paloc4 >= 0 && paloc4 <= 3)&&
                (paloc5 >= 0 && paloc5 <= 3))&&(manoCS.length()==15)){
            //Pinta cartas (♡,♠,♣,♢)
            //Pinto carta 1
            if (paloc1 == 0) paloc1S = '\u2660';
            if (paloc1 == 1) paloc1S = '\u2661';
            if (paloc1 == 2) paloc1S = '\u2662';
            if (paloc1 == 3) paloc1S = '\u2663';
            //Pinta carta 2
            if (paloc2 == 0) paloc2S = '\u2660';
            if (paloc2 == 1) paloc2S = '\u2661';
            if (paloc2 == 2) paloc2S = '\u2662';
            if (paloc2 == 3) paloc2S = '\u2663';
            //Pinta carta 3
            if (paloc3 == 0) paloc3S = '\u2660';
            if (paloc3 == 1) paloc3S = '\u2661';
            if (paloc3 == 2) paloc3S = '\u2662';
            if (paloc3 == 3) paloc3S = '\u2663';
            //Pinta carta 4
            if (paloc4 == 0) paloc4S = '\u2660';
            if (paloc4 == 1) paloc4S = '\u2661';
            if (paloc4 == 2) paloc4S = '\u2662';
            if (paloc4 == 3) paloc4S = '\u2663';
            //Pinta carta 5
            if (paloc5 == 0) paloc5S = '\u2660';
            if (paloc5 == 1) paloc5S = '\u2661';
            if (paloc5 == 2) paloc5S = '\u2662';
            if (paloc5 == 3) paloc5S = '\u2663';
            //Carta numero = letra (J=11,Q=12,K=13,A=1)
            //Carta 1 letras y numeros
            if (numc1 == 1) numc1S = "A";
            if (numc1 == 11) numc1S = "J";
            if (numc1 == 12) numc1S = "Q";
            if (numc1 == 13) numc1S = "K";
            if (numc1 == 2) numc1S = "2";
            if (numc1 == 3) numc1S = "3";
            if (numc1 == 4) numc1S = "4";
            if (numc1 == 5) numc1S = "5";
            if (numc1 == 6) numc1S = "6";
            if (numc1 == 7) numc1S = "7";
            if (numc1 == 8) numc1S = "8";
            if (numc1 == 9) numc1S = "9";
            if (numc1 == 10) numc1S = "10";
            //Carta 2 letras y numeros
            if (numc2 == 1) numc2S = "A";
            if (numc2 == 11) numc2S = "J";
            if (numc2 == 12) numc2S = "Q";
            if (numc2 == 13) numc2S = "K";
            if (numc2 == 2) numc2S = "2";
            if (numc2 == 3) numc2S = "3";
            if (numc2 == 4) numc2S = "4";
            if (numc2 == 5) numc2S = "5";
            if (numc2 == 6) numc2S = "6";
            if (numc2 == 7) numc2S = "7";
            if (numc2 == 8) numc2S = "8";
            if (numc2 == 9) numc2S = "9";
            if (numc2 == 10) numc2S = "10";
            //Carta 3 letras y numeros
            if (numc3 == 1) numc3S = "A";
            if (numc3 == 11) numc3S = "J";
            if (numc3 == 12) numc3S = "Q";
            if (numc3 == 13) numc3S = "K";
            if (numc3 == 2) numc3S = "2";
            if (numc3 == 3) numc3S = "3";
            if (numc3 == 4) numc3S = "4";
            if (numc3 == 5) numc3S = "5";
            if (numc3 == 6) numc3S = "6";
            if (numc3 == 7) numc3S = "7";
            if (numc3 == 8) numc3S = "8";
            if (numc3 == 9) numc3S = "9";
            if (numc3 == 10) numc3S = "10";
            //Carta 4 letras y numeros
            if (numc4 == 1) numc4S = "A";
            if (numc4 == 11) numc4S = "J";
            if (numc4 == 12) numc4S = "Q";
            if (numc4 == 13) numc4S = "K";
            if (numc4 == 2) numc4S = "2";
            if (numc4 == 3) numc4S = "3";
            if (numc4 == 4) numc4S = "4";
            if (numc4 == 5) numc4S = "5";
            if (numc4 == 6) numc4S = "6";
            if (numc4 == 7) numc4S = "7";
            if (numc4 == 8) numc4S = "8";
            if (numc4 == 9) numc4S = "9";
            if (numc4 == 10) numc4S = "10";
            //Carta 5 letras y numeros
            if (numc5 == 1) numc5S = "A";
            if (numc5 == 11) numc5S = "J";
            if (numc5 == 12) numc5S = "Q";
            if (numc5 == 13) numc5S = "K";
            if (numc5 == 2) numc5S = "2";
            if (numc5 == 3) numc5S = "3";
            if (numc5 == 4) numc5S = "4";
            if (numc5 == 5) numc5S = "5";
            if (numc5 == 6) numc5S = "6";
            if (numc5 == 7) numc5S = "7";
            if (numc5 == 8) numc5S = "8";
            if (numc5 == 9) numc5S = "9";
            if (numc5 == 10) numc5S = "10";
            //Imprimir mano
            System.out.println(numc1S+""+paloc1S+","+numc2S+""+paloc2S+","+numc3S+""+paloc3S+","+numc4S+""+paloc4S+","+numc5S+""+paloc5S);
            //
            if((paloc1==paloc2)&&(paloc2==paloc3)&&(paloc3==paloc4)&&(paloc4==paloc5)){
                if((numc1==10)&&(numc2==11)&&(numc3==12)&&(numc4==13)&&(numc5==1)){
                    System.out.println("Flor Imperial");
                }else{
                    if((numc1==numc2-1)&&(numc2==numc3-1)&&(numc3==numc4-1)&&(numc4==numc5-1)){
                        System.out.println("Escalera de color");
                    }else{
                        System.out.println("¡Otra Mano!");
                    }
                }
            } else {
                if(((numc1==numc2-1)&&(numc2==numc3-1)&&(numc3==numc4-1)&&(numc4==numc5-1||numc4==numc5+12))||
                        ((numc1==numc2)&&(numc2==numc3)&&(numc3==numc4))||((numc1==numc2)&&
                        (numc2==numc3)&&(numc3!=numc4)&&(numc4==numc5))){
                    if((numc1==numc2-1)&&(numc2==numc3-1)&&(numc3==numc4-1)&&(numc4==numc5-1||numc4==numc5+12)){
                        System.out.println("Escalera");
                    }if((numc1==numc2)&&(numc2==numc3)&&(numc3==numc4)){
                        System.out.println("Póker");
                    }if((numc1==numc2)&&(numc2==numc3)&&(numc3!=numc4)&&(numc4==numc5)){
                        System.out.println("Full House");
                    }
                }else{
                   System.out.println("¡Otra Mano!");
                }
            }
        } else {
            System.out.println("Mano inválida");
        }
    }
}
