package Ejercicio24;

import java.util.Scanner;

class JuegoNaipesMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        JuegoNaipes jp = new JuegoNaipes();

        jp.manoC = c.nextLong();

        jp.algoritmo();
    }
}
