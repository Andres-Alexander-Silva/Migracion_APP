package Ejercicio5;

import java.util.Scanner;

class ServiciosPublicosCMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        ServiciosPublicosC spc = new ServiciosPublicosC();

        spc.lecturaAn = c.nextInt();
        spc.lecturaAc = c.nextInt();
        spc.tarifaM = c.nextInt();

        if (spc.lecturaAn < 0 || spc.lecturaAc < 0 || spc.tarifaM < 0){
            System.out.println("Error los siguientes datos son negativos");
            if (spc.lecturaAn < 0){
                System.out.println("Lectura Anterior.");
            }
            if (spc.lecturaAc < 0){
                System.out.println("Lectura Actual.");
            }
            if (spc.tarifaM < 0){
                System.out.println("Tarifa Mensual.");
            }
        }
        if (spc.lecturaAc > 0 && spc.lecturaAn > 0 && spc.tarifaM > 0){
            if (spc.lecturaAn > spc.lecturaAc) {
                System.out.println("Consumo Inconsistente. Se cobra Tarifa Plena");

                spc.inconsistencia();

                System.out.println("Agua           : " + spc.agua);
                System.out.println("Aseo           : " + spc.aseo);
                System.out.println("alcantarillado : " + spc.alcantarillado);
                System.out.println("Total          : " + spc.total);
            }
            if (spc.lecturaAn < spc.lecturaAc) {
                spc.calcularServiciosPC();
                System.out.println("Consumo        : " + spc.consumo);
                if (spc.consumo <= 20) {
                    spc.calcularServiciosPC();

                    System.out.println("Agua           : " + spc.agua);
                    System.out.println("Aseo           : " + spc.aseo);
                    System.out.println("alcantarillado : " + spc.alcantarillado);
                    System.out.println("Total          : " + spc.total);
                }
                if (spc.consumo > 20) {
                    spc.consumoMayorVeinte();

                    System.out.println("Agua           : " + spc.agua);
                    System.out.println("Aseo           : " + spc.aseo);
                    System.out.println("alcantarillado : " + spc.alcantarillado);
                    System.out.println("Total          : " + spc.total);
                }
            }
        }
    }
}
