package Ejercicio5;

class ServiciosPublicosC {
    int lecturaAn,lecturaAc,tarifaM,consumo,inco = 30;
    double agua,aseo,alcantarillado,sobrecargo,total;

    void calcularServiciosPC(){
        consumo = lecturaAc - lecturaAn;
        agua = consumo * tarifaM;
        aseo = (agua * 10) / 100;
        alcantarillado = (agua * 15) / 100;
        total = agua + aseo + alcantarillado;
    }
    void consumoMayorVeinte(){
        consumo = lecturaAc -lecturaAn;
        agua = consumo - 20;
        sobrecargo = (double) (tarifaM * 25) / 100;
        sobrecargo *= agua;
        agua = (consumo * tarifaM) + sobrecargo;
        aseo = (agua * 10) / 100;
        alcantarillado = (agua * 15) / 100;
        total = agua + aseo + alcantarillado;
    }
    void inconsistencia(){
        agua = tarifaM * inco;
        aseo = (agua * 10) / 100;
        alcantarillado = (agua * 15) / 100;
        total = agua + aseo + alcantarillado;
    }
}
