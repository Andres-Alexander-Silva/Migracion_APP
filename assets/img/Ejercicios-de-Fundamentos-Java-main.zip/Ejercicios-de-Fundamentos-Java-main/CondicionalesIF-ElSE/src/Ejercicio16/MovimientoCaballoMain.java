package Ejercicio16;

import java.util.Scanner;

class MovimientoCaballoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        char columnaI,columnaF,filaI,filaF;
        int columnaFA,columnaIA,filaIA,filaFA;

        columnaI = c.next().charAt(0);
        filaI = c.next().charAt(0);
        columnaF = c.next().charAt(0);
        filaF = c.next().charAt(0);

        columnaIA = (int) (columnaI);
        columnaFA = (int) (columnaF);
        filaIA = (int) (filaI);
        filaFA = (int) (filaF);

        if ((columnaIA < 97)||(columnaIA > 104)||(filaIA < 49)||(filaIA > 56)||(columnaFA < 97)||(columnaFA > 104)||(filaFA < 49||filaFA>56)) {
            if ((columnaIA < 97) || (columnaIA > 104) || (filaIA < 49) || (filaIA > 56)) {
                System.out.println("Coordenada Inicial no Válida");
            }
            if ((columnaFA < 97) || (columnaFA > 104) || (filaFA < 49) || (filaFA > 56)) {
                System.out.println("Coordenada Final no Válida");
            }
        } else {
            if ((columnaIA + 1 == columnaFA) && (filaIA + 2 == filaFA)) {
                System.out.println("Movimiento 1");
            }
            else if ((columnaIA + 2 == columnaFA) && (filaIA + 1 == filaFA)) {
                System.out.println("Movimiento 2");
            }
            else if ((columnaIA + 2 == columnaFA) && (filaIA - 1 == filaFA)) {
                System.out.println("Movimiento 3");
            }
            else if ((columnaIA + 1 == columnaFA) && (filaIA - 2 == filaFA)) {
                System.out.println("Movimiento 4");
            }
            else if ((columnaIA - 1 == columnaFA) && (filaIA - 2 == filaFA)) {
                System.out.println("Movimiento 5");
            }
            else if ((columnaIA - 2 == columnaFA) && (filaIA - 1 == filaFA)) {
                System.out.println("Movimiento 6");
            }
            else if ((columnaIA - 2 == columnaFA) && (filaIA + 1 == filaFA)) {
                System.out.println("Movimiento 7");
            }
            else if ((columnaIA - 1 == columnaFA) && (filaIA + 2 == filaFA)) {
                System.out.println("Movimiento 8");
            } else {
                System.out.println("No es un caballo");
            }
        }
    }
}