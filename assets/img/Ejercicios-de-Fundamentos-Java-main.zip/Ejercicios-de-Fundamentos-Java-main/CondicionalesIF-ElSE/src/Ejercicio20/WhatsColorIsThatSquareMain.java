package Ejercicio20;

import java.util.Scanner;

class WhatsColorIsThatSquareMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        char columna,fila;
        int columanAscii,filaAscii;

        columna = c.next().charAt(0);
        fila = c.next().charAt(0);

        columanAscii = (int) (columna);
        filaAscii = (int) (fila);

        if ((columanAscii >= 97 && columanAscii <= 104)&&(filaAscii >= 49 && filaAscii <= 56)){
            //Piezas Blancas
            if (filaAscii == 49 && columanAscii == 97){
                System.out.println("Casilla de color negro, por defecto debería contener torre");
            }
            if (filaAscii == 50 && columanAscii == 97){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 98){
                System.out.println("Casilla de color blanco, por defecto debería contener caballo");
            }
            if (filaAscii == 50 && columanAscii == 98){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 99){
                System.out.println("Casilla de color negro, por defecto debería contener alfil");
            }
            if (filaAscii == 50 && columanAscii == 99){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 100){
                System.out.println("Casilla de color blanco, por defecto debería contener dama");
            }
            if (filaAscii == 50 && columanAscii == 100){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 101){
                System.out.println("Casilla de color negro, por defecto debería contener rey");
            }
            if (filaAscii == 50 && columanAscii == 101){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 102){
                System.out.println("Casilla de color blanco, por defecto debería contener alfil");
            }
            if (filaAscii == 50 && columanAscii == 102){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 103){
                System.out.println("Casilla de color negro, por defecto debería contener caballo");
            }
            if (filaAscii == 50 && columanAscii == 103){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 49 && columanAscii == 104){
                System.out.println("Casilla de color blanco, por defecto debería contener torre");
            }
            if (filaAscii == 50 && columanAscii == 104){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            //Piezas Negras
            if (filaAscii == 56 && columanAscii == 97){
                System.out.println("Casilla de color blanco, por defecto debería contener torre");
            }
            if (filaAscii == 55 && columanAscii == 97){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 98){
                System.out.println("Casilla de color negro, por defecto debería contener caballo");
            }
            if (filaAscii == 55 && columanAscii == 98){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 99){
                System.out.println("Casilla de color blanco, por defecto debería contener alfil");
            }
            if (filaAscii == 55 && columanAscii == 99){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 100){
                System.out.println("Casilla de color negro, por defecto debería contener dama");
            }
            if (filaAscii == 55 && columanAscii == 100){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 101){
                System.out.println("Casilla de color blanco, por defecto debería contener rey");
            }
            if (filaAscii == 55 && columanAscii == 101){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 102){
                System.out.println("Casilla de color negro, por defecto debería contener alfil");
            }
            if (filaAscii == 55 && columanAscii == 102){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 103){
                System.out.println("Casilla de color blanco, por defecto debería contener caballo");
            }
            if (filaAscii == 55 && columanAscii == 103){
                System.out.println("Casilla de color negro, por defecto debería contener peón");
            }
            if (filaAscii == 56 && columanAscii == 104){
                System.out.println("Casilla de color negro, por defecto debería contener torre");
            }
            if (filaAscii == 55 && columanAscii == 104){
                System.out.println("Casilla de color blanco, por defecto debería contener peón");
            }
            if ((filaAscii == 51 && columanAscii == 97)||(filaAscii == 51 && columanAscii == 99)||(filaAscii == 51 && columanAscii == 101)||(filaAscii == 51 && columanAscii == 103)){
                System.out.println("Casilla de color negro, por defecto debería contener vacio");
            }
            if ((filaAscii == 51 && columanAscii == 98)||(filaAscii == 51 && columanAscii == 100)||(filaAscii == 51 && columanAscii == 102)||(filaAscii == 51 && columanAscii == 104)){
                System.out.println("Casilla de color blanco, por defecto debería contener vacio");
            }
            if ((filaAscii == 52 && columanAscii == 97)||(filaAscii == 52 && columanAscii == 99)||(filaAscii == 52 && columanAscii == 101)||(filaAscii == 52 && columanAscii == 103)){
                System.out.println("Casilla de color blanco, por defecto debería contener vacio");
            }
            if ((filaAscii == 52 && columanAscii == 98)||(filaAscii == 52 && columanAscii == 100)||(filaAscii == 52 && columanAscii == 102)||(filaAscii == 52 && columanAscii == 104)){
                System.out.println("Casilla de color negro, por defecto debería contener vacio");
            }
            if ((filaAscii == 53 && columanAscii == 97)||(filaAscii == 53 && columanAscii == 99)||(filaAscii == 53 && columanAscii == 101)||(filaAscii == 53 && columanAscii == 103)){
                System.out.println("Casilla de color negro, por defecto debería contener vacio");
            }
            if ((filaAscii == 53 && columanAscii == 98)||(filaAscii == 53 && columanAscii == 100)||(filaAscii == 53 && columanAscii == 102)||(filaAscii == 53 && columanAscii == 104)){
                System.out.println("Casilla de color blanco, por defecto debería contener vacio");
            }
            if ((filaAscii == 54 && columanAscii == 97)||(filaAscii == 54 && columanAscii == 99)||(filaAscii == 54 && columanAscii == 101)||(filaAscii == 54 && columanAscii == 103)){
                System.out.println("Casilla de color blanco, por defecto debería contener vacio");
            }
            if ((filaAscii == 54 && columanAscii == 98)||(filaAscii == 54 && columanAscii == 100)||(filaAscii == 54 && columanAscii == 102)||(filaAscii == 54 && columanAscii == 104)){
                System.out.println("Casilla de color negro, por defecto debería contener vacio");
            }
        } else {
            System.out.println("Datos incorrectos");
        }
    }
}