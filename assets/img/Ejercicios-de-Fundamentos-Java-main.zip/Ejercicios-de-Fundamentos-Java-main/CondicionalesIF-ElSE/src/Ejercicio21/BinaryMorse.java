package Ejercicio21;

import java.util.Scanner;

class BinaryMorse {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        long binaryMorse;
        int numTC;
        int parte1,parte2,parte3;

        binaryMorse = c.nextLong();

        parte1 = (int) (binaryMorse / 10000000000L);
        parte2 = (int) (binaryMorse % 10000000000L) / 100000;
        parte3 = (int) (binaryMorse % 10000000000L) % 100000;

        if (binaryMorse > 0){
            int num1=0;
            int num2=0;
            int num3=0;
            if (parte1 == 10000){
                num1 = 1;
            }
            if (parte1 == 11000){
                num1 = 2;
            }
            if (parte1 == 11100){
                num1 = 3;
            }
            if (parte1 == 11110){
                num1 = 4;
            }
            if (parte1 == 11111){
                num1 = 5;
            }
            if (parte1 == 1111){
                num1 = 6;
            }
            if (parte1 == 111){
                num1 = 7;
            }
            if (parte1 == 11){
                num1 = 8;
            }
            if (parte1 == 1){
                num1 = 9;
            }
            if (parte1 == 0){
                num1 = 0;
            }
            if (parte2 == 10000){
                num2 = 1;
            }
            if (parte2 == 11000){
                num2 = 2;
            }
            if (parte2 == 11100){
                num2 = 3;
            }
            if (parte2 == 11110){
                num2 = 4;
            }
            if (parte2 == 11111){
                num2 = 5;
            }
            if (parte2 == 1111){
                num2 = 6;
            }
            if (parte2 == 111){
                num2 = 7;
            }
            if (parte2 == 11){
                num2 = 8;
            }
            if (parte2 == 1){
                num2 = 9;
            }
            if (parte2 == 0){
                num2 = 0;
            }
            if (parte3 == 10000){
                num3 = 1;
            }
            if (parte3 == 11000){
                num3 = 2;
            }
            if (parte3 == 11100){
                num3 = 3;
            }
            if (parte3 == 11110){
                num3 = 4;
            }
            if (parte3 == 11111){
                num3 = 5;
            }
            if (parte3 == 1111){
                num3 = 6;
            }
            if (parte3 == 111){
                num3 = 7;
            }
            if (parte3 == 11){
                num3 = 8;
            }
            if (parte3 == 1){
                num3 = 9;
            }
            if (parte3 == 0){
                num3 = 0;
            }
            num1 *= 100;
            num2 *= 10;
            numTC = num1+num2+num3;
            System.out.println("Salida Binary Morse: " + numTC);

        } else {
            System.out.println("Error, número negativo");
        }
    }
}