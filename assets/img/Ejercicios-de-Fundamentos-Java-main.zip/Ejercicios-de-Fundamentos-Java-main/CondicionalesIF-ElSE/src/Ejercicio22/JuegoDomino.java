package Ejercicio22;

import java.util.Scanner;

class JuegoDomino {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        int num1,num2,num3;
        int num1A,num1B,num2A,num2B,num3A,num3B;

        num1 = c.nextInt();
        num2 = c.nextInt();
        num3 = c.nextInt();

        num1A = num1 / 10;
        num1B = num1 % 10;
        num2A = num2 / 10;
        num2B = num2 % 10;
        num3A = num3 / 10;
        num3B = num3 % 10;

        if ((num1A >= 0 && num1A <= 6)&&(num1B >= 0 && num1B <= 6)&&(num2A >= 0 && num2A <= 6)&&
                (num2B >= 0 && num2B <= 6)&&(num3A >= 0 && num3A <= 6)&&(num3B >= 0 && num3B <= 6)){
            if (((num1A == num2B)&&(num1B == num2A))||((num1A == num2A)&&(num1B == num2B))||((num1A == num3B)&&(num1B == num3A))||
                    ((num1A == num3A)&&(num1B == num3B))||((num2A == num3B)&&(num2B == num3A))||((num2A == num3A)&&(num2B ==num3B))){
                System.out.println("Hay un error de fichas duplicadas");
            } else {
                if ((num1A == num3A||num1A == num3B)&&(num2A == num3A||num2B == num3B)){
                    System.out.println("Se puede jugar a cualquiera de los dos extremos");
                } else {
                    if ((num1A == num3A)||(num1A == num3B)){
                        System.out.println("Se puede jugar al extremo izquierdo");
                    } else {
                        if ((num2B == num3A)||(num2B == num3B)){
                            System.out.println("Se  puede jugar al extremo derecho");
                        } else {
                            System.out.println("No se puede jugar, debe pasar");
                        }
                    }
                }
            }
        } else {
            if (((num1A < 0 || num1A > 6)||(num1B < 0 || num1B > 6))&&((num2A < 0 || num2A > 6)||(num2B < 0 || num2B > 6))&&
                    ((num3A < 0 || num3A > 6)||(num3B < 0 || num3B > 6))){
                System.out.println("Los tres números no corresponden a una ficha de dominó");
            } else {
                System.out.println("Alguno de los tres números no corresponde a una ficha de dominó");
            }
        }
    }
}
