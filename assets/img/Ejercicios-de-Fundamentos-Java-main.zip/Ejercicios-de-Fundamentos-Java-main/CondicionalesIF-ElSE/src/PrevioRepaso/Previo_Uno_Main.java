package PrevioRepaso;

import java.util.Scanner;

class Previo_Uno_Main {
    //Clase Main
    public static void main(String[] args) {
        //Clase scanner para capturar datos de entrada
        Scanner c = new Scanner(System.in);

        //Constantes
        int aceite=150000,filtros=80000,correasYB=350000,frenos=300000,llantas=1100000,amortiguadores=350000,nivelesDeL=50000;
        int aceiteH=2,filtroH=1,correasYBH=5,frenosH=3,llantasH=1,amortiguadoresH=3,nivelesDeLH=1;
        int precioManoObra=40000;

        //Entradas
        int kmVehiculos,tipoVehiculo;

        //Varibles de Proceso
        int manoDeObra,manoDeObraCamionetas,manoDeObraCamiones,costoRepuestos;

        //Leer datos de entrada
        kmVehiculos = c.nextInt();
        tipoVehiculo = c.nextInt();

        //Salida
        float totalPagarMantenimiento;

        //Proceso
        if (tipoVehiculo == 1){
            if (kmVehiculos > 0 && kmVehiculos <= 15000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 15000 && kmVehiculos <= 25000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 25000 && kmVehiculos <= 35000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 35000 && kmVehiculos <= 45000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 45000 && kmVehiculos <= 55000){
                costoRepuestos = aceite + filtros + correasYB + llantas + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + correasYBH + llantasH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 55000 && kmVehiculos <= 65000){
                costoRepuestos = aceite + filtros + frenos + amortiguadores + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + amortiguadoresH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 65000 && kmVehiculos <= 75000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 75000 && kmVehiculos <= 85000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 85000 && kmVehiculos <= 95000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 95000 && kmVehiculos <= 100000){
                costoRepuestos = aceite + filtros + correasYB + frenos + llantas + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + correasYBH + frenosH + llantasH + nivelesDeLH) * precioManoObra;
                totalPagarMantenimiento = costoRepuestos + manoDeObra;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 100000){
                System.out.println("no aplica este programa de mantenimiento y se debe usar otro programa");
            }
        }
        if (tipoVehiculo == 2){
            if (kmVehiculos > 0 && kmVehiculos <= 15000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 15000 && kmVehiculos <= 25000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 25000 && kmVehiculos <= 35000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 35000 && kmVehiculos <= 45000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 45000 && kmVehiculos <= 55000){
                costoRepuestos = aceite + filtros + correasYB + llantas + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + correasYBH + llantasH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 55000 && kmVehiculos <= 65000){
                costoRepuestos = aceite + filtros + frenos + amortiguadores + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + amortiguadoresH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 65000 && kmVehiculos <= 75000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 75000 && kmVehiculos <= 85000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 85000 && kmVehiculos <= 95000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 95000 && kmVehiculos <= 100000){
                costoRepuestos = aceite + filtros + correasYB + frenos + llantas + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + correasYB + frenosH + llantasH + nivelesDeLH) * precioManoObra;
                manoDeObraCamionetas = manoDeObra * 2;
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamionetas;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 100000){
                System.out.println("no aplica este programa de mantenimiento y se debe usar otro programa");
            }
        }
        if (tipoVehiculo == 3){
            if (kmVehiculos > 0 && kmVehiculos <= 15000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 15000 && kmVehiculos <= 25000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 25000 && kmVehiculos <= 35000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 35000 && kmVehiculos <= 45000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 45000 && kmVehiculos <= 55000){
                costoRepuestos = aceite + filtros + correasYB + llantas + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + correasYBH + llantasH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 55000 && kmVehiculos <= 65000){
                costoRepuestos = aceite + filtros + frenos + amortiguadores + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + amortiguadoresH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 65000 && kmVehiculos <= 75000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 75000 && kmVehiculos <= 85000){
                costoRepuestos = aceite + filtros + frenos + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + frenosH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 85000 && kmVehiculos <= 95000){
                costoRepuestos = aceite + filtros + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 95000 && kmVehiculos <= 100000){
                costoRepuestos = aceite + filtros + correasYB + frenos + llantas + nivelesDeL;
                manoDeObra = (aceiteH + filtroH + correasYBH + frenosH + llantasH + nivelesDeLH) * precioManoObra;
                manoDeObraCamiones = (int) ((manoDeObra * 2) * 1.5);
                totalPagarMantenimiento = costoRepuestos + manoDeObraCamiones;
                System.out.println("Valor Mantenimiento del Véhiculo: " + totalPagarMantenimiento);
            }
            if (kmVehiculos > 100000){
                System.out.println("no aplica este programa de mantenimiento y se debe usar otro programa");
            }
        }
    }
}
