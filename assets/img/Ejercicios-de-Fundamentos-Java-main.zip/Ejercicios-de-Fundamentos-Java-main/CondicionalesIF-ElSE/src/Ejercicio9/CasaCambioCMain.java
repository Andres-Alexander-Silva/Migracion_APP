package Ejercicio9;

import java.util.Scanner;

class CasaCambioCMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        CasaCambioC casaC = new CasaCambioC();

        casaC.precioCompraDolar = c.nextDouble();
        casaC.precioVentaDolar = c.nextDouble();
        casaC.cantidadInicialPesos = c.nextDouble();
        casaC.cantidadInicialDolar = c.nextDouble();
        casaC.cantidadDolarComprado = c.nextDouble();
        casaC.cantidadDolarVendido = c.nextDouble();

        casaC.calcularCasaCC();

        if (casaC.informacionValida){
            System.out.println("Cantidad Final de Pesos: " + casaC.cantidadFinalPesos);
            System.out.println("Cantidad Final de Dolares: " + casaC.cantidadFinaldolares);
            System.out.println("EL negocio va bien ;)");
        } else {
            System.out.println("Cantidad Final de Pesos: " + casaC.cantidadFinalPesos);
            System.out.println("Cantidad Final de Dolares: " + casaC.cantidadFinaldolares);
            System.out.println("Hay pérdidas. Cambie de Casa de Cambio.");
        }
    }
}
