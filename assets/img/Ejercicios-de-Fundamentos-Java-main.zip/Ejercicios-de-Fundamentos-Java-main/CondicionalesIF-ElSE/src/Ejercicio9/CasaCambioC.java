package Ejercicio9;

class CasaCambioC {
    double precioCompraDolar,precioVentaDolar,cantidadInicialPesos,cantidadInicialDolar;
    double cantidadDolarComprado,cantidadDolarVendido,cantidadFinalPesos,cantidadFinaldolares;
    boolean informacionValida;

    void calcularCasaCC(){
        cantidadFinalPesos = cantidadInicialPesos + (cantidadDolarVendido * precioVentaDolar) - (cantidadDolarComprado * precioCompraDolar);
        cantidadFinaldolares = (cantidadInicialDolar + cantidadDolarComprado) - cantidadDolarVendido;
        informacionValida = (cantidadFinalPesos > 0) && (cantidadFinaldolares > 0);
    }
}
