package Ejercicio19;

import java.util.Scanner;

class HoraATravesDelEspejoMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        HoraATravesDelEspejo htdp = new HoraATravesDelEspejo();

        htdp.hReflejo = c.nextInt();

        htdp.horaEspejo();

        if (htdp.horaNV){
            System.out.println("Datos Incorrectos");
        } else if (htdp.h1){
            System.out.println("Hora Real: 0"+htdp.hReal1+":00");
        } else if (htdp.h2){
            System.out.println("Hora Real: "+htdp.hReal2+":00");
        } else if(htdp.h3){
            if (htdp.hReal3 < 10 && htdp.minReal3 < 10){
                System.out.println("Hora Real: 0"+htdp.hReal3+"0"+htdp.minReal3);
            } else if (htdp.hReal3 < 10 && htdp.minReal3 >= 10){
                System.out.println("Hora Real: 0"+htdp.hReal3+":"+htdp.minReal3);
            } else if (htdp.hReal3 >= 10 && htdp.minReal3 < 10){
                System.out.println("Hora Real: "+htdp.hReal3+":0"+htdp.minReal3);
            } else {
                System.out.println("Hora Real: "+htdp.hReal3+":"+htdp.minReal3);
            }
        } else if (htdp.h4){
            if (htdp.minReal4 < 10){
                System.out.println("Hora Real: "+htdp.hReal4+":0"+htdp.minReal4);
            } else {
                System.out.println("Hora Real: "+htdp.hReal4+":"+htdp.minReal4);
            }
        } else if (htdp.h5){
            if (htdp.minReal5 < 10){
                System.out.println("Hora Valida: "+htdp.hReal5+":0"+ htdp.minReal5);
            } else {
                System.out.println("Hora Valida: "+htdp.hReal5+":"+ htdp.minReal5);
            }
        } else if (htdp.h6){
            if (htdp.hReal6 < 10 && htdp.minReal6 < 10){
                System.out.println("Hora Real: 0"+htdp.hReal6+":0"+ htdp.minReal6);
            } else if (htdp.hReal6 < 10 && htdp.minReal6 >= 10){
                System.out.println("Hora Real: 0"+htdp.hReal6+":0"+ htdp.minReal6);
            } else if (htdp.hReal6 >= 10 && htdp.minReal6 < 10){
                System.out.println("Hora Valida: "+htdp.hReal6+":0"+ htdp.minReal6);
            } else {
                System.out.println("Hora Valida: "+htdp.hReal6+":"+ htdp.minReal6);
            }
        }
    }
}
