package Ejercicio19;

class HoraATravesDelEspejo {
    int hReflejo,hReal1,hReal2,hReal3,hReal4,hReal5,hReal6,hora,minuto;
    int minReal1,minReal2,minReal3,minReal4,minReal5,minReal6;
    boolean horaV,horaNV,h1,h2,h3,h4,h5,h6;

    void horaEspejo(){
        hora = hReflejo / 100;
        minuto = hReflejo % 100;

        horaV = (hora > 0 && hora <= 12) && (minuto >= 0 && minuto <= 59);
        horaNV = !horaV;

        h1 = hora == 11 && minuto == 0;
        hReal1 = hora - 10;
        minReal1 = minuto;

        h2 = hora == 12 && minuto == 0;
        hReal2 = hora;
        minReal2 = minuto;

        h3 = (hora >= 1 && hora <= 10) && (minuto >= 1 && minuto <= 59);
        hReal3 = 11 - hora;
        minReal3 = 60 - minuto;

        h4 = hora == 11 && minuto >= 1 && minuto <= 59;
        hReal4 = hora + 1;
        minReal4 = 60 - minuto;

        h5 = hora == 12 && minuto >= 1 && minuto <= 59;
        hReal5 = hora - 1;
        minReal5 = 60 - minuto;

        h6 = hora >= 1 && hora <= 10 && minuto == 0;
        hReal6 = 12 - hora;
        minReal6 = 00;
    }
}
