package Ejercicio17;

import java.util.GregorianCalendar;
import java.util.Scanner;

class HowOldAreYouMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        GregorianCalendar biciesto = new GregorianCalendar();

        int fecha1,fecha2;
        int dia1,dia2,mes1,mes2,anio1,anio2;
        int edad;

        fecha1 = c.nextInt();
        fecha2 = c.nextInt();

        dia1 = fecha1 / 1000000;
        dia2 = fecha2 / 1000000;
        mes1 = (fecha1 % 1000000) / 10000;
        mes2 = (fecha2 % 1000000) / 10000;
        anio1 = (fecha1 % 1000000) % 10000;
        anio2 = (fecha2 % 1000000) % 10000;
        edad = anio2 - anio1;

        if ((((mes1 == 1 && dia1>=0 && dia1<=31)||
                (mes1 == 2 && dia1>=0 && dia1<=28)||
                (mes1 == 3 && dia1>=0 && dia1<=31)||
                (mes1 == 4 && dia1>=0 && dia1<=30)||
                (mes1 == 5 && dia1>=0 && dia1<=31)||
                (mes1 == 6 && dia1>=0 && dia1<=30)||
                (mes1 == 7 && dia1>=0 && dia1<=31)||
                (mes1 == 8 && dia1>=0 && dia1<=31)||
                (mes1 == 9 && dia1>=0 && dia1<=30)||
                (mes1 == 10 && dia1>=0 && dia1<=31)||
                (mes1 == 11 && dia1>=0 && dia1<=30)||
                (mes1 == 12 && dia1>=0 && dia1<=31)||
                (mes1 == 2 && dia1>=0 && dia1<=29 && biciesto.isLeapYear(anio1)))==false||
                (mes1==0)||
                (dia1==0)||
                (anio1==0))||
                (((mes2 == 1 && dia2>=0 && dia2<=31)||
                        (mes2 == 2 && dia2>=0 && dia2<=28)||
                        (mes2 == 3 && dia2>=0 && dia2<=31)||
                        (mes2 == 4 && dia2>=0 && dia2<=30)||
                        (mes2 == 5 && dia2>=0 && dia2<=31)||
                        (mes2 == 6 && dia2>=0 && dia2<=30)||
                        (mes2 == 7 && dia2>=0 && dia2<=31)||
                        (mes2 == 8 && dia2>=0 && dia2<=31)||
                        (mes2 == 9 && dia2>=0 && dia2<=30)||
                        (mes2 == 10 && dia2>=0 && dia2<=31)||
                        (mes2 == 11 && dia2>=0 && dia2<=30)||
                        (mes2 == 12 && dia2>=0 && dia2<=31)||
                        (mes2 == 2 && dia2>=0 && dia2<=29 && biciesto.isLeapYear(anio2)))==false||
                (mes2==0)||
                (dia2==0)||
                (anio2==0))){
            if ((((mes1 == 1 && dia1>=0 && dia1<=31)||
                    (mes1 == 2 && dia1>=0 && dia1<=28)||
                    (mes1 == 3 && dia1>=0 && dia1<=31)||
                    (mes1 == 4 && dia1>=0 && dia1<=30)||
                    (mes1 == 5 && dia1>=0 && dia1<=31)||
                    (mes1 == 6 && dia1>=0 && dia1<=30)||
                    (mes1 == 7 && dia1>=0 && dia1<=31)||
                    (mes1 == 8 && dia1>=0 && dia1<=31)||
                    (mes1 == 9 && dia1>=0 && dia1<=30)||
                    (mes1 == 10 && dia1>=0 && dia1<=31)||
                    (mes1 == 11 && dia1>=0 && dia1<=30)||
                    (mes1 == 12 && dia1>=0 && dia1<=31)||
                    (mes1 == 2 && dia1>=0 && dia1<=29 && biciesto.isLeapYear(anio1)))==false||
                    (mes1==0)||
                    (dia1==0)||
                    (anio1==0))&&
                    (((mes2 == 1 && dia2>=0 && dia2<=31)||
                            (mes2 == 2 && dia2>=0 && dia2<=28)||
                            (mes2 == 3 && dia2>=0 && dia2<=31)||
                            (mes2 == 4 && dia2>=0 && dia2<=30)||
                            (mes2 == 5 && dia2>=0 && dia2<=31)||
                            (mes2 == 6 && dia2>=0 && dia2<=30)||
                            (mes2 == 7 && dia2>=0 && dia2<=31)||
                            (mes2 == 8 && dia2>=0 && dia2<=31)||
                            (mes2 == 9 && dia2>=0 && dia2<=30)||
                            (mes2 == 10 && dia2>=0 && dia2<=31)||
                            (mes2 == 11 && dia2>=0 && dia2<=30)||
                            (mes2 == 12 && dia2>=0 && dia2<=31)||
                            (mes2 == 2 && dia2>=0 && dia2<=29 && biciesto.isLeapYear(anio2)))==false||
                    (mes2==0)||
                    (dia2==0)||
                    (anio2==0))){
                System.out.println("Ninguna de las fechas es válida");
            } else {
                System.out.println("Alguna de las fechas no es válida");
            }
        } else {
            if (edad < 3){
                System.out.println("Las fechas corresponden a un bebé");
            }
            if (edad >= 3 && edad < 6){
                System.out.println("Las fechas corresponden a un párvulo");
            }
            if (edad >= 6 && edad < 10){
                System.out.println("Las fechas corresponden a un infante");
            }
            if (edad >= 10 && edad < 17){
                System.out.println("Las fechas corresponden a un adolescente");
            }
            if (edad >= 17 && edad < 25){
                System.out.println("Las fechas corresponden a un universitario");
            }
            if (edad >= 25){
                System.out.println("¿Cuándo se gradua?");
            }
        }
    }
}