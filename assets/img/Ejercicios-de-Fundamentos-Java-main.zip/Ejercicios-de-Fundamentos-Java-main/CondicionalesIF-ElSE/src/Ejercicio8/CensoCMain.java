package Ejercicio8;

import java.util.Scanner;

class CensoCMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);

        double edad,estatura,peso;

        edad = c.nextDouble();
        estatura = c.nextDouble();
        peso = c.nextDouble();

        if ((edad < 16 || edad > 50) || (estatura < 1 || estatura > 1.8) || (peso < 40 || peso > 100)){
            if (edad < 16 || edad > 50){
                System.out.println("Edad fuera de rango.");
            }
            if (estatura < 1 || estatura > 1.8){
                System.out.println("Estatura fuera de rango.");
            }
            if (peso < 40 || peso > 100){
                System.out.println("Peso fuera de rango.");
            }
        }
        if (edad >= 16 && edad <= 50){
            if (edad > 16 && edad <= 25){
                System.out.println("Joven.");
            }
            if (edad > 25 && edad <= 40){
                System.out.println("Adulto.");
            }
            if (edad > 40 && edad < 50){
                System.out.println("Segunda Edad.");
            }
        }
        if (estatura >= 1 && estatura <= 1.8){
            if (estatura > 1 && estatura <= 1.6){
                System.out.println("Estatura Baja.");
            }
            if (estatura > 1.6 && estatura <= 1.7){
                System.out.println("Estatura Promedio.");
            }
            if (estatura > 1.7 && estatura < 1.8){
                System.out.println("Estatura Alta.");
            }
        }
        if (peso >= 40 && peso <= 100){
            if (peso > 40 && peso <= 60){
                System.out.println("Peso Bajo.");
            }
            if (peso > 60 && peso <= 80){
                System.out.println("Peso Promedio.");
            }
            if (peso > 80 && peso < 100){
                System.out.println("Peso Alto.");
            }
        }
    }
}
