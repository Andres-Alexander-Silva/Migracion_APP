package Ejercicio1;

class TiendaC {
    int dineroI,ingresosT,egresosT;
    double impuestos,gananciasB,gananciasN,dineroT;

    void calcularTiendaC(){
        impuestos = (double) ((ingresosT * 19) / 100);
        gananciasB = ingresosT - egresosT;
        gananciasN = gananciasB - impuestos;
        dineroT = dineroI + gananciasN;
    }
}
