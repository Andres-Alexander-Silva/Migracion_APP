package Ejercicio1;

import java.util.Scanner;

class TiendaCMain {
    public static void main(String[] args) {
        Scanner c = new Scanner(System.in);
        TiendaC tc = new TiendaC();

        tc.dineroI = c.nextInt();
        tc.ingresosT = c.nextInt();
        tc.egresosT = c.nextInt();

        if (tc.dineroI < 0 || tc.ingresosT < 0 || tc.egresosT < 0) {
            System.out.println("Error, los siguientes datos son negativos:");
            if (tc.dineroI < 0) {
                System.out.println("Dinero Inicial.");
            }
            if (tc.ingresosT < 0) {
                System.out.println("Ingresos.");
            }
            if (tc.egresosT < 0) {
                System.out.println("Egresos.");
            }
        } else {
            tc.calcularTiendaC();

            System.out.println("Impuestos = " + tc.impuestos);
            System.out.println("Ganancias Brutas = " + tc.gananciasB);
            System.out.println("Ganancias Netas = " + tc.gananciasN);
            System.out.println("Dinero Final = " + tc.dineroT);
        }
    }
}
